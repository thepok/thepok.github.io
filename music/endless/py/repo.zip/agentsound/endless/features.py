"""The endless features: the ONLY place that switches them (module state of symphony / choir / solo / colour /
perform / bandlib.orchestra and orchestra-symphonic's plan, arc and score table).

    from agentsound.endless import features
    features.state()                        # {'setplan': True, 'tech': True, ...} - the current switches
    features.set(tech=False)                # unknown names are errors; applied in ORDER
    features.reset()                        # = set(**DEFAULTS) - what genres.py applies on import
    with features.using(tech=False, choir=False):   # restores the previous state on exit
        ...

Every switch off is bit-identical to the code before its round. set() switches everything that is on off (in reverse
ORDER) and the wanted features on (in ORDER), so the state never depends on the order of the calls before it - the
same switches give the same module state as a fresh import with them.
"""
from __future__ import annotations

from contextlib import contextmanager

DEFAULTS = {
    'setplan': True,         # round o18b / o22 SET_PLAN v4: per piece +0.05 se 0.21, the set level kept 21 of 28
    'tech': True,            # round o23 TECH: per piece +0.42 se 0.15, 12 won / 4 lost, the set level kept 28 of 28
    'choir': True,           # round oc2 CHOIR v2: per piece +0.18 se 0.18, the set level kept 28 of 28
    'solo': True,            # round os1 SOLO: per piece +0.51 se 0.12, 13 of 16 won, the set level agreed 28 of 28
    'colour': True,          # round ox1 COLOUR: per piece +0.05 se 0.19, the set level agreed 56 of 56, variety +1.2
    'tech2': True,           # round o25 (with 'shape'): per piece -0.06 se 0.18, the set level agreed 18 of 20
    'shape': True,           # round o25 SHAPE3: the macro shapes (merged with tech2)
    'polish': False,         # round op1 POLISH: waits for its follow-up round (branch op2)
    'pumping': True,         # user fix 2026-10-25 (docs/PUMPING.md): the phrase arc reduced to 30 %
    'piano_diverse': False,  # rounds p-div 1-4 PIANO_DIVERSE (new-age-piano): paused by the user
    'payoff': True,          # round pk4 PAYOFF (new-age-piano): per piece +0.33 se 0.16, 10 won / 4 lost
    'keyboard': True,        # round pk2 KEYBOARD v2 (new-age-piano): per piece +0.32 se 0.13, 11 won / 3 lost, hands +1.87
    'calm': True,            # round ol1 CALM (orchestra-symphonic): no cliffs at the joins, one note per onset; per piece
                             # +0.8 se, the set level agreed 9 of 9 (Wilson 0.70-1.00)
    'apart': False,          # round ol4 APART (orchestra-symphonic): not merged (per piece +1.5 se, sets agreed 2 of 7);
                             # v2 (the guest's feel and ending memory, its opening kept) waits for its round
}
"""The default switches (genres.py applies them on import). The merged rounds are on; the experiments waiting for a
listening round are off. `songs/_blind/shared_plan.py --flag no<name>` / `<name>` switches one for a paired round."""
ORDER = tuple(DEFAULTS)
"""The order the features are switched on (off: reversed): tech2 rides on tech's palette, polish on choir / solo /
colour; all of them before a set plan is drawn (set() is the only way to switch them)."""
NEEDS = {'polish': ('choir', 'solo', 'colour'), 'apart': ('colour',)}
"""A feature that only works on top of others: set() refuses it without them."""

_STATE = {k: False for k in DEFAULTS}
_SETPLAN_SAVED: dict = {}


def _loaded() -> None:
    """genres imported (its import applies DEFAULTS; until then every feature is off)."""
    from . import genres
    assert genres


def state() -> dict:
    """The current switches."""
    _loaded()
    return dict(_STATE)


def set(**flags) -> None:                                    # noqa: A001 (features.set)
    """Switch features by name (unknown names are errors); the others keep their state."""
    from ..theory import ComposeError
    _loaded()
    bad = sorted(k for k in flags if k not in DEFAULTS)
    if bad:
        raise ComposeError(f"features.set: unknown {', '.join(bad)}; one of {', '.join(DEFAULTS)}")
    want = dict(_STATE, **{k: bool(v) for k, v in flags.items()})
    for k, need in NEEDS.items():
        if want[k] and not all(want[n] for n in need):
            raise ComposeError(f"features.set: {k} needs {', '.join(need)} on")
    for k in reversed(ORDER):
        if _STATE[k]:
            _SWITCH[k](False)
            _STATE[k] = False
    for k in ORDER:
        if want[k]:
            _SWITCH[k](True)
            _STATE[k] = True


def reset() -> None:
    """The defaults (DEFAULTS)."""
    set(**DEFAULTS)


@contextmanager
def using(**flags):
    """features.set(**flags) for the with-block; the state before is restored on exit."""
    was = state()
    set(**flags)
    try:
        yield
    finally:
        set(**was)


# ------------------------------------------------------------------------------------------------ the switches

def _setplan(on: bool) -> None:
    """Round o18b, v4 since round o22 (symphony.SET_PLAN): ORCHESTRA_SYMPHONIC's set draws, memory, groups, shape and
    bar-plan memory and set arc (genres.SETPLAN_*), the motto cells (symphony.CELLS_V), the score's rows
    (genres.SETPLAN_ROWS) - restored as they were when switched off."""
    from . import genres as GE, symphony as S
    G = GE.ORCHESTRA_SYMPHONIC
    if on:
        _SETPLAN_SAVED.update(set=G.plan['set'], memory=G.plan['set_memory'], groups=G.plan.get('set_groups'),
                              shape=G.plan.get('set_shape'),
                              arc=G.arc['set'], cells={f: dict(c) for f, c in S.CELLS.items()})
        for f, c in S.CELLS_V.items():
            S.CELLS[f].update(c)
        G.plan['set'] = dict(G.plan['set'], **GE.SETPLAN_SET)
        G.plan['set_memory'] = dict(G.plan['set_memory'], **GE.SETPLAN_MEMORY)
        G.plan['set_groups'] = {'motto': S.MOTTO_FAMILIES}
        G.plan['set_feel'] = ('layout',)
        G.plan['set_shape'] = dict(GE.SETPLAN_SHAPE)
        G.plan['set_bars'] = dict(GE.SETPLAN_BARS)
        G.arc['set'] = dict(G.arc['set'], **GE.SETPLAN_ARC)
        S.SET_PLAN = dict(S.SET_PLAN_ON)
    else:
        G.plan['set'], G.plan['set_memory'] = _SETPLAN_SAVED['set'], _SETPLAN_SAVED['memory']
        G.plan.pop('set_feel', None)
        G.plan.pop('set_bars', None)
        if _SETPLAN_SAVED.get('shape') is None:
            G.plan.pop('set_shape', None)
        else:
            G.plan['set_shape'] = _SETPLAN_SAVED['shape']
        if _SETPLAN_SAVED['groups'] is None:
            G.plan.pop('set_groups', None)
        else:
            G.plan['set_groups'] = _SETPLAN_SAVED['groups']
        G.arc['set'] = _SETPLAN_SAVED['arc']
        for f, c in _SETPLAN_SAVED['cells'].items():
            S.CELLS[f].clear()
            S.CELLS[f].update(c)
        S.SET_PLAN = None
    GE.SCORES['symphony'].clear()
    GE.SCORES['symphony'].update(GE.symphony_table(setplan=on))


def _plan_flag(key: str, on: bool) -> None:
    """orchestra-symphonic's plan[key] (composer.set_plan's hook for a feature's set draw) on / off."""
    from . import genres as GE
    if on:
        GE.ORCHESTRA_SYMPHONIC.plan[key] = True
    else:
        GE.ORCHESTRA_SYMPHONIC.plan.pop(key, None)


def _tech(on: bool) -> None:
    """Round o23: symphony.TECH (the palette written into the parts), the set's technique draw with memory
    (plan['set_tech']: composer.set_plan) and the band's technique sounds (orch.TECH_SOUNDS: the brass mutes, the col
    legno / harmonics levels)."""
    from ..bandlib import orchestra as orch_
    from . import symphony as S
    S.TECH = dict(S.TECH_ON) if on else None
    orch_.TECH_SOUNDS = bool(on)
    _plan_flag('set_tech', on)


def _tech2(on: bool) -> None:
    """Round o24b / o25: TECH['v2'] (symphony.TECH_V2 - 3 techniques a piece, each featured at most twice a set, the
    pizzicato choir at most once per TECH_V2['pizz_gap'] slots, the trill's crown once a set; the pizzicato choir / col
    legno on the theme and the motto; the harmonics on the soft endings; the harp glissando into the climax) drawn per
    set slot (plan['set_tech2']: composer.set_plan -> symphony.tech2_slot). Rides on tech's palette (without it only
    the set draw)."""
    from . import symphony as S
    if S.TECH is not None:
        S.TECH = dict(S.TECH, v2=dict(S.TECH_V2), feature=S.TECH_V2['feature'], feature1=S.TECH_ON['feature']) \
            if on else dict({k: v for k, v in S.TECH.items() if k not in ('v2', 'feature1')},
                            feature=S.TECH_ON['feature'])
    _plan_flag('set_tech2', on)


def _shape(on: bool) -> None:
    """Round o25 SHAPE3: symphony.MACRO = MACRO3_ON (the macro shapes - the opening, the climax's place / count / kind,
    the ending, the aftermath after an early / mid climax a release and a second build, the chorale climax with the
    motto's rhythm, the late / cut climax by a shorter way) drawn per set slot (plan['set_macro'])."""
    from . import symphony as S
    S.MACRO = dict(S.MACRO3_ON) if on else None
    _plan_flag('set_macro', on)


def _choir(on: bool) -> None:
    """Round oc1, v2 since oc2: endless.choir.CHOIR = CHOIR_ON + CHOIR_V2 (the vocalset-choir pack's SATB choir as
    events - the summit, the lead-in, an a cappella, a halo, the coda; the theme sung, the gestures' set memory) and
    the set's plan draw with memory (plan['set_choir'])."""
    from . import choir as CH
    CH.CHOIR = dict(CH.CHOIR_ON, **CH.CHOIR_V2) if on else None
    _plan_flag('set_choir', on)


def _solo(on: bool) -> None:
    """Round os1: solo.SOLO (the exposed wind lines on the solo players, the string solo event, the concertmaster on
    the violins I's cantilena - symphony.build_symphony -> solo.solo_pass) and the set's solo-event draw with memory
    (plan['set_solo']: solo.solo_slot)."""
    from . import solo as SO
    SO.SOLO = dict(SO.SOLO_ON) if on else None
    _plan_flag('set_solo', on)


def _colour(on: bool) -> None:
    """Round ox1: endless.colour.COLOUR (per piece an organ, a classical guitar, a harpsichord, a celesta /
    glockenspiel or tubular bells the piece is built around) and the set's guest draw with memory
    (plan['set_guest'])."""
    from . import colour as CO
    CO.COLOUR = dict(CO.COLOUR_ON) if on else None
    _plan_flag('set_guest', on)


def _polish(on: bool) -> None:
    """Round op1 POLISH on top of CHOIR v2, SOLO and COLOUR: solo.SOLO['polish'] (the concertmaster's fader up, no
    parade of solo blocks, the cello event on the theme), colour.COLOUR['polish'] (the guest's returns and coda, the
    bells' hint, the signature gestures with the set's memory, the guitar piece's full orchestra, the cameo guests
    louder), choir.CHOIR['polish'] (the orchestra leaves the sung theme, the summit's texture with the set's memory,
    the summit capped at 2 per 8 slots, PLANS_POLISH, no short halo) and the title's form label with the set's memory
    (plan['set_polish']: composer.set_plan -> composer.title_slot / choir.choir_slot)."""
    from . import choir as CH, colour as CO, solo as SO
    if on:
        CH.CHOIR = dict(CH.CHOIR, polish=dict(CH.CHOIR_POLISH), caps=dict(CH.CHOIR_POLISH['caps']))
        SO.SOLO = dict(SO.SOLO, polish=dict(SO.SOLO_POLISH))
        CO.COLOUR = dict(CO.COLOUR, polish=dict(CO.COLOUR_POLISH))
    else:
        if CH.CHOIR and 'polish' in CH.CHOIR:
            CH.CHOIR = {k: v for k, v in CH.CHOIR.items() if k != 'polish'}
            CH.CHOIR['caps'] = dict(CH.CHOIR_V2['caps'])
        if SO.SOLO and 'polish' in SO.SOLO:
            SO.SOLO = {k: v for k, v in SO.SOLO.items() if k != 'polish'}
        if CO.COLOUR and 'polish' in CO.COLOUR:
            CO.COLOUR = {k: v for k, v in CO.COLOUR.items() if k != 'polish'}
    _plan_flag('set_polish', on)


def _pumping(on: bool) -> None:
    """The automatic phrase arc stacked over symphonic score dynamics reduced (symphony.PUMPING); performance only, so
    the same saved compose seed / plan can be used for an A/B."""
    from . import symphony as S
    S.PUMPING = dict(S.PUMPING_ON) if on else None


def _piano_diverse(on: bool) -> None:
    """Round p-div for new-age-piano: perform.PIANO_DIVERSE (the per-piece anti-template draws - the climax's left
    hand, the peak's place and kind, the ending gesture, the interlude from the theme) and with it run.candidates'
    selection (the score a gate, the set's memory choosing among the near-ties)."""
    from . import perform as P_
    P_.PIANO_DIVERSE = dict(P_.PIANO_DIVERSE_ON) if on else None


def _keyboard(on: bool) -> None:
    """Round pk1 for new-age-piano: perform.KEYBOARD (the ten-finger pianist - a return of the theme in the left
    hand's tenor under a right-hand figure, the left hand answering the right hand's held notes with the theme's
    head, the hands' octaves at the peak; on by default since round pk2). genres' import applies the defaults while
    composer / perform may still be importing: perform reads _PENDING when it gets there."""
    import sys
    _PENDING['keyboard'] = on
    P_ = sys.modules.get(__name__.rsplit('.', 1)[0] + '.perform')
    if P_ is not None and hasattr(P_, 'KEYBOARD_ON'):
        P_.KEYBOARD = dict(P_.KEYBOARD_ON) if on else None


def _payoff(on: bool) -> None:
    """Round pk4 for new-age-piano: perform.PAYOFF (the sung climax's statement / arrival / pause transformed, the
    climax's left hand drawn per piece) - a performance-side switch, the plan's draws stay."""
    import sys
    _PENDING['payoff'] = on
    P_ = sys.modules.get(__name__.rsplit('.', 1)[0] + '.perform')
    if P_ is not None and hasattr(P_, 'PAYOFF_ON'):
        P_.PAYOFF = dict(P_.PAYOFF_ON) if on else None


def _calm(on: bool) -> None:
    """Round ol1 (symphony.CALM): the block before a cliff join tapers into it (the climax's release keeps its step),
    and a role strikes a pitch once per onset (orch.Score.dedupe)."""
    from . import symphony as S
    S.CALM = dict(S.CALM_ON) if on else None


def _apart(on: bool) -> None:
    """Round ol4 (colour.APART, v2): a guest's again piece in a set - never in a feel the colour had, another ending
    gesture."""
    from . import colour as CO
    CO.APART = dict(CO.APART_ON) if on else None


_PENDING: dict = {}
"""A switch applied before its module finished importing (perform reads it there)."""
_SWITCH = {'setplan': _setplan, 'tech': _tech, 'choir': _choir, 'solo': _solo, 'colour': _colour, 'tech2': _tech2,
           'shape': _shape, 'polish': _polish, 'pumping': _pumping, 'piano_diverse': _piano_diverse,
           'payoff': _payoff, 'keyboard': _keyboard,
           'calm': _calm, 'apart': _apart}
