declare const init:(settings?:any)=>Promise<any>; export default init;
