import{readFileSync}from'node:fs';globalThis.__KINETIC_WASM__=readFileSync(new URL('../src/own-engine/kernel.wasm',import.meta.url));
