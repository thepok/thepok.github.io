import assert from 'node:assert/strict';
import * as THREE from 'three';
import {FragmentBatches} from '../src/fragment-batches.ts';

const batches=new FragmentBatches();
const position={GetX:()=>3,GetY:()=>5,GetZ:()=>7},rotation={GetX:()=>0,GetY:()=>0,GetZ:()=>0,GetW:()=>1};
const item=id=>({id,kind:'fragment',sourceKind:'slab',body:{GetPosition:()=>position,GetRotation:()=>rotation}});
function geometry(){const indexed=new THREE.BoxGeometry(.8,.3,.7),g=indexed.toNonIndexed();indexed.dispose();return g;}
const source=geometry(),expected=Array.from(source.attributes.position.array);source.dispose();
let items=Array.from({length:3000},(_,i)=>item(-i-1));
for(let round=0;round<3;round++){
 batches.begin(items);for(const fragment of items)batches.update(fragment,geometry,'#ab9080');batches.end();
 assert.equal(batches.refs.size,3000);
 const pool=batches.pools.get(false);assert.equal(pool.slots.length,3000,'replace entire budget without growing allocation');
 const ref=batches.refs.get(items[0].id),range=pool.mesh.getGeometryRangeAt(ref.slot.geometry),p=pool.mesh.geometry.attributes.position;
 assert.deepEqual(Array.from(p.array.slice(range.vertexStart*3,(range.vertexStart+36)*3)),expected,'exact original vertices retained');
 const matrix=new THREE.Matrix4();pool.mesh.getMatrixAt(ref.slot.instance,matrix);assert.deepEqual(new THREE.Vector3().setFromMatrixPosition(matrix).toArray(),[3,5,7]);
 const color=new THREE.Color();pool.mesh.getColorAt(ref.slot.instance,color);assert.equal(color.getHexString(),'ab9080');
 items=items.map(x=>item(x.id-3000));
}
batches.begin([]);batches.end();assert.equal(batches.refs.size,0);
for(const slot of batches.pools.get(false).slots)assert.equal(batches.pools.get(false).mesh.getVisibleAt(slot.instance),false);
batches.reset();assert.equal(batches.pools.get(false).free.length,3000);
console.log('PASS exact geometry, color, pose, full-budget recycling, disappeared fragment cleanup and reset');
