import {chromium} from '@playwright/test';
import {readFile,writeFile} from 'node:fs/promises';
const fixture=JSON.parse(await readFile('artifacts/bombardment/fixture.json','utf8')),shots=JSON.parse(await readFile('artifacts/bombardment/shots.json','utf8'));
const browser=await chromium.launch({channel:'chrome',headless:true});
const results=[],duration=Number(process.env.BENCH_BROWSER_SECONDS??10),variants=process.env.BENCH_BROWSER_VARIANTS==='both'?[false,true]:[false];
try{
for(const enabled of variants){
 const context=await browser.newContext({viewport:{width:1440,height:900}}),page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(fixture=>{localStorage.setItem('loadbearing-lab.demo-seen','1');localStorage.setItem('loadbearing-lab.last-mode',JSON.stringify({challengeId:'sandbox-demolition-yard'}));localStorage.setItem('loadbearing-lab.sandbox-demolition-yard',JSON.stringify(fixture));localStorage.setItem('loadbearing-lab.fragment-limit','3000');},fixture);
 await page.goto((process.env.TEST_URL||'http://localhost:5175/')+'?clusters='+(enabled?'1':'0'));await page.locator('#boot-screen').waitFor({state:'detached',timeout:60000});await page.click('#run');await page.waitForFunction(()=>window.__loadBearing.simulation?.elapsed>0,{},{timeout:120000});
 await page.evaluate(({shots,duration})=>{const d=window.__loadBearing,s=d.simulation;window.__bench={shots:0,rows:[],lastT:-1,start:performance.now(),done:false};const b=window.__bench;b.timer=setInterval(()=>{const t=s.elapsed;if(t===b.lastT)return;b.lastT=t;while(b.shots<shots.length&&shots[b.shots].time<=t){const shot=shots[b.shots++];s.launchProjectile(shot.position,shot.velocity,shot.mass,shot.radius);}b.rows.push({t,wall:(performance.now()-b.start)/1000,shots:b.shots,fragments:s.fragments,broken:s.broken,physicsMs:s.physicsMs,rate:s.rate,fps:d.scene.fps,clusters:s.clusters,timings:s.timings});if(t>=duration){clearInterval(b.timer);b.done=true;s.pause(true);}},16);},{shots,duration});
 let done=false;while(!done){await page.waitForTimeout(15000);const status=await page.evaluate(()=>{const b=window.__bench;return {done:b.done,last:b.rows.at(-1),mode:window.__loadBearing.simulation.mode,threads:window.__loadBearing.simulation.threads};});console.log(JSON.stringify({enabled,...status}));done=status.done;if(status.last?.wall>600)throw Error('Benchmark exceeded ten minutes for one browser run');}
 const data=await page.evaluate(()=>({rows:window.__bench.rows,mode:window.__loadBearing.simulation.mode,threads:window.__loadBearing.simulation.threads}));data.enabled=enabled;data.errors=errors;results.push(data);await page.mouse.move(700,400);await page.screenshot({path:'artifacts/bombardment/browser-'+(enabled?'on':'off')+'.png'});await writeFile('artifacts/bombardment/browser-results.json',JSON.stringify(results));await context.close();
}
}finally{await browser.close();}
