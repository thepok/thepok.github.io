import assert from 'node:assert/strict';
import { mkdir } from 'node:fs/promises';
import { build } from 'esbuild';

await mkdir('artifacts',{recursive:true});
await build({stdin:{contents:"export {generateDemolitionBuilding} from './src/procedural-buildings.ts'; export {validateBlueprint} from './src/catalog.ts';",resolveDir:process.cwd()},bundle:true,platform:'node',format:'esm',outfile:'artifacts/procedural-buildings.mjs'});
const {generateDemolitionBuilding,validateBlueprint}=await import('../artifacts/procedural-buildings.mjs?'+Date.now());
for(const target of [24,100,500,750,1000]){
 const result=generateDemolitionBuilding(target,12345+target);
 assert.equal(result.pieces.length,target);assert.equal(result.target,target);assert.ok(validateBlueprint({scenario:'sandbox',pieces:result.pieces}));assert.ok(result.cost<=1200000);assert.ok(result.height>=8&&result.height<=80);
 assert.equal(new Set(result.pieces.map(p=>`${p.kind}:${p.p.join(',')}:${p.rotation}`)).size,target,'no duplicate parts');
 console.log('PASS procedural',target,'parts',result.name,result.height+' m','$'+result.cost.toLocaleString());
}
