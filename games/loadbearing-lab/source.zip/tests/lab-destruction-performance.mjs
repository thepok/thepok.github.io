import { mkdir, writeFile } from 'node:fs/promises';
import { build } from 'esbuild';

await mkdir('artifacts', { recursive: true });

async function bundle(name, resolveDir) {
  const outfile = `artifacts/${name}.mjs`;
  await build({
    stdin: {
      contents: "export { Simulation, loadPhysics } from './src/physics.ts'; export { generateDemolitionBuilding } from './src/procedural-buildings.ts';",
      resolveDir,
    },
    bundle: true,
    platform: 'node',
    format: 'esm',
    external: ['jolt-physics'],
    outfile,
  });
  return import(`../${outfile}?${Date.now()}-${name}`);
}

function percentile(values, fraction) {
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.min(sorted.length - 1, Math.ceil(sorted.length * fraction) - 1)];
}

function snapshot(sim) {
  return {
    activeBodyCount: sim.items.filter(item => !item.fractured && item.body.IsActive?.()).length,
    totalBodyCount: sim.bodyList.length,
    activeJointCount: sim.joints.filter(joint => !joint.broken).length,
    activeRebarCount: sim.rebars.filter(link => !link.broken).length,
    fragments: sim.fragments,
  };
}

const root = await bundle('lab-destruction-root', '../..');
const experiment = await bundle('lab-destruction-experiment', '.');
const J = await root.loadPhysics();
const target = 1000;
const seed = 91210;
const generated = root.generateDemolitionBuilding(target, seed);
const lowerColumns = generated.pieces.filter(piece => piece.kind === 'column' && piece.p[1] === 0).slice(0, 8);
const rows = [];
for (const [label, api] of [['root', root], ['experiment', experiment]]) {
  const blueprint = api.generateDemolitionBuilding(target, seed).pieces;
  const sim = new api.Simulation(J, blueprint, 'sandbox', 1, { sandbox: true });
  for (let i = 0; i < 120; i++) sim.step(1 / 60);
  const before = snapshot(sim);
  for (const column of lowerColumns) {
    sim.launchProjectile([column.p[0], 8, column.p[2]], [0, -25, 0], 25000, .8);
  }
  const cpu = [];
  for (let i = 0; i < 120; i++) {
    sim.step(1 / 60);
    cpu.push(sim.physicsMs);
  }
  rows.push({
    label,
    requestedParts: blueprint.length,
    projectileCount: lowerColumns.length,
    projectileMassKg: 25000,
    before,
    after: snapshot(sim),
    medianPhysicsCpuMs: percentile(cpu, .5),
    p95PhysicsCpuMs: percentile(cpu, .95),
  });
  sim.dispose();
}

const baseline = rows[0], candidate = rows[1];
const report = {
  seed,
  settleSteps: 120,
  measuredSteps: 120,
  dt: 1 / 60,
  rows,
  relative: {
    medianPhysicsCpu: candidate.medianPhysicsCpuMs / baseline.medianPhysicsCpuMs - 1,
    p95PhysicsCpu: candidate.p95PhysicsCpuMs / baseline.p95PhysicsCpuMs - 1,
  },
};
await writeFile('artifacts/lab-destruction-performance.json', JSON.stringify(report, null, 2));
console.log(JSON.stringify(report, null, 2));
