import assert from 'node:assert/strict';
import { build } from 'esbuild';

await build({
  stdin: {
    contents: "export { Simulation, loadPhysics } from './src/physics.ts'; export { PARTS } from './src/catalog.ts';",
    resolveDir: process.cwd(),
  },
  bundle: true,
  platform: 'node',
  format: 'esm',
  external: ['jolt-physics'],
  outfile: 'artifacts/rigid-clusters.mjs',
});

const { Simulation, loadPhysics, PARTS } = await import('../artifacts/rigid-clusters.mjs?' + Date.now());
const J = await loadPhysics();

const column = (id, x, y, z) => ({ id, kind: 'column', p: [x, y, z], rotation: 0 });
const stack = (start, x, z, height = 4) => Array.from({ length: height }, (_, i) => column(start + i, x, i * 4, z));
const mass = items => items.reduce((sum, item) => sum + PARTS[item.kind].mass, 0);
const position = body => { const p = body.GetPosition(); return [p.GetX(), p.GetY(), p.GetZ()]; };
const velocity = body => { const p = body.GetLinearVelocity(); return [p.GetX(), p.GetY(), p.GetZ()]; };
const centerOfMass = body => { const p = body.GetCenterOfMassPosition(); return [p.GetX(), p.GetY(), p.GetZ()]; };
const angularVelocity = body => { const p = body.GetAngularVelocity(); return [p.GetX(), p.GetY(), p.GetZ()]; };
const quat = body => { const q = body.GetRotation(); return [q.GetX(), q.GetY(), q.GetZ(), q.GetW()]; };
const qmul = (a, b) => [a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1], a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0], a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3], a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2]];
const qrotate = (q, v) => { const p = [v[0], v[1], v[2], 0]; const qi = [-q[0], -q[1], -q[2], q[3]]; const r = qmul(qmul(q, p), qi); return r.slice(0, 3); };
const add = (a, b) => a.map((v, i) => v + b[i]);
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const close = (a, b, epsilon = 1e-4) => assert.ok(a.every((value, axis) => Math.abs(value - b[axis]) <= epsilon), `${a} != ${b}`);
const clusterRules = { sandbox: true, duration: 120, rigidClusters: true };

// The anchored control component must remain represented by its original bodies.
{
  const sim = new Simulation(J, [
    { id: 1, kind: 'foundation', p: [0, 0, 0], rotation: 0 },
    ...stack(10, 0, 0, 3),
  ], 'sandbox', 1, clusterRules);
  sim.clusters?.discover();
  const groups = sim.clusters?.groups;
  assert.ok(groups instanceof Set, 'discover() must return a Set');
  assert.equal(groups.size, 0, 'a component with a ground anchor must not cluster');
  sim.dispose();
}

// Three or more connected unsupported originals form a cluster with conserved mass.
{
  const pieces = stack(100, 12, 8, 4);
  const sim = new Simulation(J, pieces, 'sandbox', 1, clusterRules);
  sim.clusters?.discover();
  const groups = sim.clusters?.groups;
  assert.equal(groups?.size, 1, 'one unsupported connected component should cluster');
  const group = [...groups][0];
  assert.equal(group.members.length, pieces.length);
  assert.ok(Math.abs(group.mass - mass(pieces)) < 1e-3, 'aggregate mass must equal member mass');
  assert.ok(group.joints.length >= pieces.length - 1, 'internal joints must be retained for release');
  assert.ok(group.body, 'cluster must have an aggregate body');

  const before = group.members.map(member => position(member.item.body));
  const memberRotations = group.members.map(member => quat(member.item.body));
  sim.clusters.sync();
  const afterSync = group.members.map(member => position(member.item.body));
  before.forEach((pose, i) => close(afterSync[i], pose));

  const aggregate = group.body.GetPosition();
  const moved = new J.RVec3(aggregate.GetX() + 2, aggregate.GetY() + 1, aggregate.GetZ() - 3);
  const rotation = new J.Quat(0, Math.sin(Math.PI / 8), 0, Math.cos(Math.PI / 8));
  sim.bodies.SetPositionAndRotation(group.body.GetID(), moved, rotation, J.EActivation_Activate);
  J.destroy(moved);
  sim.clusters.sync();
  const aggregatePosition = position(group.body), aggregateRotation = quat(group.body);
  group.members.forEach((member, i) => {
    const expectedPosition = add(aggregatePosition, qrotate(aggregateRotation, member.localPosition));
    close(position(member.item.body), expectedPosition, 2e-3);
    const expectedRotation = qmul(aggregateRotation, member.localRotation);
    close(quat(member.item.body), expectedRotation, 2e-3);
    assert.notDeepEqual(memberRotations[i], quat(member.item.body), 'rotation must follow aggregate rotation');
  });

  const linear = [1.5, -0.25, 2.25], angular = [0.2, 0.4, -0.3];
  const aggregateCom = centerOfMass(group.body);
  const releaseOffsets = group.members.map(member => {
    const p = centerOfMass(member.item.body);
    return p.map((value, axis) => value - aggregateCom[axis]);
  });
  const lv = new J.Vec3(...linear), av = new J.Vec3(...angular);
  group.body.SetLinearVelocity(lv); group.body.SetAngularVelocity(av);
  J.destroy(lv); J.destroy(av);

  sim.clusters.release(group.members[0].item);
  assert.equal(sim.clusters.groups.size, 0);
  group.members.forEach((member, i) => {
    assert.ok(member.item.body.GetID(), 'released member keeps its original body');
    const r = releaseOffsets[i];
    close(velocity(member.item.body), add(linear, cross(angular, r)), 2e-3);
    close(angularVelocity(member.item.body), angular, 2e-3);
    assert.equal(member.item.body.IsInBroadPhase(), true, 'released member returns to the broad phase');
  });
  assert.ok(group.joints.every(joint => !joint.broken), 'release retains intact joints');
  sim.dispose();
}

// A formerly anchored section becomes eligible only after its ground joint is broken.
{
  const sim = new Simulation(J, [
    { id: 1, kind: 'foundation', p: [0, 0, 0], rotation: 0 },
    ...stack(10, 0, 0, 4),
  ], 'sandbox', 1, clusterRules);
  sim.clusters.discover();
  assert.equal(sim.clusters.groups.size, 0);
  const groundJoint = sim.joints.find(joint => !joint.b && joint.a.id === 1);
  assert.ok(groundJoint, 'foundation must have a ground anchor');
  const detachment = sim.joints.find(joint => joint.b && (joint.a.id === 1 || joint.b.id === 1));
  assert.ok(detachment, 'foundation must connect to the stack');
  sim.breakJoint(detachment);
  sim.removeRebars(sim.items.find(item => item.id === 1));
  for (let i = 0; i < 20; i++) sim.step(1 / 60);
  sim.clusters.discover();
  assert.equal(sim.clusters.groups.size, 1, 'detached stack becomes clusterable after anchor loss');
  sim.dispose();
}

// Fracture must release the complete aggregate before targeting one original member.
{
  const sim = new Simulation(J, stack(500, 20, 20, 4), 'sandbox', 1, clusterRules);
  sim.clusters.discover();
  const group = [...sim.clusters.groups][0];
  assert.equal(group.members.length, 4);
  const target = group.members[1].item;
  sim.fracture(target, [target.initial[0], target.initial[1] + 2, target.initial[2]]);
  assert.equal(sim.clusters.groups.size, 0, 'fracture must release its whole cluster');
  assert.equal(target.fractured, true, 'the requested member must fracture');
  assert.ok(group.members.filter(member => member.item !== target).every(member => !member.item.fractured), 'neighboring members remain intact');
  sim.dispose();
}

// A repeatable A/B profile exercises the production timing contract while avoiding
// machine-specific pass/fail cutoffs. The clustered run must expose all timing
// buckets and retain the same deterministic component inventory.
{
  const makePieces = () => {
    const pieces = [];
    let id = 1000;
    for (let x = -24; x <= 24; x += 4) for (let z = -24; z <= 24; z += 4) {
      pieces.push(...stack(id, x, z, 4));
      id += 4;
    }
    return pieces;
  };
  const pieces = makePieces();
  assert.ok(pieces.length >= 500 && pieces.length <= 1000);
  const run = (rigidClusters) => {
    const sim = new Simulation(J, structuredClone(pieces), 'sandbox', 1, { ...clusterRules, rigidClusters });
    sim.clusters?.discover();
    for (let i = 0; i < 8; i++) sim.step(1 / 60);
    const result = { bodies: sim.bodyList.filter(body => body.IsInBroadPhase()).length, groups: sim.clusters?.groups.size ?? 0, timings: sim.timings };
    sim.dispose();
    return result;
  };
  const plain = run(false);
  const clustered = run(true);
  for (const [label, timings] of [['plain', plain.timings], ['clustered', clustered.timings]]) {
    assert.ok(timings && Number.isFinite(timings.jolt), `${label} timings.jolt`);
    assert.ok(Number.isFinite(timings.damage), `${label} timings.damage`);
    assert.ok(Number.isFinite(timings.other), `${label} timings.other`);
    assert.ok(Number.isFinite(timings.clusters), `${label} timings.clusters`);
    assert.ok(Number.isFinite(timings.total), `${label} timings.total`);
  }
  assert.equal(plain.groups, 0);
  assert.ok(clustered.groups > 0, 'deterministic unsupported stacks should produce clusters');
  assert.ok(clustered.bodies < plain.bodies, 'clustering should reduce active body count');
  console.log(JSON.stringify({ plain, clustered }));
}

console.log('Rigid cluster checks passed.');
