import {build} from 'esbuild';
await build({stdin:{contents:"export {Simulation,loadPhysics} from './src/physics.ts';export {generateDemolitionBuilding} from './src/procedural-buildings.ts'",resolveDir:process.cwd()},bundle:true,platform:'node',format:'esm',external:['jolt-physics'],outfile:'artifacts/cluster-profile.mjs'});
const {Simulation,loadPhysics,generateDemolitionBuilding}=await import('../artifacts/cluster-profile.mjs');const J=await loadPhysics();
for(const count of [Number(process.env.PARTS??1000)]){
const design=generateDemolitionBuilding(count,72000,'art-deco').pieces.filter(p=>p.kind!=='foundation').map(p=>({...p,p:[p.p[0],p.p[1]+200,p.p[2]]}));
for(const enabled of [false,true]){
const sim=new Simulation(J,structuredClone(design),'sandbox',1,{sandbox:true,rigidClusters:enabled,fragmentLimit:1000});const samples=[];let saved=0;
for(let i=0;i<120;i++){sim.step(1/60);saved=Math.max(saved,sim.clusters?.stats.savedBodies??0);if(i>=30)samples.push({...sim.timings});}
const median=k=>samples.map(s=>s[k]).sort((a,b)=>a-b)[Math.floor(samples.length/2)];console.log(JSON.stringify({count:design.length,enabled,saved,stats:sim.clusters?.stats,broken:sim.broken,jolt:median('jolt'),damage:median('damage'),clusters:median('clusters'),total:median('total')}));sim.dispose();
}}
