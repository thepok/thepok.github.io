import { mkdir, writeFile } from 'node:fs/promises';
import { build } from 'esbuild';

await mkdir('artifacts', { recursive: true });

async function bundle(name, resolveDir) {
  const outfile = `artifacts/${name}.mjs`;
  await build({
    stdin: {
      contents: "export { Simulation, loadPhysics } from './src/physics.ts'; export { generateDemolitionBuilding } from './src/procedural-buildings.ts';",
      resolveDir,
    },
    bundle: true,
    platform: 'node',
    format: 'esm',
    external: ['jolt-physics'],
    outfile,
  });
  return import(`../${outfile}?${Date.now()}-${name}`);
}

function median(values) {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

function percentile(values, fraction) {
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.min(sorted.length - 1, Math.ceil(sorted.length * fraction) - 1)];
}

const root = await bundle('lab-performance-root', '../..');
const experiment = await bundle('lab-performance-experiment', '.');
const J = await root.loadPhysics();
const warmupSteps = 120;
const measuredSteps = 60;
const rows = [];
for (const target of [500, 1000]) {
  const seed = 90210 + target;
  const measurements = {};
  for (const [label, api] of [['root', root], ['experiment', experiment]]) {
    const generated = api.generateDemolitionBuilding(target, seed);
    const sim = new api.Simulation(J, generated.pieces, 'sandbox', 1, { sandbox: true });
    for (let i = 0; i < warmupSteps; i++) sim.step(1 / 60);
    const cpu = [];
    for (let i = 0; i < measuredSteps; i++) {
      // Keep the solver's active-body path exercised without injecting velocity
      // or impulses that would make the two geometry copies diverge.
      for (const item of sim.items) if (item.id > 0 && !item.fractured) sim.bodies.ActivateBody(item.body.GetID());
      sim.step(1 / 60);
      cpu.push(sim.physicsMs);
    }
    measurements[label] = {
      requested: target,
      pieces: generated.pieces.length,
      bodyCount: sim.bodyList.length,
      jointCount: sim.joints.length,
      medianPhysicsCpuMs: median(cpu),
      p95PhysicsCpuMs: percentile(cpu, .95),
    };
    sim.dispose();
  }
  rows.push({
    target,
    root: measurements.root,
    experiment: measurements.experiment,
    bodyDelta: measurements.experiment.bodyCount - measurements.root.bodyCount,
    jointDelta: measurements.experiment.jointCount - measurements.root.jointCount,
    medianPhysicsCpuRelativeOverhead: measurements.root.medianPhysicsCpuMs === 0
      ? null
      : measurements.experiment.medianPhysicsCpuMs / measurements.root.medianPhysicsCpuMs - 1,
    p95PhysicsCpuRelativeOverhead: measurements.root.p95PhysicsCpuMs === 0
      ? null
      : measurements.experiment.p95PhysicsCpuMs / measurements.root.p95PhysicsCpuMs - 1,
  });
}

const report = {
  seedFormula: '90210 + requestedParts',
  warmupSteps,
  measuredSteps,
  dt: 1 / 60,
  rows,
};
await writeFile('artifacts/lab-performance.json', JSON.stringify(report, null, 2));
console.log(JSON.stringify(report, null, 2));
