import {build} from 'esbuild';
import assert from 'node:assert/strict';
await build({stdin:{contents:"export {Simulation,loadPhysics} from './src/physics';export {generateDemolitionBuilding} from './src/procedural-buildings';",resolveDir:process.cwd()},bundle:true,platform:'node',format:'esm',external:['jolt-physics'],outfile:'artifacts/rebar-barrage-module.mjs'});
const {Simulation,loadPhysics,generateDemolitionBuilding}=await import('../artifacts/rebar-barrage-module.mjs'),J=await loadPhysics();
const sim=new Simulation(J,generateDemolitionBuilding(300,90210,'art-deco').pieces,'sandbox',1,{sandbox:true,fragmentLimit:3000});
sim.settleStartup();
try {
 for(let n=0;n<8;n++){
  assert.ok(sim.launchProjectile([0,20,-70],[0,0,165],1,1,'storey',false,{parts:64,concreteStrength:1,reinforcement:1}));
  for(let k=0;k<90;k++){
   sim.step(1/60);
   for(const l of sim.rebars){if(l.broken)continue;const a=sim.bodyWorldPoint(l.a,l.localA),b=sim.bodyWorldPoint(l.b,l.localB),d=Math.hypot(...a.map((v,i)=>v-b[i]));
    assert.ok(d<=l.limit+.051,`Rebar stretched to ${d} m after shot ${n+1}, step ${k}`);
   }
  }
  console.log(`PASS shot ${n+1}: no overstretched rebar, ${sim.fragments} fragments`);
 }
}finally{sim.dispose()}

