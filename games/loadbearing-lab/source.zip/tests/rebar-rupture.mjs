import assert from 'node:assert/strict';
import {build} from 'esbuild';
await build({stdin:{contents:"export {Simulation,loadPhysics} from './src/physics'",resolveDir:process.cwd()},bundle:true,platform:'node',format:'esm',external:['jolt-physics'],outfile:'artifacts/rebar-rupture.mjs'});
const {Simulation,loadPhysics}=await import('../artifacts/rebar-rupture.mjs?'+Date.now()),J=await loadPhysics();
const sim=new Simulation(J,[],'sandbox',1,{sandbox:true});
try {
 const a=sim.dynamicBox([-1,'column'],[0,10,0],[.2,.2,.2],10),b=sim.dynamicBox([-2,'column'],[0,10.2,0],[.2,.2,.2],10);
 sim.createRebar(a,b,[0,10.1,0],[0,10.1,0],.18,140000);
 const link=sim.rebars.at(-1);
 assert.equal(link.constraint.GetTotalLambdaPosition(),0,'Fresh constraint has no solver impulse');
 sim.updateRebars(1/60);assert.equal(link.broken,false,'Healthy steel remains connected');
 const move=x=>{const p=new J.RVec3(x,10.2,0),q=new J.Quat(0,0,0,1);sim.bodies.SetPositionAndRotation(b.body.GetID(),p,q,J.EActivation_Activate);J.destroy(p);J.destroy(q);};
 move(.03);sim.updateRebars(1/60);assert.equal(link.broken,false,'Small deformation is allowed');
 move(10);assert.equal(link.constraint.GetTotalLambdaPosition(),0);sim.updateRebars(1/60);
 assert.equal(link.broken,true,'Steel tears by extension even without a solver impulse');
 assert.equal(a.rebarLinks.length,0,'Broken visual connection removed');
 const count=sim.rebars.length;
 sim.createRebar(a,b,[0,10.1,0],[10,10.1,0],.18,140000);
 assert.equal(sim.rebars.length,count,'Do not reconnect already separated fracture faces');
 console.log('PASS healthy rebar, small deformation, zero-impulse rupture, no distant reattachment');
}finally{sim.dispose()}
