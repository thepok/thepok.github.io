import {build} from 'esbuild';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import os from 'node:os';
import {spawn} from 'node:child_process';
const out='artifacts/bombardment';await mkdir(out,{recursive:true});
if(!process.env.BENCH_VARIANT){
 for(const variant of ['off','on'])await new Promise((resolve,reject)=>{const child=spawn(process.execPath,[process.argv[1]],{stdio:'inherit',env:{...process.env,BENCH_VARIANT:variant}});child.on('error',reject);child.on('exit',code=>{console.log(JSON.stringify({event:'process-exit',variant,code}));resolve();});});
 const reports=await Promise.all(['off','on'].map(async variant=>JSON.parse(await readFile(out+'/'+variant+'-results.json','utf8'))));
 await writeFile(out+'/results.json',JSON.stringify({...reports[0],runs:reports.flatMap(r=>r.runs)},null,2));process.exit(reports.some(r=>r.runs.some(run=>!run.completed))?1:0);
}

await build({stdin:{contents:"export {Simulation,loadPhysics} from './src/physics.ts';export {generateDemolitionBuilding} from './src/procedural-buildings.ts';export {PARTS} from './src/catalog.ts';",resolveDir:process.cwd()},bundle:true,platform:'node',format:'esm',external:['jolt-physics'],outfile:out+'/engine.mjs'});
const {Simulation,loadPhysics,generateDemolitionBuilding,PARTS}=await import('../'+out+'/engine.mjs?run='+Date.now());
const config={parts:1000,seed:72000,style:'art-deco',fragmentLimit:3000,shots:120,shotInterval:.15,firstShot:1,duration:25,dt:1/60,mass:10000,speed:100,radius:.75};
const design=generateDemolitionBuilding(config.parts,config.seed,config.style),pieces=design.pieces;
const centers=pieces.filter(p=>p.kind!=='foundation').map(p=>{const c=PARTS[p.kind].segments[0].center,a=p.rotation*Math.PI/2;return {id:p.id,kind:p.kind,p:[p.p[0]+c[0]*Math.cos(a)+c[2]*Math.sin(a),p.p[1]+c[1],p.p[2]-c[0]*Math.sin(a)+c[2]*Math.cos(a)]};});
const xs=centers.map(p=>p.p[0]),zs=centers.map(p=>p.p[2]),cx=(Math.min(...xs)+Math.max(...xs))/2,cz=(Math.min(...zs)+Math.max(...zs))/2,range=Math.max(Math.max(...xs)-Math.min(...xs),Math.max(...zs)-Math.min(...zs))*.75+22;
const low=centers.filter(p=>p.p[1]<12&&p.kind!=='facade');
const shots=Array.from({length:config.shots},(_,i)=>{const angle=i*2.399963229728653,target=i<30?low[(i*17)%low.length].p:i<70?centers[(i*37)%centers.length].p:[cx+Math.sin(i*1.7)*8,1+(i%3),cz+Math.cos(i*2.3)*8];const position=[cx+Math.cos(angle)*range,target[1]+3,cz+Math.sin(angle)*range],d=target.map((n,k)=>n-position[k]),len=Math.hypot(...d);return {time:config.firstShot+i*config.shotInterval,position,velocity:d.map(n=>n/len*config.speed),mass:config.mass,radius:config.radius};});
await writeFile(out+'/fixture.json',JSON.stringify({version:1,scenario:'sandbox',challengeId:'sandbox-demolition-yard',intensity:1,pieces}));await writeFile(out+'/shots.json',JSON.stringify(shots));
const hash=createHash('sha256');for(const file of ['src/physics.ts','src/rigid-clusters.ts','src/local-fracture.ts','src/catalog.ts'])hash.update(await readFile(file));
const result={config,building:{name:design.name,parts:pieces.length,height:design.height},metadata:{runtime:process.version,engine:JSON.parse(await readFile('../../node_modules/jolt-physics/package.json','utf8')).version,execution:'single-thread WASM in Node; no rendering or worker transport',cpu:os.cpus()[0]?.model,sourceHash:hash.digest('hex'),created:new Date().toISOString()},runs:[]};
const J=await loadPhysics(),quantile=(rows,key,q)=>{const a=rows.map(r=>r[key]).sort((a,b)=>a-b);return a[Math.floor((a.length-1)*q)]??0;};
for(const enabled of [process.env.BENCH_VARIANT==='on']){
 const sim=new Simulation(J,structuredClone(pieces),'sandbox',1,{sandbox:true,rigidClusters:enabled,fragmentLimit:config.fragmentLimit}),startup=await sim.settleStartup();
 let bucket={};for(const key of ['updateRebars','fractureProjectileImpacts','fractureGroundImpacts','updateGlassDamage']){const original=sim[key].bind(sim);sim[key]=(...args)=>{const start=performance.now();try{return original(...args);}finally{bucket[key]=(bucket[key]??0)+performance.now()-start;}};}
 let failure,cleanupFailure,allocatedAtEnd=0;const rows=[];let next=0,lastLog=performance.now();console.log(JSON.stringify({event:'start',clusters:enabled,startup,parts:pieces.length}));
 try{
  if(!startup?.quiet||pieces.length!==1000||!sim.joints.some(j=>!j.b))throw Error('Benchmark requires a settled anchored 1000-part building');
  for(let frame=0;frame<Math.round(config.duration/config.dt);frame++){
   while(next<shots.length&&shots[next].time<=sim.elapsed+1e-7){const shot=shots[next++];sim.launchProjectile(shot.position,shot.velocity,shot.mass,shot.radius);}
   bucket={};sim.step(config.dt);
   const row={t:sim.elapsed,phase:sim.elapsed<config.firstShot?'idle':sim.elapsed<config.firstShot+70*config.shotInterval?'structure fire':sim.elapsed<config.firstShot+config.shots*config.shotInterval?'rubble fire':'settling',...sim.timings,...bucket,allocatedBodies:sim.bodyList.length,debris:sim.fragments,awake:sim.system.GetNumActiveBodies(J.EBodyType_RigidBody),bodies:sim.bodyList.filter(b=>b.IsInBroadPhase()).length,broken:sim.broken,fractured:sim.items.filter(i=>i.id>0&&i.fractured).length,rebars:sim.rebars.filter(r=>!r.broken).length,groups:sim.clusters?.groups.size??0,saved:sim.clusters?.stats.savedBodies??0,shots:next};rows.push(row);
   if(performance.now()-lastLog>12000){lastLog=performance.now();console.log(JSON.stringify({event:'progress',clusters:enabled,t:+row.t.toFixed(1),shots:next,debris:row.debris,broken:row.broken,stepMs:+row.total.toFixed(1)}));await writeFile(out+'/'+(enabled?'on':'off')+'-progress.json',JSON.stringify(row));await writeFile(out+'/'+(enabled?'on':'off')+'-steps.json',JSON.stringify(rows));}
   if(frame%60===59)await new Promise(r=>setTimeout(r,0));
  }
 }catch(error){failure={message:error.message,stack:error.stack,elapsed:sim.elapsed,shots:next,allocatedBodies:sim.bodyList.length,fragments:sim.fragments};console.log(JSON.stringify({event:'failure',...failure}));}finally{allocatedAtEnd=sim.bodyList.length;try{sim.dispose();}catch(error){cleanupFailure=error.stack;}}
  const phases=Object.fromEntries([...new Set(rows.map(r=>r.phase))].map(phase=>{const r=rows.filter(row=>row.phase===phase),sum=r.reduce((n,x)=>n+x.total,0);return [phase,{steps:r.length,medianMs:quantile(r,'total',.5),p95Ms:quantile(r,'total',.95),maxMs:Math.max(...r.map(x=>x.total)),physicsThroughput:r.length*config.dt/(sum/1000),joltShare:r.reduce((n,x)=>n+x.jolt,0)/sum,meanJoltMs:r.reduce((n,x)=>n+x.jolt,0)/r.length,meanDamageMs:r.reduce((n,x)=>n+x.damage,0)/r.length,meanRebarCheckMs:r.reduce((n,x)=>n+x.updateRebars,0)/r.length,meanProjectileDamageMs:r.reduce((n,x)=>n+x.fractureProjectileImpacts,0)/r.length}];}));
  const summary={enabled,startup,completed:!failure,failure,cleanupFailure,allocatedAtEnd,phases,peakDebris:Math.max(...rows.map(r=>r.debris)),peakActiveBodies:Math.max(...rows.map(r=>r.awake)),peakRebars:Math.max(...rows.map(r=>r.rebars)),maxSavedBodies:Math.max(...rows.map(r=>r.saved)),final:rows.at(-1)};result.runs.push(summary);await writeFile(out+'/'+(enabled?'on':'off')+'-steps.json',JSON.stringify(rows));await writeFile(out+'/'+(enabled?'on':'off')+'-results.json',JSON.stringify(result,null,2));console.log(JSON.stringify({event:'complete',...summary}));if(failure)process.exitCode=1;
}
