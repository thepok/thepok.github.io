import type { V3 } from './catalog';

export interface WalkerControls {
  forward: number;
  right: number;
  yaw: number;
  run: boolean;
  jump: boolean;
}

export interface WalkerSnapshot {
  /** The character's feet position in world space. */
  position: V3;
  velocity: V3;
  yaw: number;
  grounded: boolean;
}

/**
 * A small gameplay wrapper around Jolt's CharacterVirtual. The wrapper owns
 * only the character and query filters; the simulation owns the physics world.
 */
export class WalkerPhysics {
  readonly controls: WalkerControls = { forward: 0, right: 0, yaw: 0, run: false, jump: false };

  private readonly J: any;
  private readonly character: any;
  private readonly shape: any;
  private readonly broadPhaseFilter: any;
  private readonly objectLayerFilter: any;
  private readonly bodyFilter: any;
  private readonly shapeFilter: any;
  private readonly extended: any;
  private readonly allocator: any;
  private readonly gravity: any;
  private readonly desired: any;
  private readonly jumpVelocity = 5.8;
  private readonly walkSpeed = 4.2;
  private readonly runSpeed = 7.0;
  private jumpLatch = false;
  private dead = false;
  private spawn: V3;
  private yaw = 0;

  constructor(public readonly sim: any, spawn: V3) {
    this.J = sim.J;
    this.spawn = [...spawn] as V3;
    const J = this.J;
    const system = sim.system;

    // Capsule total height is 2 * half-cylinder + 2 * radius = 1.75 m.
    // The shape offset makes CharacterVirtual's position the feet position.
    const radius = 0.28;
    const halfCylinder = 0.595;
    const capsuleSettings = new J.CapsuleShapeSettings(halfCylinder, radius);
    const shapeResult = capsuleSettings.Create();
    if (!shapeResult.IsValid?.()) {
      J.destroy(capsuleSettings);
      J.destroy(shapeResult);
      throw new Error('Unable to create walker capsule shape');
    }
    this.shape = shapeResult.Get();
    this.shape.AddRef();
    J.destroy(shapeResult);
    J.destroy(capsuleSettings);

    const settings = new J.CharacterVirtualSettings();
    settings.mShape = this.shape;
    settings.mShapeOffset.Set(0, 0.875, 0);
    settings.mUp.Set(0, 1, 0);
    settings.mMaxSlopeAngle = Math.PI / 3;
    settings.mMass = 80;
    settings.mMaxStrength = 1000;
    settings.mPredictiveContactDistance = 0.05;

    const position = new J.RVec3(...this.spawn);
    const rotation = new J.Quat(0, 0, 0, 1);
    this.character = new J.CharacterVirtual(settings, position, rotation, system);
    J.destroy(position);
    J.destroy(rotation);
    J.destroy(settings);

    const objectVsBroadPhase = sim.world.GetObjectVsBroadPhaseLayerFilter();
    const objectPair = sim.world.GetObjectLayerPairFilter();
    this.broadPhaseFilter = new J.DefaultBroadPhaseLayerFilter(objectVsBroadPhase, 1);
    this.objectLayerFilter = new J.DefaultObjectLayerFilter(objectPair, 1);
    this.bodyFilter = new J.BodyFilter();
    this.shapeFilter = new J.ShapeFilter();
    this.extended = new J.ExtendedUpdateSettings();
    this.extended.mStickToFloorStepDown.Set(0, -0.3, 0);
    this.extended.mWalkStairsStepUp.Set(0, 0.23, 0);
    this.extended.mWalkStairsMinStepForward = 0.02;
    this.extended.mWalkStairsStepForwardTest = 0.16;
    this.extended.mWalkStairsStepDownExtra.Set(0, -0.02, 0);
    this.allocator = sim.world.GetTempAllocator();
    this.gravity = new J.Vec3(0, 0, 0);
    this.desired = new J.Vec3(0, 0, 0);
  }

  step(dt: number): void {
    if (this.dead) return;
    const c = this.controls;
    const forward = Math.max(-1, Math.min(1, c.forward));
    const right = Math.max(-1, Math.min(1, c.right));
    const length = Math.hypot(forward, right);
    const scale = length > 1 ? 1 / length : 1;
    const f = forward * scale;
    const r = right * scale;
    const sy = Math.sin(c.yaw), cy = Math.cos(c.yaw);
    const speed = c.run ? this.runSpeed : this.walkSpeed;
    const g = this.sim.system.GetGravity();
    this.gravity.Set(g.GetX(), g.GetY(), g.GetZ());
    // CharacterVirtual expects the caller to integrate gravity into its
    // velocity before ExtendedUpdate. Keep support contacts stable by
    // clearing downward velocity while grounded.
    this.character.UpdateGroundVelocity?.();
    const velocity = this.character.GetLinearVelocity();
    const grounded = this.character.IsSupported();
    const support=this.character.GetGroundVelocity();const gx=grounded?support.GetX():0,gz=grounded?support.GetZ():0;
    let vertical = grounded ? support.GetY() : velocity.GetY() + this.gravity.GetY() * dt;
    if (c.jump && !this.jumpLatch && grounded) vertical = this.jumpVelocity;
    this.jumpLatch = c.jump;
    this.desired.Set((sy * f + cy * r) * speed+gx, vertical, (-cy * f + sy * r) * speed+gz);
    this.character.SetLinearVelocity(this.desired);

    this.character.ExtendedUpdate(dt, this.gravity, this.extended, this.broadPhaseFilter,
      this.objectLayerFilter, this.bodyFilter, this.shapeFilter, this.allocator);
    this.yaw = c.yaw;
  }

  snapshot(): WalkerSnapshot {
    const p = this.character.GetPosition();
    const v = this.character.GetLinearVelocity();
    return {
      position: [p.GetX(), p.GetY(), p.GetZ()],
      velocity: [v.GetX(), v.GetY(), v.GetZ()],
      yaw: this.yaw,
      grounded: this.character.IsSupported(),
    };
  }

  reset(spawn: V3): void {
    if (this.dead) return;
    this.spawn = [...spawn] as V3;
    const p = new this.J.RVec3(...spawn);
    this.character.SetPosition(p);
    this.J.destroy(p);
    this.desired.Set(0, 0, 0);
    this.character.SetLinearVelocity(this.desired);
    this.jumpLatch = false;
  }

  dispose(): void {
    if (this.dead) return;
    this.dead = true;
    const J = this.J;
    J.destroy(this.character);
    J.destroy(this.extended);
    J.destroy(this.broadPhaseFilter);
    J.destroy(this.objectLayerFilter);
    J.destroy(this.bodyFilter);
    J.destroy(this.shapeFilter);
    J.destroy(this.gravity);
    J.destroy(this.desired);
    this.shape.Release();
  }
}


