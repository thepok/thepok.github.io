import * as THREE from 'three';
import { MeshBasicNodeMaterial } from 'three/webgpu';
import { attribute, uniform, positionLocal, vec3, float, max, sin, smoothstep, instancedArray, instanceIndex, Fn, If } from 'three/tsl';

type Backend = 'webgpu' | 'webgl';

/** Bounded visual-only debris. Physics remains authoritative in Jolt. */
export class GpuDebris {
  readonly capacity = 4096;
  readonly mesh: THREE.InstancedMesh;
  readonly time = uniform(0);
  private next = 0;
  private births: Float32Array;
  private velocities: Float32Array;
  private seeds: Float32Array;
  private floors: Float32Array;
  private birthAttribute: THREE.InstancedBufferAttribute;
  private velocityAttribute: THREE.InstancedBufferAttribute;
  private seedAttribute: THREE.InstancedBufferAttribute;
  private floorAttribute: THREE.InstancedBufferAttribute;
  private gpuPosition:any; private gpuVelocity:any; private gpuAge:any; private gpuFloor:any; private gpuCompute:any; private gpuDt:any;

  constructor(backend: Backend) {
    const geometry = new THREE.IcosahedronGeometry(.07, 0);
    this.births = new Float32Array(this.capacity);
    this.velocities = new Float32Array(this.capacity * 3);
    this.seeds = new Float32Array(this.capacity);
    this.floors = new Float32Array(this.capacity);
    this.birthAttribute = new THREE.InstancedBufferAttribute(this.births, 1);
    this.velocityAttribute = new THREE.InstancedBufferAttribute(this.velocities, 3);
    this.seedAttribute = new THREE.InstancedBufferAttribute(this.seeds, 1);
    this.floorAttribute = new THREE.InstancedBufferAttribute(this.floors, 1);
    if (backend === 'webgpu') {
      this.gpuPosition=instancedArray(this.capacity,'vec3'); this.gpuVelocity=instancedArray(this.capacity,'vec3'); this.gpuAge=instancedArray(this.capacity,'float');this.gpuFloor=instancedArray(this.capacity,'float'); this.gpuDt=uniform(0);
      this.gpuCompute=Fn(()=>{const i=instanceIndex,p=this.gpuPosition.element(i),v=this.gpuVelocity.element(i),a=this.gpuAge.element(i);If(a.greaterThan(0),()=>{const nextV=v.add(vec3(0,this.gpuDt.mul(-14),0)).toVar(),nextP=p.add(nextV.mul(this.gpuDt)).toVar();If(nextP.y.lessThan(this.gpuFloor.element(i)),()=>{nextP.y.assign(this.gpuFloor.element(i));nextV.y.assign(nextV.y.mul(-.24));});p.assign(nextP);v.assign(nextV);a.assign(a.add(this.gpuDt));});})().compute(this.capacity);
    }
    geometry.setAttribute('debrisBirth', this.birthAttribute);
    geometry.setAttribute('debrisVelocity', this.velocityAttribute);
    geometry.setAttribute('debrisSeed', this.seedAttribute);
    geometry.setAttribute('debrisFloor', this.floorAttribute);
    const material = backend === 'webgpu' ? this.nodeMaterial() : this.webglMaterial();
    this.mesh = new THREE.InstancedMesh(geometry, material, this.capacity);
    this.mesh.frustumCulled = false;
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.mesh.count = 0;
    this.mesh.renderOrder = 4;
  }

  private nodeMaterial(): THREE.Material {
    const m = new MeshBasicNodeMaterial({ color: '#d2c18c', transparent: true, opacity: .9 });
    const age = max(float(0), this.time.sub(attribute('debrisBirth')));
    const v = attribute('debrisVelocity', 'vec3');
    const seed = attribute('debrisSeed');
    const drift = vec3(sin(seed.mul(7.1)), sin(seed.mul(5.3)), sin(seed.mul(3.7))).mul(.12);
    const offset = this.gpuPosition ? this.gpuPosition.element(instanceIndex) : v.mul(age).add(vec3(0, age.mul(age).mul(-4.8), 0)).add(drift.mul(age));
    // Approximate terrain collision in the visual shader; no CPU readback is needed.
    const bouncedY = max(offset.y, attribute('debrisFloor'));
    m.positionNode = positionLocal.add(vec3(offset.x, bouncedY, offset.z));
    (m as any).opacityNode = smoothstep(float(3.6), float(2.0), age);
    return m;
  }

  private webglMaterial(): THREE.Material {
    return new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 } }, transparent: true, depthWrite: false,
      vertexShader: `attribute float debrisBirth; attribute vec3 debrisVelocity; attribute float debrisSeed; attribute float debrisFloor;
        uniform float uTime; varying float vLife;
        void main(){ float age=max(0.0,uTime-debrisBirth); vec3 p=position+debrisVelocity*age+vec3(0.0,-7.0*age*age,0.0);
        p.y=max(p.y,debrisFloor); p.x+=sin(debrisSeed*7.1)*.12*age; p.z+=sin(debrisSeed*3.7)*.12*age;
        vLife=1.0-smoothstep(2.0,3.6,age); gl_Position=projectionMatrix*modelViewMatrix*instanceMatrix*vec4(p,1.0); }`,
      fragmentShader: `varying float vLife; void main(){ gl_FragColor=vec4(0.82,0.72,0.45,vLife*.9); }`
    });
  }

  spawn(position: THREE.Vector3, velocity: THREE.Vector3, now: number, amount = 8, groundY = 0) {
    const matrix = new THREE.Matrix4();
    for (let i = 0; i < amount; i++) {
      const index = this.next++ % this.capacity;
      this.births[index] = now;
      this.seeds[index] = (index * 17.13) % 31;
      this.floors[index] = groundY - position.y;
      const j = index * 3;
      this.velocities[j] = velocity.x + Math.sin(index * 2.1) * .8;
      this.velocities[j + 1] = velocity.y + .25 + (index % 5) * .16;
      this.velocities[j + 2] = velocity.z + Math.cos(index * 1.7) * .8;
      if(this.gpuPosition){const pa=(this.gpuPosition as any).value.array as Float32Array,va=(this.gpuVelocity as any).value.array as Float32Array,aa=(this.gpuAge as any).value.array as Float32Array,fa=(this.gpuFloor as any).value.array as Float32Array;pa[index*3]=0;pa[index*3+1]=0;pa[index*3+2]=0;va[index*3]=this.velocities[j];va[index*3+1]=this.velocities[j+1];va[index*3+2]=this.velocities[j+2];aa[index]=0.0001;fa[index]=groundY-position.y;}
      matrix.makeTranslation(position.x, position.y, position.z);
      this.mesh.setMatrixAt(index, matrix);
    }
    this.mesh.count = Math.min(this.capacity, Math.max(this.mesh.count, Math.min(this.next, this.capacity)));
    this.birthAttribute.needsUpdate = true; this.velocityAttribute.needsUpdate = true; this.seedAttribute.needsUpdate = true; this.floorAttribute.needsUpdate = true;
    this.mesh.instanceMatrix.needsUpdate = true;
    if(this.gpuPosition){(this.gpuPosition as any).value.needsUpdate=true;(this.gpuVelocity as any).value.needsUpdate=true;(this.gpuAge as any).value.needsUpdate=true;(this.gpuFloor as any).value.needsUpdate=true;}
  }

  update(now: number) {
    this.time.value = now;
    const mat = this.mesh.material as THREE.ShaderMaterial & { uniforms?: Record<string, { value: number }> };
    if (mat.uniforms?.uTime) mat.uniforms.uTime.value = now;
  }

  compute(renderer: any, dt: number) { if(this.gpuCompute && renderer.compute){ this.gpuDt.value=Math.max(0,Math.min(.05,dt)); renderer.compute(this.gpuCompute); } }
  reset(){
    this.next=0;this.mesh.count=0;this.births.fill(0);this.velocities.fill(0);this.seeds.fill(0);this.floors.fill(0);
    this.birthAttribute.needsUpdate=true;this.velocityAttribute.needsUpdate=true;this.seedAttribute.needsUpdate=true;this.floorAttribute.needsUpdate=true;
    if(this.gpuPosition){for(const storage of [this.gpuPosition,this.gpuVelocity,this.gpuAge,this.gpuFloor]){storage.value.array.fill(0);storage.value.needsUpdate=true;}}
  }
}
