import { PARTS, type Piece, type V3 } from './catalog';

export interface FragmentShape { center:V3; size:V3; mass:number; kick:V3 }

/** Six uneven blocks fill the original brittle panel/column. Steel bends apart as a module. */
export function fractureShapes(piece:Piece):FragmentShape[] {
 if(!['column','wall','slab','deck','facade'].includes(piece.kind))return [];
 const def=PARTS[piece.kind],segment=def.segments[0];
 const axes=[0,1,2].sort((a,b)=>segment.size[b]-segment.size[a]);
 const cuts=[[0,.29,.64,1],[0,.46,1]];
 const result:FragmentShape[]=[];
 let seed=piece.id*7919+17;
 const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 for(let i=0;i<3;i++)for(let j=0;j<2;j++){
  const center=[...segment.center] as V3,size=[...segment.size] as V3;
  let fraction=1;
  for(const [n,k] of [i,j].entries()){
   const axis=axes[n],lo=cuts[n][k],hi=cuts[n][k+1];
   center[axis]+=(lo+(hi-lo)/2-.5)*segment.size[axis];size[axis]*=(hi-lo);fraction*=hi-lo;
  }
  const speed=piece.kind==='facade'?3.8:1.8;
  const kick:[number,number,number]=[(random()-.5)*speed*2,(random()-.25)*speed,(random()-.5)*speed*2];
  result.push({center,size:size.map(v=>v*.94) as V3,mass:def.mass*fraction,kick});
 }
 // Opposing impulses scatter debris without adding net linear momentum.
 const mean=result.reduce((sum,f)=>sum.map((v,a)=>v+f.kick[a]*f.mass/def.mass) as V3,[0,0,0] as V3);
 for(const f of result)f.kick=f.kick.map((v,a)=>v-mean[a]) as V3;
 return result;
}

export function rotateByQuaternion(v:V3,q:number[]):V3 {
 const [x,y,z]=v,[qx,qy,qz,qw]=q;
 const tx=2*(qy*z-qz*y),ty=2*(qz*x-qx*z),tz=2*(qx*y-qy*x);
 return [x+qw*tx+qy*tz-qz*ty,y+qw*ty+qz*tx-qx*tz,z+qw*tz+qx*ty-qy*tx];
}
