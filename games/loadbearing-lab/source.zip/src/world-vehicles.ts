import { VehiclePhysics } from './vehicle-physics';
import { demoVehicleControls } from './demo-driving';
import { assertVehicleParts, type VehiclePart } from './vehicle-blueprint';
import type { V3 } from './catalog';
export interface WorldVehicleSpec { id:number; parts:VehiclePart[]; position:V3; rotation:number; name:string }
export type WorldVehicleMode='parked'|'drive'|'attack';
export interface WorldVehicleState { id:number; name:string; parts:VehiclePart[]; position:V3; rotation:number; chassisId:number; mode:WorldVehicleMode; target?:V3; yaw:number; pitch:number }
type Entry={spec:WorldVehicleSpec;vehicle:VehiclePhysics;mode:WorldVehicleMode;target?:V3};
export class WorldVehicles {
 private entries=new Map<number,Entry>(); constructor(private sim:any){}
 get states():WorldVehicleState[]{return [...this.entries.values()].map(e=>{const p=e.vehicle.chassis.GetPosition(),q=e.vehicle.chassis.GetRotation();return {id:e.spec.id,name:e.spec.name,parts:e.spec.parts,position:[p.GetX(),p.GetY(),p.GetZ()],rotation:Math.atan2(2*(q.GetX()*q.GetZ()+q.GetW()*q.GetY()),1-2*(q.GetY()*q.GetY()+q.GetX()*q.GetX())),chassisId:e.vehicle.chassisItem.id,mode:e.mode,target:e.target,yaw:e.vehicle.controls.yaw,pitch:e.vehicle.controls.pitch};});}
 spawn(spec:WorldVehicleSpec){this.validate(spec);if(this.entries.has(spec.id))throw new Error('World vehicle already exists');this.reserve(spec);const vehicle=new VehiclePhysics(this.sim,spec.parts,spec.position,undefined,spec.rotation,spec.id);vehicle.controls={...vehicle.controls,brake:true};this.entries.set(spec.id,{spec,vehicle,mode:'parked'});return this.states.find(s=>s.id===spec.id)!;}
 remove(id:number){const e=this.entries.get(id);if(!e)return false;e.vehicle.dispose();this.entries.delete(id);return true;}
 replace(spec:WorldVehicleSpec){this.validate(spec);if(!this.entries.has(spec.id))return this.spawn(spec);const old=this.entries.get(spec.id)!;const count=this.bodyCount(spec),oldCount=this.bodyCount(old.spec);if(this.sim.bodyList.length-oldCount+count>8192+(this.sim.bodyPool?.length??0))throw new Error('Physics body capacity reached');old.vehicle.dispose();this.entries.delete(spec.id);const vehicle=new VehiclePhysics(this.sim,spec.parts,spec.position,undefined,spec.rotation,spec.id);this.entries.set(spec.id,{spec,vehicle,mode:'parked'});return this.states.find(s=>s.id===spec.id)!;}
 setMode(id:number,mode:WorldVehicleMode,target?:V3){const e=this.entries.get(id);if(!e)throw new Error('Unknown world vehicle');if(mode==='drive')for(const [other,entry] of this.entries)if(other!==id&&entry.mode==='drive'){entry.mode='parked';entry.vehicle.controls={...entry.vehicle.controls,throttle:0,steer:0,brake:true};}e.mode=mode;e.target=target;return this.states.find(s=>s.id===id)!;}
 input(id:number,input:any){const e=this.entries.get(id);if(!e)throw new Error('Unknown world vehicle');if(e.mode!=='drive')return false;e.vehicle.controls={...e.vehicle.controls,...input};return true;}
 step(dt:number){for(const e of this.entries.values()){if(e.mode==='parked')e.vehicle.controls={...e.vehicle.controls,throttle:0,steer:0,brake:true,fire:false};else if(e.mode==='attack'){const p=e.vehicle.chassis.GetPosition(),q=e.vehicle.chassis.GetRotation(),t=e.target??[0,3,0];e.vehicle.controls=demoVehicleControls([p.GetX(),p.GetY(),p.GetZ()],[q.GetX(),q.GetY(),q.GetZ(),q.GetW()],t,this.sim.elapsed,25,t);}e.vehicle.step(dt);}}
 afterStep(){for(const e of this.entries.values())e.vehicle.afterStep();} dispose(){for(const id of [...this.entries.keys()])this.remove(id);}
 private validate(s:WorldVehicleSpec){if(!Number.isInteger(s.id)||s.id<=0||!Number.isFinite(s.rotation)||s.position.some(v=>!Number.isFinite(v)))throw new Error('Invalid world vehicle spec');assertVehicleParts(s.parts);}
 private bodyCount(spec:WorldVehicleSpec){return 1+spec.parts.filter(p=>p.kind==='wheel').length;}
 private reserve(spec:WorldVehicleSpec){const count=this.bodyCount(spec);if(this.sim.bodyList.length+count>8192&&!this.sim.ensureBodyCapacity?.(count))throw new Error('Physics body capacity reached');}
}
