import type { Simulation, DynamicItem, Joint } from './physics';
import { PARTS, type V3 } from './catalog';
import { rotateByQuaternion } from './fracture';

type Q = [number,number,number,number];
type Member = {item:DynamicItem;localPosition:V3;localRotation:Q};
type Group = {body:any;members:Member[];joints:Joint[];mass:number;incoming:V3;born:number};
const vec=(v:any):V3=>[v.GetX(),v.GetY(),v.GetZ()];
const quat=(v:any):Q=>[v.GetX(),v.GetY(),v.GetZ(),v.GetW()];
const add=(a:V3,b:V3):V3=>a.map((v,i)=>v+b[i]) as V3;
const sub=(a:V3,b:V3):V3=>a.map((v,i)=>v-b[i]) as V3;
const cross=(a:V3,b:V3):V3=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const mulQ=(a:Q,b:Q):Q=>[a[3]*b[0]+a[0]*b[3]+a[1]*b[2]-a[2]*b[1],a[3]*b[1]-a[0]*b[2]+a[1]*b[3]+a[2]*b[0],a[3]*b[2]+a[0]*b[1]-a[1]*b[0]+a[2]*b[3],a[3]*b[3]-a[0]*b[0]-a[1]*b[1]-a[2]*b[2]];

// Experimental, deliberately restricted to detached rigid sections. Foundations,
// flexible/yielded joints and reinforcement continue through the ordinary solver.
// Original bodies stay allocated (off-world) so item IDs, exact geometry and local
// joint anchors survive grouping. The compound is never an extra rendered item.
export class RigidClusters {
 readonly groups=new Set<Group>();
 private byItem=new Map<DynamicItem,Group>();
 private pool:any[]=[];
 private cooldown=new Map<DynamicItem,number>();
 private nextScan=0;
 created=0;released=0;
 constructor(private sim:Simulation){}
 get stats(){return {groups:this.groups.size,members:this.byItem.size,savedBodies:this.byItem.size-this.groups.size,created:this.created,released:this.released};}
 body(item:DynamicItem){return this.byItem.get(item)?.body??item.body;}
 discover(){
  const s=this.sim;if(s.elapsed<this.nextScan)return;this.nextScan=s.elapsed+.25;
  const visited=new Set<DynamicItem>(),blocked=new Set<DynamicItem>();
  for(const link of s.rebars)if(!link.broken){blocked.add(link.a);blocked.add(link.b);}
  const pendingBodies=new Set<any>();for(const pair of s.pendingCollisions.values()){pendingBodies.add(pair.a);pendingBodies.add(pair.b);}
  let budget=2;
  for(const seed of s.items){
   if(!budget||seed.id<=0||seed.fractured||visited.has(seed)||this.byItem.has(seed))continue;
   const queue=[seed],members:DynamicItem[]=[],joints=new Set<Joint>();let eligible=true;
   visited.add(seed);
   while(queue.length){
    const item=queue.pop()!;members.push(item);
    if(item.id<=0||item.fractured||item.retired||blocked.has(item)||pendingBodies.has(item.body)||this.byItem.has(item)||(this.cooldown.get(item)??0)>s.elapsed)eligible=false;
    for(const j of s.jointNeighbors.get(item.id)??[]){
     if(j.broken)continue;joints.add(j);
     if(!j.b||j.pinned||j.damageStage)eligible=false;
     const other=j.a===item?j.b:j.a;
     if(other&&!visited.has(other)){visited.add(other);queue.push(other);}
    }
   }
   if(!eligible||members.length<3||members.length>1024||joints.size<members.length-1)continue;
   // Do not weld an assembly that is already stretching apart.
   if([...joints].some(j=>j.localA.some((p,i)=>Math.hypot(...sub(s.bodyWorldPoint(j.a,p),s.bodyWorldPoint(j.b!,j.localB![i])))>.08)))continue;
   this.form(members,[...joints]);budget--;
  }
 }
 private form(items:DynamicItem[],joints:Joint[]){
  const s=this.sim,J=s.J;
  if(!this.pool.length&&this.created>=128)return;
  const massOf=(item:DynamicItem)=>1/item.body.GetMotionProperties().GetInverseMass();
  const mass=items.reduce((n,item)=>n+massOf(item),0),center:V3=[0,0,0],velocity:V3=[0,0,0];
  for(const item of items){const m=massOf(item),p=vec(item.body.GetCenterOfMassPosition()),v=vec(item.body.GetLinearVelocity());for(let i=0;i<3;i++){center[i]+=p[i]*m/mass;velocity[i]+=v[i]*m/mass;}}
  const members=items.map(item=>({item,localPosition:sub(vec(item.body.GetPosition()),center),localRotation:quat(item.body.GetRotation())}));
  const settings=new J.StaticCompoundShapeSettings(),inertia=J.Mat44.prototype.sZero(),column=new J.Vec3(0,0,0),momentum:V3=[0,0,0];
  // Sum each member's true mass tensor, including its offset from the shared COM.
  for(const member of members){
   const item=member.item,m=massOf(item),p=new J.Vec3(...member.localPosition),q=new J.Quat(...member.localRotation);
   settings.AddShapeShape(p,q,item.body.GetShape(),item.id);J.destroy(p);
   const mp=item.body.GetShape().GetMassProperties();mp.ScaleToMass(m);const rotation=J.Mat44.prototype.sRotation(q);mp.Rotate(rotation);J.destroy(rotation);J.destroy(q);
   const omega=vec(item.body.GetAngularVelocity()),spin=new J.Vec3(...omega),angular=vec(mp.mInertia.Multiply3x3(spin));J.destroy(spin);
   const r=sub(vec(item.body.GetCenterOfMassPosition()),center),orbital=cross(r,sub(vec(item.body.GetLinearVelocity()),velocity));
   for(let i=0;i<3;i++)momentum[i]+=angular[i]+orbital[i]*m;
   const offset=new J.Vec3(...r);mp.Translate(offset);J.destroy(offset);
   for(let c=0;c<3;c++){const a=vec(inertia.GetColumn3(c)),b=vec(mp.mInertia.GetColumn3(c));column.Set(...add(a,b));inertia.SetColumn3(c,column);}J.destroy(mp);
  }
  const result=settings.Create();if(!result.IsValid()){J.destroy(result);J.destroy(settings);J.destroy(inertia);J.destroy(column);return;}
  const compound=result.Get();compound.AddRef();J.destroy(result);J.destroy(settings);
  const shapeCOM=vec(compound.GetCenterOfMass()),offset=new J.Vec3(...shapeCOM.map(n=>-n)),shape=new J.OffsetCenterOfMassShape(compound,offset);shape.AddRef();J.destroy(offset);compound.Release();
  const identity=new J.Quat(0,0,0,1);let body=this.pool.pop();
  if(body){s.bodies.SetShape(body.GetID(),shape,false,J.EActivation_DontActivate);const p=new J.RVec3(...center);s.bodies.SetPositionAndRotation(body.GetID(),p,identity,J.EActivation_DontActivate);J.destroy(p);}
  else body=s.makeBody(shape,center,identity,mass);
  shape.Release();J.destroy(identity);
  const properties=new J.MassProperties();properties.mMass=mass;properties.mInertia=inertia;body.GetMotionProperties().SetMassProperties(J.EAllowedDOFs_All,properties);J.destroy(properties);
  const inv=inertia.Inversed3x3(),L=new J.Vec3(...momentum),omega=vec(inv.Multiply3x3(L));J.destroy(inv);J.destroy(L);J.destroy(inertia);J.destroy(column);
  const linear=new J.Vec3(...velocity),angular=new J.Vec3(...omega);body.SetLinearVelocity(linear);body.SetAngularVelocity(angular);J.destroy(linear);J.destroy(angular);
  for(const j of joints){j.constraint.AddRef();s.system.RemoveConstraint(j.constraint);j.clustered=true;}
  for(const {item} of members){s.bodies.RemoveBody(item.body.GetID());s.removedBodies.add(item.body);}
  if(s.removedBodies.delete(body))s.bodies.AddBody(body.GetID(),J.EActivation_Activate);
  const group:Group={body,members,joints,mass,incoming:velocity,born:s.elapsed};this.groups.add(group);for(const item of items)this.byItem.set(item,group);this.created++;
 }
 beforeStep(dt:number){
  const s=this.sim;
  for(const group of [...this.groups]){
   group.incoming=vec(group.body.GetLinearVelocity());
   // Small fast disaster bodies may not change a heavy cluster's velocity much.
   // Expand ahead of their contact so the ordinary joint solver sees the impulse.
   const bounds=group.body.GetWorldSpaceBounds(),lo=vec(bounds.mMin),hi=vec(bounds.mMax);
   for(const threat of s.items){
    if(threat.kind!=='meteor'&&threat.kind!=='rock')continue;
    const p=vec(threat.body.GetPosition()),v=vec(threat.body.GetLinearVelocity());if(Math.hypot(...v)<3)continue;
    const margin=(threat.radius??1)+Math.hypot(...v)*dt;
    if(p.every((n,i)=>n>=lo[i]-margin&&n<=hi[i]+margin)){this.release(group.members[0].item);break;}
   }
  }
 }
 sync(){for(const group of this.groups)this.syncGroup(group);}
 private syncGroup(group:Group){
  const s=this.sim,J=s.J,origin=vec(group.body.GetPosition()),rotation=quat(group.body.GetRotation()),com=vec(group.body.GetCenterOfMassPosition()),linear=vec(group.body.GetLinearVelocity()),omega=vec(group.body.GetAngularVelocity());
  const p=new J.RVec3(0,0,0),q=new J.Quat(0,0,0,1),v=new J.Vec3(0,0,0),w=new J.Vec3(...omega);
  for(const member of group.members){
   const pos=add(origin,rotateByQuaternion(member.localPosition,rotation)),rot=mulQ(rotation,member.localRotation);
   p.Set(...pos);q.Set(...rot);
   const localCOM=vec(member.item.body.GetShape().GetCenterOfMass()),worldCOM=add(pos,rotateByQuaternion(localCOM,rot));
   v.Set(...add(linear,cross(omega,sub(worldCOM,com))));s.bodies.SetPositionRotationAndVelocity(member.item.body.GetID(),p,q,v,w);
  }
  J.destroy(p);J.destroy(q);J.destroy(v);J.destroy(w);
 }
 afterStep(dt:number){
  this.sync();const s=this.sim;
  // A hard collision returns to individual bodies and local material fracture.
  // Compare against free flight; gravity alone must never dissolve a cluster.
  const gravity=vec(s.system.GetGravity());
  for(const group of [...this.groups]){
   const now=vec(group.body.GetLinearVelocity()),expected=group.incoming.map((v,i)=>(v+gravity[i]*dt)*Math.max(0,1-.08*dt)) as V3;
   const delta=Math.hypot(...sub(now,expected));if(delta<2.5)continue;
   let point:V3|undefined;
   if(s.system.WereBodiesInContact(group.body.GetID(),s.ground.GetID())){
    let low=Infinity;for(const {item} of group.members){const bounds=item.body.GetWorldSpaceBounds(),min=vec(bounds.mMin),max=vec(bounds.mMax);if(min[1]<low){low=min[1];point=[(min[0]+max[0])/2,min[1],(min[2]+max[2])/2];}}
   }else for(const other of s.items){if(other.fractured||s.removedBodies.has(other.body))continue;if(s.system.WereBodiesInContact(group.body.GetID(),other.body.GetID())){point=vec(other.body.GetCenterOfMassPosition());break;}}
   const hit=point?this.nearest(group,point):undefined;this.release(group.members[0].item);
   if(hit&&point)s.impactFracture(hit,point,.5*group.mass*delta*delta);
  }
 }
 release(item:DynamicItem){
  const group=this.byItem.get(item);if(!group)return;
  const s=this.sim;this.syncGroup(group);s.bodies.RemoveBody(group.body.GetID());s.removedBodies.add(group.body);this.pool.push(group.body);this.groups.delete(group);
  for(const member of group.members){this.byItem.delete(member.item);s.removedBodies.delete(member.item.body);s.bodies.AddBody(member.item.body.GetID(),s.J.EActivation_Activate);this.cooldown.set(member.item,s.elapsed+2);}
  for(const j of group.joints){j.clustered=false;j.constraint.ResetWarmStart();if(!j.broken)s.system.AddConstraint(j.constraint);j.constraint.Release();}
  this.released++;
 }
 force(item:DynamicItem,x:number,y:number,z:number){
  const group=this.byItem.get(item);if(!group)return false;
  if(!(x||y||z))return true;
  const s=this.sim,J=s.J;s.bodies.ActivateBody(group.body.GetID());const f=new J.Vec3(x,y,z),p=new J.RVec3(...vec(item.body.GetCenterOfMassPosition()));group.body.AddForce(f,p);J.destroy(f);J.destroy(p);return true;
 }
 private nearest(group:Group,point:V3){
  let hit=group.members[0].item,best=Infinity;
  for(const {item} of group.members){const b=item.body.GetWorldSpaceBounds(),lo=vec(b.mMin),hi=vec(b.mMax),d=point.reduce((n,v,i)=>n+Math.max(lo[i]-v,0,v-hi[i])**2,0);if(d<best){best=d;hit=item;}}
  return hit;
 }
 hit(bodyId:number,point:V3){for(const group of this.groups)if(group.body.GetID().GetIndexAndSequenceNumber()===bodyId)return this.nearest(group,point);}
 dispose(){for(const group of [...this.groups])this.release(group.members[0].item);}
}
