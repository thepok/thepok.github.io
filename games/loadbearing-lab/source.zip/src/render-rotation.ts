// Angular velocity is in world space, so apply its rotation before the body rotation.
// Mutate caller-owned output to avoid allocations in the render loop.
export function predictRotation(out:{set:(x:number,y:number,z:number,w:number)=>any},q:{x:number;y:number;z:number;w:number},omega:{x:number;y:number;z:number},dt:number){
 const speed=Math.hypot(omega.x,omega.y,omega.z);
 if(speed<1e-8||dt<=0)return out.set(q.x,q.y,q.z,q.w);
 const half=speed*dt*.5,s=Math.sin(half)/speed,x=omega.x*s,y=omega.y*s,z=omega.z*s,w=Math.cos(half);
 return out.set(w*q.x+x*q.w+y*q.z-z*q.y,w*q.y-x*q.z+y*q.w+z*q.x,w*q.z+x*q.y-y*q.x+z*q.w,w*q.w-x*q.x-y*q.y-z*q.z);
}
