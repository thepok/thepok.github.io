type Vector={x:number;y:number;z:number;set:(x:number,y:number,z:number)=>any};
type Rotation={x:number;y:number;z:number;w:number;set:(x:number,y:number,z:number,w:number)=>any};
type Pose={at:number;x:number;y:number;z:number;qx:number;qy:number;qz:number;qw:number};
/** All vehicle bodies sample the same delayed clock, rather than chasing each new packet. */
export class VehiclePoseBuffer{
 private poses:Pose[]=[];
 push(at:number,p:Vector,q:Rotation){
  const last=this.poses.at(-1);
  if(last&&Math.hypot(p.x-last.x,p.y-last.y,p.z-last.z)>8)this.poses=[];
  const pose={at,x:p.x,y:p.y,z:p.z,qx:q.x,qy:q.y,qz:q.z,qw:q.w};
  if(this.poses.at(-1)?.at===at)this.poses[this.poses.length-1]=pose;else this.poses.push(pose);
  if(this.poses.length>12)this.poses.shift();
 }
 sample(at:number,p:Vector,q:Rotation){
  const poses=this.poses;if(!poses.length)return;
  let a=poses[0],b=a;
  for(let i=1;i<poses.length;i++){b=poses[i];if(b.at>=at)break;a=b;}
  const t=a===b?0:Math.max(0,Math.min(1,(at-a.at)/(b.at-a.at)));
  p.set(a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t,a.z+(b.z-a.z)*t);
  let dot=a.qx*b.qx+a.qy*b.qy+a.qz*b.qz+a.qw*b.qw;const sign=dot<0?-1:1;dot=Math.min(1,Math.abs(dot));
  let wa=1-t,wb=t;if(dot<.9995){const angle=Math.acos(dot),sin=Math.sin(angle);wa=Math.sin((1-t)*angle)/sin;wb=Math.sin(t*angle)/sin;}
  const x=a.qx*wa+b.qx*wb*sign,y=a.qy*wa+b.qy*wb*sign,z=a.qz*wa+b.qz*wb*sign,w=a.qw*wa+b.qw*wb*sign,len=Math.hypot(x,y,z,w)||1;
  q.set(x/len,y/len,z/len,w/len);
 }
}
