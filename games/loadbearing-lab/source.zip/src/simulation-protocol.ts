import type { Piece, Scenario, V3 } from './catalog';
export type Hazard = 'wind'|'earthquake'|'flood'|'meteors';
export const POSE_STRIDE = 14; // position, quaternion, linear velocity, active, angular velocity
export type WorkerCommand =
 | { type:'init'; pieces:Piece[]; scenario:Scenario; intensity:number; rules:any; threads:number }
 | { type:'snapshot-consumed'; seq:number }
 | { type:'vehicle-input'; input:any }
 | { type:'pause'; value:boolean } | { type:'speed'; value:number } | { type:'hazard'; kind:Hazard; enabled:boolean }
 | { type:'trees'; specs:any[] } | { type:'projectile'; position:V3; velocity:V3; mass:number; radius:number } | { type:'fragment-limit'; value:number }
 | { type:'restart'; requestId:number; hazards?:Partial<Record<Hazard,boolean>> } | { type:'stop' };
