import assert from 'node:assert/strict';import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';import {createHash} from 'node:crypto';
const read=n=>readFileSync('src/own-engine/'+n),hash=b=>createHash('sha256').update(b).digest('hex');
const baseline=read('kernel-reference.wasm'),fast=read('kernel.wasm');assert.equal(hash(baseline),'037176c75c5d5800e2a6600e8468c5592d57d2431aff889e92a3ce1eca2084ed');
for(const bytes of [baseline,fast])assert.deepEqual(WebAssembly.Module.imports(await WebAssembly.compile(bytes)),[]);
const m=await WebAssembly.instantiate(fast,{});assert.equal(m.instance.exports.optimization_version(),200);assert(m.instance.exports.memory.buffer.byteLength<=128*1024*1024);
const data={baselineSha256:hash(baseline),optimizedSha256:hash(fast),bytes:{baseline:baseline.length,optimized:fast.length},runtimeImports:[],memoryBytes:m.instance.exports.memory.buffer.byteLength,internalSteps:'60 Hz for large scenes; 120 Hz for startup, small scenes and enabled motor hinges',geometry:'All original bodies, parts and fracture geometries; no clustering or lower debris budget'};
mkdirSync('artifacts',{recursive:true});writeFileSync('artifacts/speed-audit.json',JSON.stringify(data,null,2));console.log('SPEED_AUDIT_PASS',JSON.stringify(data));
