import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
const browser=await chromium.launch({channel:'chrome',headless:true,args:['--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
const context=await browser.newContext({viewport:{width:412,height:915},deviceScaleFactor:2.625,isMobile:true,hasTouch:true,userAgent:'Mozilla/5.0 (Linux; Android 15; Pixel 8) AppleWebKit/537.36 Chrome/152.0 Mobile Safari/537.36'});
const page=await context.newPage(),errors=[],benchmarkProgress=[],gameProgress=[];
page.on('pageerror',e=>errors.push(e.message));
const cdp=await context.newCDPSession(page);await cdp.send('Emulation.setCPUThrottlingRate',{rate:4});
await page.addInitScript(()=>{Object.defineProperty(navigator,'hardwareConcurrency',{get:()=>4});localStorage.setItem('loadbearing-own-fast.demo-seen','1');localStorage.setItem('loadbearing-own-fast.last-mode',JSON.stringify({challengeId:'sandbox-demolition-yard'}));});
try{
  await page.goto('http://127.0.0.1:5174/');await page.waitForFunction(()=>window.__loadBearing?.ready,{},{timeout:90000});

  // Reproduce the reported mobile benchmark symptom directly: before
  // measurement starts, preload must visibly advance instead of reading 0.
  await page.evaluate(()=>document.getElementById('kinetic-benchmark').click());await page.waitForFunction(()=>document.getElementById('kinetic-bench-panel')?.open);await page.selectOption('#kb-preset','art-deco');await page.selectOption('#kb-repeats','1');await page.click('#kb-start');
  const benchStart=Date.now();
  for(let i=0;i<120;i++){
    const row=await page.evaluate(()=>({status:document.getElementById('kb-status')?.textContent??'',value:Number(document.getElementById('kb-progress')?.value??0)}));
    benchmarkProgress.push({wallMs:Date.now()-benchStart,...row});
    if(row.value>.1)break;
    await page.waitForTimeout(250);
  }
  const moved=benchmarkProgress.find(p=>p.value>.1);
  assert.ok(moved,'Benchmark progress must leave zero during preload on a 4x-throttled mobile profile');
  assert.match(moved.status,/vorspannen|Aufwärmen|Messen/i,'Benchmark must identify the active preparation/measurement stage');
  await page.click('#kb-cancel');await page.waitForFunction(()=>document.getElementById('kb-status')?.textContent?.includes('Abgebrochen'));
  await page.click('#kb-close');

  // Also verify that ordinary large-world start reaches live scenario time.
  await page.evaluate(()=>{document.getElementById('workshop-mode').click();document.getElementById('sandbox-mode').click();document.getElementById('clear').click();document.getElementById('procedural-style').value='art-deco';document.getElementById('procedural-count-number').value='1000';const old=Date.now;Date.now=()=>0x51a7;try{document.getElementById('generate-building').click();}finally{Date.now=old;}document.getElementById('run').click();});
  const start=Date.now();
  for(let i=0;i<180;i++){
    const row=await page.evaluate(()=>({status:document.getElementById('status').textContent,timer:document.getElementById('timer').textContent,elapsed:window.__loadBearing.simulation?.elapsed??null,startup:window.__loadBearing.simulation?.startup??null,preparing:window.__loadBearing.simulation?.preparing??false,startupProgress:window.__loadBearing.simulation?.startupProgress??0}));
    gameProgress.push({wallMs:Date.now()-start,...row});
    if((row.elapsed??0)>.5)break;
    await page.waitForTimeout(250);
  }
  const final=gameProgress.at(-1);
  assert.ok((final.elapsed??0)>.5,'Simulation clock must start on a 4x-throttled phone profile within 45 seconds');
  assert.equal(await page.evaluate(()=>__loadBearing.simulation.broken),0,'No startup damage');
  assert.deepEqual(errors,[]);
  await page.screenshot({path:'artifacts/mobile-startup/mobile-running.png',fullPage:true});
  await writeFile('artifacts/mobile-startup/mobile-progress.json',JSON.stringify({benchmarkProgress,gameProgress,errors},null,2));
  console.log('MOBILE_PROGRESS_PASS '+JSON.stringify({benchmarkFirstMovementMs:moved.wallMs,benchmarkStatus:moved.status,gameStartMs:final.wallMs,elapsed:final.elapsed}));
}finally{await browser.close();}
