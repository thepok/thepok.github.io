import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {mkdir,writeFile} from 'node:fs/promises';
await mkdir('artifacts/speed-browser',{recursive:true});
const browser=await chromium.launch({channel:'chrome',headless:true,args:['--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
const report={runs:[],errors:[],requests:[]},url=process.env.TEST_URL||'http://127.0.0.1:5174/';
try{
 const page=await browser.newPage({viewport:{width:1440,height:1000}});
 page.on('pageerror',e=>report.errors.push(e.message));page.context().on('request',r=>report.requests.push(r.url()));
 await page.addInitScript(()=>{localStorage.setItem('loadbearing-own-fast.demo-seen','1');localStorage.setItem('loadbearing-own-fast.last-mode',JSON.stringify({challengeId:'sandbox-demolition-yard'}));localStorage.setItem('loadbearing-own-fast.fragment-limit','1000');});
 async function setup(variant){await page.goto(url+'?kernel='+variant);await page.waitForFunction(()=>window.__loadBearing?.ready,{},{timeout:120000});await page.evaluate(()=>{for(const id of ['workshop-mode','sandbox-mode','clear'])document.getElementById(id).click();document.getElementById('procedural-style').value='art-deco';document.getElementById('procedural-count-number').value='1000';const old=Date.now;Date.now=()=>0x51a7;try{document.getElementById('generate-building').click();}finally{Date.now=old;}__loadBearing.scene.onPick([0,0,0],null);__loadBearing.scene.fitStructure();document.getElementById('run').click();});await page.waitForFunction(()=>__loadBearing.simulation?.elapsed>1,{},{timeout:120000});}
 await setup('optimized');
 // Cancel must not reset the existing game, lose rendering, or strand its worker.
 const original=await page.evaluate(()=>{window.beforeWorker=__loadBearing.simulation.worker;window.beforeRender=__loadBearing.scene.render;return __loadBearing.simulation.elapsed;});
 await page.click('#kinetic-benchmark');await page.selectOption('#kb-repeats','1');await page.click('#kb-start');
 await page.waitForFunction(()=>__loadBearing.simulation.paused&&__loadBearing.scene.render!==window.beforeRender,{},{timeout:15000});await page.click('#kb-cancel');
 assert.equal(await page.evaluate(()=>__loadBearing.simulation.worker===window.beforeWorker&&__loadBearing.scene.render===window.beforeRender),true);
 await page.waitForFunction(t=>__loadBearing.simulation.elapsed>t,original,{timeout:30000});
 // Complete A/B using the actual modal and its dedicated module worker.
 await page.click('#kb-start');await page.waitForFunction(()=>window.__kineticBenchmark,{},{timeout:360000});
 const bench=await page.evaluate(()=>__kineticBenchmark);assert.equal(bench.runs.length,2);assert.equal(bench.runs[0].kernel.sha256,'037176c75c5d5800e2a6600e8468c5592d57d2431aff889e92a3ce1eca2084ed');assert.equal(bench.aggregateQualityPass,true);assert.equal(bench.runs[1].internalSubsteps,1200);assert.equal(bench.runs[0].internalSubsteps,2400);assert.equal(await page.evaluate(()=>__loadBearing.scene.render===window.beforeRender),true);
 await page.screenshot({path:'artifacts/speed-browser/benchmark.png'});
 const downloadPromise=page.waitForEvent('download');await page.click('#kb-json');const download=await downloadPromise;await download.saveAs('artifacts/speed-browser/ui-export.json');
 await page.setViewportSize({width:390,height:844});await page.screenshot({path:'artifacts/speed-browser/mobile-benchmark.png'});assert.equal(await page.evaluate(()=>document.querySelector('#kinetic-bench-panel').getBoundingClientRect().right<=innerWidth),true);
 await page.setViewportSize({width:1440,height:1000});await page.click('#kb-close');
 // Same live shot clock and original renderer, on both native cores.
 for(const variant of ['reference','optimized']){
  await setup(variant);await page.screenshot({path:`artifacts/speed-browser/${variant}-before.png`});
  await page.click('#kinetic-benchmark');await page.click('#kb-live');
  await page.waitForFunction(()=>__loadBearing.simulation?.broken>100,{},{timeout:90000});
  await page.waitForFunction(()=>__loadBearing.simulation.elapsed>8,{},{timeout:120000});await page.screenshot({path:`artifacts/speed-browser/${variant}-during.png`});
  await page.waitForFunction(()=>window.__kineticLiveBenchmark,{},{timeout:300000});const live=await page.evaluate(()=>__kineticLiveBenchmark);
  report.runs.push({variant,live});assert.equal(live.ticks,1200);assert.equal(live.final.finite,true);assert.equal(live.final.fragments,1000);assert(live.final.meanHeight<10);assert.equal(live.controlled,live.interventions.length===0);assert.ok(live.interventions.every(kind=>kind==='trees-present'),'Unexpected intervention: '+live.interventions.join(','));assert.equal(live.internalSubsteps,variant==='reference'?2400:1200);
  await page.evaluate(()=>__loadBearing.simulation.pause(true));await page.waitForTimeout(200);await page.screenshot({path:`artifacts/speed-browser/${variant}-after.png`});
 }
 assert.equal(await page.evaluate(()=>Object.keys(localStorage).some(k=>k.startsWith('loadbearing.')||k.startsWith('loadbearing-own.'))),false);
 assert(!report.requests.some(u=>/jolt|rapier|ammo/i.test(u)),'No foreign physics dependency');assert.deepEqual(report.errors,[]);report.benchmark=bench;report.browser=browser.version();console.log('SPEED_BROWSER_PASS',JSON.stringify({speedup:bench.medianSpeedup,quality:bench.aggregateQualityPass,runs:report.runs.map(r=>({variant:r.variant,final:r.live.final}))}));
}finally{await writeFile('artifacts/speed-browser/verification.json',JSON.stringify(report,null,2));await browser.close();}
