import {build} from 'esbuild';
import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {pathToFileURL} from 'node:url';
import os from 'node:os';
const args=process.argv.slice(2),arg=(name,fallback)=>{const i=args.indexOf(name);return i<0?fallback:args[i+1];};
const repeats=Number(arg('--repeats','3')),presets=arg('--presets','art-deco,brutalist').split(','),out=resolve(arg('--out','artifacts/benchmark/results.json'));
if(!Number.isInteger(repeats)||repeats<1||repeats>5)throw Error('--repeats must be 1..5');
if(presets.some(p=>!['art-deco','brutalist','quiet'].includes(p)))throw Error('Unknown preset');
mkdirSync('artifacts/benchmark',{recursive:true});mkdirSync(dirname(out),{recursive:true});
globalThis.__KINETIC_WASM__=readFileSync('src/own-engine/kernel.wasm');
globalThis.__KINETIC_WASM_REFERENCE__=readFileSync('src/own-engine/kernel-reference.wasm');
await build({stdin:{contents:"export {runSuite} from './src/benchmark/suite.ts';",resolveDir:process.cwd()},bundle:true,platform:'node',format:'esm',outfile:'artifacts/benchmark/suite.mjs'});
const {runSuite}=await import(pathToFileURL(resolve('artifacts/benchmark/suite.mjs')));
const output={environment:{node:process.version,cpu:os.cpus()[0]?.model,cores:os.cpus().length,arch:os.arch(),platform:os.platform()},results:[]};
let lastLog=0,stage='';
for(const preset of presets){
 const result=await runSuite({preset,seed:0x51a7,fragmentLimit:1000},repeats,p=>{const key=`${p.variant} ${p.repetition} ${p.stage}`;if(key!==stage||performance.now()-lastLog>5000){console.log(`${preset}: ${key} ${p.completed}/${p.total}`);lastLog=performance.now();stage=key;}});
 output.results.push(result);writeFileSync(out,JSON.stringify(output,null,2));
 console.log('BENCHMARK_RESULT '+JSON.stringify({preset,medianSpeedup:result.medianSpeedup,min:result.minimumSpeedup,max:result.maximumSpeedup,quality:result.aggregateQualityPass,pairs:result.pairs}));
}
if(output.results.some(r=>!r.aggregateQualityPass)){console.error('FAILED: aggregate quality gate');process.exitCode=1;}
if(args.includes('--require-2x')&&output.results.some(r=>r.medianSpeedup<2)){console.error('FAILED: 2x performance target');process.exitCode=1;}
console.log('Report:',out);
