import {runSuite, type Spec} from './suite';
let busy=false,cancelled=false;
self.onmessage=async(e:MessageEvent)=>{
 const c=e.data;
 if(c.type==='cancel'){cancelled=true;return;}
 if(c.type!=='start'||busy)return;
 busy=true;cancelled=false;
 try{const report=await runSuite(c.spec as Spec,c.repeats??1,p=>postMessage({type:'progress',progress:p}),()=>cancelled);postMessage({type:'result',report});}
 catch(error){postMessage({type:'error',message:error instanceof Error?error.message:String(error)});}
 finally{busy=false;}
};
