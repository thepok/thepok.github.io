import './ui.css';
import type { Spec } from './suite';

/** Diagnostics only. Does not replace the game GUI, renderer, or save system. */
export function installBenchmarkUI(){
 const api=()=>((window as any).__loadBearing),button=document.createElement('button');
 button.id='kinetic-benchmark';button.className='quiet';button.title='Physik-Benchmark: Referenz gegen Optimierung';button.innerHTML='<span>Benchmark</span>';
 (document.querySelector('.top-actions')??document.querySelector('.topbar'))?.append(button);
 const panel=document.createElement('dialog');panel.className='kinetic-bench';panel.id='kinetic-bench-panel';
 panel.innerHTML=`<header><div><small>KINETIC · EIGENE PHYSIK</small><h2>Physik vergleichen</h2></div><button id="kb-close" aria-label="Benchmark schließen">×</button></header>
 <p>Gleiche Bauteile, gleiche Schüsse, gleiches Trümmerlimit. Referenz: intern 120 Hz. Optimiert: große Welten 60 Hz, kleine Welten / angetriebene Fahrzeugachsen 120 Hz. Kein Jolt. Gemessen wird der Physikdurchsatz, nicht die Render-FPS.</p>
 <div class="kb-fields"><label>Szene<select id="kb-preset"><option value="art-deco">Art déco · 1.000 Teile · Einsturz</option><option value="brutalist">Brutalismus · 1.000 Teile · Einsturz</option><option value="quiet">Art déco · Ruhe / Stabilität</option><option value="current">Aktueller Bauplan · Beschuss</option></select></label><label>Wiederholungen<select id="kb-repeats"><option value="1">1 · schneller Vergleich</option><option value="3" selected>3 · A/B, B/A, A/B</option><option value="5">5 · längere Messreihe</option></select></label></div>
 <div class="kb-actions"><button id="kb-start" class="kb-primary">A/B-Test starten</button><button id="kb-cancel" disabled>Abbrechen</button></div>
 <p class="kb-small">Pro Lauf 20 simulierte Sekunden, fünf fest getaktete Schüsse, 1.000 Trümmerplätze. Vorbereitung und Aufwärmen werden getrennt erfasst. Dein Spiel und dessen Rendering werden während der Messung pausiert und anschließend wiederhergestellt.</p>
 <progress id="kb-progress" max="100" value="0"></progress><div id="kb-status" role="status" aria-live="polite">Bereit. Die Referenz ist die bisherige KINETIC-Version.</div>
 <section id="kb-result" hidden><strong id="kb-speed"></strong><div id="kb-quality"></div><table><thead><tr><th>Physik</th><th>Referenz</th><th>Optimiert</th></tr></thead><tbody id="kb-rows"></tbody></table><div class="kb-actions"><button id="kb-json">Messdaten exportieren</button></div><p class="kb-small">Automatische Schadens- und Stabilitätsprüfungen ersetzen keine visuelle Begutachtung. Der optimierte Modus hat eine andere interne Zeitauflösung. Bruchreihenfolge und Bahnen können sich unterscheiden.</p></section>
 <section class="kb-live"><h3>Sichtbarer Test im vollständigen Spiel</h3><p>Setzt die aktuell laufende Sandbox-Welt zurück und beschießt sie mit derselben Schussfolge. Der Bauplan bleibt erhalten. Danach kannst du normal weiterspielen.</p><button id="kb-live">Aktuelles Gebäude zurücksetzen + beschießen</button><p class="kb-small">Zum Vergleich derselben Szene mit dem alten Kern: <a href="?kernel=reference">Referenzmodus öffnen</a> · <a href="?kernel=optimized">Optimierten Modus öffnen</a>. Beide Links benutzen ausschließlich die eigenen Vorschau-Spielstände.</p></section>`;
 document.body.append(panel);
 const $=<T extends HTMLElement>(id:string)=>panel.querySelector<T>('#'+id)!;
 let worker:Worker|undefined,report:any,restore:(()=>void)|undefined,busy=false,operation=0;
 const status=(text:string)=>{$('kb-status').textContent=text;};
 const controls=(running:boolean)=>{busy=running;($<HTMLButtonElement>('kb-start')).disabled=running;$<HTMLButtonElement>('kb-live').disabled=running;$<HTMLButtonElement>('kb-cancel').disabled=!running;$<HTMLSelectElement>('kb-preset').disabled=running;$<HTMLSelectElement>('kb-repeats').disabled=running;};
 function finish(){operation++;worker?.terminate();worker=undefined;restore?.();restore=undefined;controls(false);}
 function cancel(){if(!busy)return;finish();status('Abgebrochen. Dein Spiel wurde wieder freigegeben.');}
 button.onclick=()=>{document.exitPointerLock?.();panel.showModal();};$('kb-close').onclick=()=>panel.close();panel.addEventListener('close',cancel);panel.addEventListener('keydown',e=>e.stopPropagation());$('kb-cancel').onclick=cancel;
 function showReport(value:any){
  report={...value,environment:{userAgent:navigator.userAgent,hardwareConcurrency:navigator.hardwareConcurrency,deviceMemoryGiB:(navigator as any).deviceMemory??null,rendererPaused:true}};
  (window as any).__kineticBenchmark=report;
  const speed=value.medianSpeedup;($('kb-result')).hidden=false;$('kb-speed').textContent=`${speed.toFixed(2)}× Physikdurchsatz · ${Math.abs((speed-1)*100).toFixed(0)} % ${speed>=1?'mehr':'weniger'}`;
  $('kb-quality').textContent=`${value.aggregateQualityPass?'Aggregat-Prüfungen bestanden':'Schadens-/Stabilitätsabweichung: prüfen'} · ${value.doubleSpeedTargetMet?'2×-Ziel in dieser Messung erreicht':'2×-Ziel in dieser Messung nicht erreicht'}`;
  $('kb-quality').className=value.aggregateQualityPass?'kb-ok':'kb-warning';
  const median=(a:number[])=>a.sort((a,b)=>a-b)[Math.floor(a.length/2)];
  const runs=(v:string)=>value.runs.filter((r:any)=>r.variant===v),ref=runs('reference'),opt=runs('optimized');
  const values:[string,string,string][]=[
   ['Mittel / Schritt',...['reference','optimized'].map(v=>median(runs(v).map((r:any)=>r.stats.meanMs)).toFixed(2)+' ms')] as [string,string,string],
   ['p95 / Schritt',...['reference','optimized'].map(v=>median(runs(v).map((r:any)=>r.stats.p95Ms)).toFixed(2)+' ms')] as [string,string,string],
   ['Interne Schritte',String(ref.at(-1).internalSubsteps),String(opt.at(-1).internalSubsteps)],
   ['Letzter Lauf: Brüche',String(ref.at(-1).final.broken),String(opt.at(-1).final.broken)],
   ['Letzter Lauf: Trümmer',String(ref.at(-1).final.fragments),String(opt.at(-1).final.fragments)],
  ];
  for(const phase of Object.keys(ref[0].phases))values.push([phase,median(ref.map((r:any)=>r.phases[phase].meanMs)).toFixed(2)+' ms',median(opt.map((r:any)=>r.phases[phase].meanMs)).toFixed(2)+' ms']);
  const tbody=$('kb-rows');tbody.replaceChildren();for(const row of values){const tr=document.createElement('tr');for(const v of row){const td=document.createElement('td');td.textContent=v;tr.append(td);}tbody.append(tr);}
  status(`Fertig. Median aus ${value.repeats} Vergleich${value.repeats===1?'':'en'}, Spanne ${value.minimumSpeedup.toFixed(2)}–${value.maximumSpeedup.toFixed(2)}×.`);
 }
 $('kb-json').onclick=()=>{if(!report)return;const url=URL.createObjectURL(new Blob([JSON.stringify(report,null,2)],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download='kinetic-benchmark-'+new Date().toISOString().replace(/[:.]/g,'-')+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
 $('kb-start').onclick=async()=>{
  if(busy)return;const request=++operation;controls(true);(window as any).__kineticBenchmark=undefined;$('kb-result').hidden=true;$<HTMLProgressElement>('kb-progress').value=0;status('Test wird vorbereitet …');
  try{
   const current=api(),preset=$<HTMLSelectElement>('kb-preset').value as Spec['preset'],repeats=+$<HTMLSelectElement>('kb-repeats').value;
   const spec:Spec={preset,fragmentLimit:1000,...(preset==='current'?{pieces:structuredClone(current.pieces)}:{})};
   if(preset==='current'&&!spec.pieces?.length)throw Error('Der aktuelle Bauplan ist leer.');
   const sim=current.simulation,scene=current.scene,wasPaused=sim?.paused??false,render=scene.render;
   // Pause acknowledgment precedes timing, avoiding a second live solver stealing CPU.
   restore=()=>{scene.render=render;if(sim&&!wasPaused&&api().simulation===sim)sim.pause(false);};
   if(sim&&!wasPaused){await new Promise<void>((resolve,reject)=>{const timer=setTimeout(()=>{sim.worker.removeEventListener('message',listener);reject(Error('Die laufende Simulation ließ sich nicht pausieren.'));},12000);const listener=(e:MessageEvent)=>{if(e.data.type==='ack'&&e.data.command==='pause'&&e.data.value===true){clearTimeout(timer);sim.worker.removeEventListener('message',listener);resolve();}};sim.worker.addEventListener('message',listener);sim.pause(true);});}
   if(!busy||operation!==request)return;scene.render=()=>{};
   worker=new Worker(new URL('./worker.ts',import.meta.url),{type:'module'});
   worker.onerror=e=>{status(e.message||'Benchmark-Worker fehlgeschlagen.');finish();};
   worker.onmessage=e=>{
    const m=e.data;if(m.type==='progress'){const p=m.progress,ratio=Math.max(0,Math.min(1,p.completed/Math.max(1,p.total))),stageProgress=p.stage==='Gebäude vorspannen'?.15*ratio:p.stage==='Aufwärmen'?.15+.10*ratio:.25+.75*ratio,detail=p.stage==='Messen'?`${(20*ratio).toFixed(1)} / 20.0 s simuliert`:`${p.completed}/${p.total} Schritte`;status(`${p.variant==='reference'?'Referenz':'Optimiert'} · Paar ${p.repetition}/${repeats} · ${p.stage} · ${detail}`);const slot=(p.repetition-1)*2+((p.repetition%2===1)===(p.variant==='reference')?0:1);$<HTMLProgressElement>('kb-progress').value=(slot+stageProgress)/(2*repeats)*100;}
    else if(m.type==='result'){finish();$<HTMLProgressElement>('kb-progress').value=100;showReport(m.report);}
    else if(m.type==='error'){finish();status(m.message);}
   };
   worker.postMessage({type:'start',spec,repeats});
  }catch(e){if(operation===request){finish();status(e instanceof Error?e.message:String(e));}}
 };
 $('kb-live').onclick=async()=>{
  const sim=api().simulation;if(!sim||!sim.rules?.sandbox){status('Starte zunächst eine Sandbox-Welt im normalen Spiel.');return;}
  controls(true);
  try{await sim.restart({},true);panel.close();controls(false);}
  catch(e){controls(false);status(e instanceof Error?e.message:String(e));}
 };
 // Live results are retained for browser tests and console diagnostics without
 // forcing a pop-up or replacing the existing game HUD.
 window.addEventListener('kinetic-live-result',(e:Event)=>{(window as any).__kineticLiveBenchmark=(e as CustomEvent).detail;});
}
