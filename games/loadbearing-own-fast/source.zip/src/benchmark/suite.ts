import { Simulation } from '../physics';
import initKinetic, { selectedKernelInfo } from '../own-engine/compatibility.mjs';
import { generateDemolitionBuilding, type BuildingStyle } from '../procedural-buildings';
import type { Piece, V3 } from '../catalog';

export const BENCHMARK_VERSION = 'kinetic-benchmark-v1';
export type Variant = 'reference' | 'optimized';
export type Preset = 'art-deco' | 'brutalist' | 'quiet' | 'current';
export interface Spec { preset: Preset; seed?: number; pieces?: Piece[]; fragmentLimit?: number; }
export interface Shot { tick: number; position: V3; velocity: V3; mass: number; radius: number; }
export interface Progress { variant: Variant; repetition: number; stage: string; completed: number; total: number; }
export const DEFAULT_SEED = 0x51a7;
export const SECONDS = 20;
export const WARMUP_TICKS = 90;
export function statistics(values: number[]) {
 if (!values.length) return { count: 0, totalMs: 0, meanMs: 0, medianMs: 0, p95Ms: 0, maxMs: 0 };
 const sorted = [...values].sort((a,b)=>a-b), totalMs=values.reduce((a,b)=>a+b,0);
 const at=(p:number)=>sorted[Math.min(sorted.length-1,Math.ceil(sorted.length*p)-1)];
 return {count:values.length,totalMs,meanMs:totalMs/values.length,medianMs:at(.5),p95Ms:at(.95),maxMs:sorted.at(-1)!};
}
export function scenario(spec: Spec) {
 const seed = Number.isSafeInteger(spec.seed) ? spec.seed! >>> 0 : DEFAULT_SEED;
 let pieces: Piece[];
 if (spec.preset==='current') {
  if (!spec.pieces?.length || spec.pieces.length>2500) throw Error('Für eigene Baupläne sind 1–2500 Bauteile erlaubt.');
  pieces=structuredClone(spec.pieces);
 } else {
  if (!['art-deco','brutalist','quiet'].includes(spec.preset)) throw Error('Unbekanntes Benchmark-Szenario.');
  pieces=generateDemolitionBuilding(1000,seed,(spec.preset==='quiet'?'art-deco':spec.preset) as BuildingStyle).pieces;
 }
 const dt=pieces.length>=400?1/60:1/120;
 const limit=spec.fragmentLimit??1000;
 if (!Number.isSafeInteger(limit)||limit<24||limit>3000) throw Error('Ungültige Trümmergrenze.');
 return {pieces,seed,dt,ticks:Math.round(SECONDS/dt),fragmentLimit:limit,preset:spec.preset};
}
export function shotPlan(pieces: Piece[], dt: number): Shot[] {
 const xs=pieces.map(p=>p.p[0]),ys=pieces.map(p=>p.p[1]),zs=pieces.map(p=>p.p[2]);
 const a=Math.min(...xs),b=Math.max(...xs),c=Math.min(...zs),d=Math.max(...zs),cx=(a+b)/2,cz=(c+d)/2,h=Math.max(...ys);
 return [
  {time:1,position:[a-20,5,cz],velocity:[70,0,0]},
  {time:3,position:[b+20,5,cz],velocity:[-70,0,0]},
  {time:5,position:[cx,5,c-20],velocity:[0,0,70]},
  {time:7,position:[cx,5,d+20],velocity:[0,0,-70]},
  {time:10,position:[cx,h+20,cz],velocity:[0,-80,0]},
 ].map(s=>({tick:Math.round(s.time/dt),position:s.position as V3,velocity:s.velocity as V3,mass:500000,radius:5}));
}
function hashText(text:string) {let h=2166136261;for(let i=0;i<text.length;i++)h=Math.imul(h^text.charCodeAt(i),16777619);return (h>>>0).toString(16).padStart(8,'0');}
const float=new Float32Array(1), word=new Uint32Array(float.buffer);
function stateTrace(sim:Simulation,tick:number) {
 let hash=2166136261,finite=true,maxSpeed=0,minY=Infinity,maxY=-Infinity,totalY=0,intact=0,active=0;
 const mix=(n:number)=>{hash=Math.imul(hash^n,16777619);};
 for(const item of sim.items){
  mix(item.id);mix(+!!item.fractured);mix(+!!item.retired);
  const p=item.body.GetPosition(),q=item.body.GetRotation(),v=item.body.GetLinearVelocity(),w=item.body.GetAngularVelocity();
  const values=[p.GetX(),p.GetY(),p.GetZ(),q.GetX(),q.GetY(),q.GetZ(),q.GetW(),v.GetX(),v.GetY(),v.GetZ(),w.GetX(),w.GetY(),w.GetZ()];
  for(const n of values){if(!Number.isFinite(n))finite=false;float[0]=n;mix(word[0]);}
  if(!item.fractured&&!item.retired){minY=Math.min(minY,values[1]);maxY=Math.max(maxY,values[1]);maxSpeed=Math.max(maxSpeed,Math.hypot(values[7],values[8],values[9]));if(item.body.IsActive())active++;}
  if(item.id>0&&!item.fractured){totalY+=values[1];intact++;}
 }
 mix(sim.broken);mix(sim.fragments);
 let liveJoints=0;for(const j of sim.joints){mix(+j.broken);mix(j.damageStage??0);if(!j.broken)liveJoints++;}
 return {tick,hash:(hash>>>0).toString(16).padStart(8,'0'),finite,broken:sim.broken,fragments:sim.fragments,liveJoints,allocatedBodies:sim.bodyList.length,active,intact,meanHeight:intact?totalY/intact:0,minY,maxY,maxSpeed};
}
export class Measurement {
 readonly samples:number[]=[];readonly launchTimes:number[]=[];readonly traces:ReturnType<typeof stateTrace>[]=[];
 readonly shots:Shot[];readonly blueprintHash:string;tick=0;private launched=0;private initialSubsteps:number;
 constructor(public sim:Simulation,public dt:number,public totalTicks:number,quiet=false){this.shots=quiet?[]:shotPlan(sim.pieces,dt);this.blueprintHash=hashText(JSON.stringify(sim.pieces));this.initialSubsteps=sim.world.k?.substeps_total?.()??0;}
 step(){
  if(this.tick===0)this.initialSubsteps=this.sim.world.k?.substeps_total?.()??0;
  // Includes projectile creation / fracture physics, but not trace collection,
  // scheduler waiting, renderer, snapshot serialization, or UI work.
  const start=performance.now();let launchMs=0;
  for(const shot of this.shots)if(shot.tick===this.tick){const at=performance.now();const created=this.sim.launchProjectile(shot.position,shot.velocity,shot.mass,shot.radius);if(!created)throw Error('Benchmark-Geschoss konnte nicht erzeugt werden.');launchMs+=performance.now()-at;this.launched++;}
  this.sim.step(this.dt);this.samples.push(performance.now()-start);this.launchTimes.push(launchMs);this.tick++;
  if(this.tick%30===0||this.tick===this.totalTicks){const trace=stateTrace(this.sim,this.tick);this.traces.push(trace);if(!trace.finite)throw Error('Nicht-endlicher Physikzustand im Benchmark.');}
 }
 get complete(){return this.tick>=this.totalTicks;}
 finish(){
  const stats=statistics(this.samples),phases:Record<string,ReturnType<typeof statistics>>={};
  for(const [name,from,to] of [['Ruhe',0,1],['Einschläge',1,5],['Kollaps',5,11],['Trümmer',11,SECONDS]] as const)phases[name]=statistics(this.samples.slice(Math.round(from/this.dt),Math.round(to/this.dt)));
  const expected=this.shots.filter(s=>s.tick<this.totalTicks).length;
  if(this.launched!==expected)throw Error(`Unvollständige Schussfolge: ${this.launched}/${expected}.`);
  return {schema:BENCHMARK_VERSION,blueprintHash:this.blueprintHash,parts:this.sim.pieces.length,fragmentLimit:this.sim.fragmentLimit,dt:this.dt,internalSubsteps:this.sim.world.k?.substeps_total?this.sim.world.k.substeps_total()-this.initialSubsteps:Math.round(this.tick*this.dt*120),internalPolicy:this.sim.world.k?.optimization_version?'large-world-60Hz; startup/small/hinges-120Hz':'fixed-120Hz',ticks:this.tick,simulatedSeconds:this.tick*this.dt,outliers:this.sim.items.filter(i=>!i.fractured&&!i.retired&&i.body.GetPosition().GetY() < -1).map(i=>({id:i.id,kind:i.kind,position:[i.body.GetPosition().GetX(),i.body.GetPosition().GetY(),i.body.GetPosition().GetZ()],velocity:[i.body.GetLinearVelocity().GetX(),i.body.GetLinearVelocity().GetY(),i.body.GetLinearVelocity().GetZ()]})),shots:this.shots,stats,phases,physicsThroughput:this.dt*1000/stats.meanMs,traces:this.traces,final:this.traces.at(-1)!,samplesMs:this.samples,launchTotalMs:this.launchTimes.reduce((a,b)=>a+b,0),timingScope:'Simulation.step + projectile creation; excludes setup, warmup, traces, rendering, snapshots and scheduling'};
 }
}
export type RunResult=ReturnType<Measurement['finish']>&{variant:Variant;repetition:number;preset:Preset;seed:number;setupMs:number;settleMs:number;warmupMs:number;wallMs:number;kernel:any};
export async function runOne(spec:Spec,variant:Variant,repetition:number,progress:(p:Progress)=>void=()=>{},cancelled:()=>boolean=()=>false):Promise<RunResult>{
 const setup=performance.now(),scene=scenario(spec),J=await initKinetic({variant});
 const sim=new Simulation(J,structuredClone(scene.pieces),'sandbox',1,{sandbox:true,fragmentLimit:scene.fragmentLimit,kineticVariant:variant},0);
 const setupMs=performance.now()-setup;
 const check=()=>{if(cancelled())throw Error('Benchmark abgebrochen.');};
 const notify=(stage:string,completed:number)=>progress({variant,repetition,stage,completed,total:scene.ticks});
 try{
  notify('Gebäude vorspannen',0);const settleStart=performance.now();await sim.settleStartup();const settleMs=performance.now()-settleStart;check();
  notify('Aufwärmen',0);const warmupStart=performance.now();for(let i=0;i<WARMUP_TICKS;i++){sim.step(scene.dt);if(i%12===11){await new Promise(r=>setTimeout(r,0));check();}}const warmupMs=performance.now()-warmupStart;
  const measure=new Measurement(sim,scene.dt,scene.ticks,scene.preset==='quiet'),started=performance.now();
  while(!measure.complete){check();for(let i=0;i<12&&!measure.complete;i++)measure.step();notify('Messen',measure.tick);await new Promise(r=>setTimeout(r,0));}
  const result=measure.finish();
  if(scene.preset==='quiet'&&(result.final.broken!==0||result.final.fragments!==0))throw Error('Das unbelastete Referenzgebäude beschädigt sich selbst.');
  return {...result,variant,repetition,preset:scene.preset,seed:scene.seed,setupMs,settleMs,warmupMs,wallMs:performance.now()-started,kernel:selectedKernelInfo()};
 }finally{sim.dispose();}
}
export function compareRuns(reference:RunResult,optimized:RunResult){
 if(reference.blueprintHash!==optimized.blueprintHash||reference.dt!==optimized.dt||reference.ticks!==optimized.ticks||reference.fragmentLimit!==optimized.fragmentLimit||JSON.stringify(reference.shots)!==JSON.stringify(optimized.shots))throw Error('Ungleiche Benchmark-Konfigurationen dürfen nicht verglichen werden.');
 const a=reference.final,b=optimized.final,relative=(x:number,y:number)=>Math.abs(y-x)/Math.max(1,Math.abs(x));
 const maxHeightDelta=Math.max(...reference.traces.map((t,i)=>Math.abs(t.meanHeight-(optimized.traces[i]?.meanHeight??Infinity))));
 const quiet=reference.preset==='quiet',samePoses=reference.traces.every((t,i)=>t.hash===optimized.traces[i]?.hash);
 const damageDelta=relative(a.broken,b.broken),fragmentDelta=relative(a.fragments,b.fragments);
 const finite=reference.traces.every(t=>t.finite)&&optimized.traces.every(t=>t.finite);
 const aggregateChecksPass=finite&&(quiet?a.broken===0&&b.broken===0&&a.fragments===0&&b.fragments===0:damageDelta<=.15&&fragmentDelta<=.05&&Math.abs(a.meanHeight-b.meanHeight)<=2&&maxHeightDelta<=6)&&b.minY>=Math.min(-1,a.minY-1)&&b.maxSpeed<=Math.max(20,a.maxSpeed*1.5);
 return {preset:reference.preset,repetition:reference.repetition,speedup:reference.stats.meanMs/optimized.stats.meanMs,p95Speedup:reference.stats.p95Ms/optimized.stats.p95Ms,meanStepReduction:1-optimized.stats.meanMs/reference.stats.meanMs,referenceMeanMs:reference.stats.meanMs,optimizedMeanMs:optimized.stats.meanMs,quality:{finite,aggregateChecksPass,checks:{damage:damageDelta<=.15,fragments:fragmentDelta<=.05,finalHeight:Math.abs(a.meanHeight-b.meanHeight)<=2,collapseCurve:maxHeightDelta<=6,ground:b.minY>=Math.min(-1,a.minY-1),velocity:b.maxSpeed<=Math.max(20,a.maxSpeed*1.5)},poseCheckpointsIdentical:samePoses,damageRelativeDifference:damageDelta,fragmentRelativeDifference:fragmentDelta,maxMeanHeightDifferenceMetres:maxHeightDelta,finalMeanHeightDifferenceMetres:Math.abs(a.meanHeight-b.meanHeight),note:'Aggregate regression gates are not a proof of equal visual quality. Inspect the live collapse too.'},phases:Object.fromEntries(Object.keys(reference.phases).map(k=>[k,{reference:reference.phases[k],optimized:optimized.phases[k],speedup:reference.phases[k].meanMs/optimized.phases[k].meanMs}]))};
}
export async function runSuite(spec:Spec,repeats=1,progress:(p:Progress)=>void=()=>{},cancelled:()=>boolean=()=>false){
 if(!Number.isInteger(repeats)||repeats<1||repeats>5)throw Error('Wiederholungen müssen zwischen 1 und 5 liegen.');
 const runs:RunResult[]=[],pairs:ReturnType<typeof compareRuns>[]=[];
 for(let i=0;i<repeats;i++){
  const order:Variant[]=i%2?['optimized','reference']:['reference','optimized'];
  for(const v of order)runs.push(await runOne(spec,v,i+1,progress,cancelled));
  pairs.push(compareRuns(runs.find(r=>r.repetition===i+1&&r.variant==='reference')!,runs.find(r=>r.repetition===i+1&&r.variant==='optimized')!));
 }
 const sorted=pairs.map(p=>p.speedup).sort((a,b)=>a-b),medianSpeedup=sorted[Math.floor(sorted.length/2)];
 return {schema:BENCHMARK_VERSION,createdAt:new Date().toISOString(),reference:'User-approved KINETIC 0.1; frozen original WASM',order:'Alternating AB / BA; fresh world for every run',repeats,medianSpeedup,minimumSpeedup:sorted[0],maximumSpeedup:sorted.at(-1),doubleSpeedTargetMet:medianSpeedup>=2,aggregateQualityPass:pairs.every(p=>p.quality.aggregateChecksPass),runs,pairs};
}
