import { PARTS, type Piece, type V3 } from './catalog';

export interface FragmentShape { center:V3; size:V3; mass:number; kick:V3; /** Optional local convex prism vertices, centered at center. */ vertices?:V3[] }

function facadeFan(random:()=>number):FragmentShape[] {
 // The glass pane is a 3.84 x 3.84 rectangle. A center fan keeps every square
 // millimetre represented while making the break visibly irregular.
 const segment=PARTS.facade.segments[0], halfX=segment.size[0]/2, halfY=segment.size[1]/2;
 const cx=segment.center[0]+(.3+random()*.4)*(random()<.5?-1:1), cy=segment.center[1]+(.3+random()*.4)*(random()<.5?-1:1), depth=segment.size[2]/2;
 const edgeA=-.78+random()*.46, edgeB=.54+random()*.34;
 const boundary:V3[]=[[-halfX,-halfY,0],[edgeA*halfX,-halfY,0],[halfX,-halfY,0],[halfX,halfY,0],[edgeB*halfX,halfY,0],[-halfX,halfY,0]];
 const result:FragmentShape[]=[];
 for(let i=0;i<boundary.length;i++){
  const next=boundary[(i+1)%boundary.length];
  const a=Math.abs((boundary[i][0]-cx+segment.center[0])*(next[1]-cy+segment.center[1])-(next[0]-cx+segment.center[0])*(boundary[i][1]-cy+segment.center[1]))/2;
  const triangle:[[number,number],[number,number],[number,number]]=[[cx,cy],[boundary[i][0]+segment.center[0],boundary[i][1]+segment.center[1]],[next[0]+segment.center[0],next[1]+segment.center[1]]];
  const center:V3=[triangle.reduce((sum,p)=>sum+p[0],0)/3,triangle.reduce((sum,p)=>sum+p[1],0)/3,0], points:V3[]=[];
  // Store a closed triangular prism around the centroid. Physics and rendering
  // can therefore use the exact same convex footprint.
  for(const z of [-depth,depth])for(const p of triangle)points.push([p[0]-center[0],p[1]-center[1],z]);
  const xs=triangle.map(p=>Math.abs(p[0]-center[0])),ys=triangle.map(p=>Math.abs(p[1]-center[1]));
  result.push({center,size:[Math.max(...xs)*2,Math.max(...ys)*2,segment.size[2]],mass:PARTS.facade.mass*a/(segment.size[0]*segment.size[1]),kick:[(random()-.5)*2,(random()-.25)*1.5,(random()-.5)*2],vertices:points});
 }
 // Correct floating-point mass residue without changing the tile.
 result.at(-1)!.mass+=PARTS.facade.mass-result.reduce((sum,part)=>sum+part.mass,0);
 const mean=result.reduce((sum,f)=>sum.map((v,a)=>v+f.kick[a]*f.mass/PARTS.facade.mass) as V3,[0,0,0] as V3);
 for(const f of result)f.kick=f.kick.map((v,a)=>v-mean[a]) as V3;
 return result;
}

/** Six uneven blocks fill the original brittle panel/column. Steel bends apart as a module. */
export function fractureShapes(piece:Piece):FragmentShape[] {
 if(!['column','wall','slab','deck','facade'].includes(piece.kind))return [];
 const def=PARTS[piece.kind],segment=def.segments[0];
 const axes=[0,1,2].sort((a,b)=>segment.size[b]-segment.size[a]);
 const cuts=[[0,.29,.64,1],[0,.46,1]];
 const result:FragmentShape[]=[];
 let seed=piece.id*7919+17;
 const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 if(piece.kind==='facade')return facadeFan(random);
 for(let i=0;i<3;i++)for(let j=0;j<2;j++){
  const center=[...segment.center] as V3,size=[...segment.size] as V3;
  let fraction=1;
  for(const [n,k] of [i,j].entries()){
   const axis=axes[n],lo=cuts[n][k],hi=cuts[n][k+1];
   center[axis]+=(lo+(hi-lo)/2-.5)*segment.size[axis];size[axis]*=(hi-lo);fraction*=hi-lo;
  }
  const speed=1.8;
  const kick:[number,number,number]=[(random()-.5)*speed*2,(random()-.25)*speed,(random()-.5)*speed*2];
  result.push({center,size:size.map(v=>v*.94) as V3,mass:def.mass*fraction,kick});
 }
 // Opposing impulses scatter debris without adding net linear momentum.
 const mean=result.reduce((sum,f)=>sum.map((v,a)=>v+f.kick[a]*f.mass/def.mass) as V3,[0,0,0] as V3);
 for(const f of result)f.kick=f.kick.map((v,a)=>v-mean[a]) as V3;
 return result;
}

export function rotateByQuaternion(v:V3,q:number[]):V3 {
 const [x,y,z]=v,[qx,qy,qz,qw]=q;
 const tx=2*(qy*z-qz*y),ty=2*(qz*x-qx*z),tz=2*(qx*y-qy*x);
 return [x+qw*tx+qy*tz-qz*ty,y+qw*ty+qz*tx-qx*tz,z+qw*tz+qx*ty-qy*tx];
}
