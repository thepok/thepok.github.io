import { PARTS, type Piece, type V3 } from './catalog';
import { fractureShapes, type FragmentShape } from './fracture';

export interface LocalFragmentShape extends FragmentShape {
  /** True for the two load-bearing remnants; rubble is explicitly false. */
  structural?: boolean;
  /** Bounds of the source segment, retained for attachment transfer. */
  parent?: { center: V3; size: V3 };
}

type SegmentBounds = { center: V3; size: V3; mass: number };

const LOCAL_KINDS = new Set<Piece['kind']>(['column', 'wall', 'slab', 'deck']);

function finiteOr(value: number, fallback: number): number {
  return Number.isFinite(value) ? value : fallback;
}

function clamp(value: number, low: number, high: number): number {
  return Math.max(low, Math.min(high, value));
}

function axisFor(kind: Piece['kind'], size: V3, center: V3, hit: V3): number {
  // Columns break along their height. Panels use the in-plane direction nearest
  // the impact edge; this keeps a low wall hit from making a vertical sliver.
  const candidates = kind === 'column' ? [1] : kind === 'wall' ? [0, 1] : [0, 2];
  return candidates.slice().sort((a, b) => {
    const edgeA = Math.abs(hit[a] - center[a]) / Math.max(size[a], 1e-6);
    const edgeB = Math.abs(hit[b] - center[b]) / Math.max(size[b], 1e-6);
    return edgeB - edgeA || a - b;
  })[0];
}

/**
 * Split one local segment around an impact while keeping the distant remainder
 * as a stiff structural body. Coordinates are in the piece's local frame.
 */
export function localFractureShapes(
  piece: Piece,
  hitLocal: V3,
  segmentOverride?: SegmentBounds,
): LocalFragmentShape[] {
  if (piece.kind === 'facade') return fractureShapes(piece);
  if (!LOCAL_KINDS.has(piece.kind)) return [];

  const def = PARTS[piece.kind];
  const source = segmentOverride ?? { ...def.segments[0], mass: def.mass };
  const center: V3 = [...source.center] as V3;
  const size: V3 = source.size.map(value => Math.max(1e-6, finiteOr(value, 1))) as V3;
  const mass = Math.max(0, finiteOr(source.mass, def.mass));
  const parent = { center: [...center] as V3, size: [...size] as V3 };
  const impact: V3 = hitLocal.map((value, axis) => finiteOr(value, center[axis])) as V3;
  const axis = axisFor(piece.kind, size, center, impact);
  const low = center[axis] - size[axis] / 2;
  const high = center[axis] + size[axis] / 2;
  const hit = clamp(impact[axis], low, high);

  // Recursive fracture should bottom out instead of creating unstable slivers.
  if (size[axis] < 0.45 || mass < 15) {
    return [{ center: [...center] as V3, size: [...size] as V3, mass, kick: [0, 0, 0], structural: false, parent }];
  }

  // Keep the damage band narrow, but allow edge hits to produce a valid band.
  const band = Math.min(size[axis] * 0.2, Math.max(size[axis] * 0.08, 0.08));
  let bandLow = Math.max(low, hit - band / 2);
  let bandHigh = Math.min(high, hit + band / 2);
  // Never leave a convex-shape-incompatible structural tail at an edge hit.
  if (bandLow - low < 0.06) bandLow = low;
  if (high - bandHigh < 0.06) bandHigh = high;
  // Keep both rubble halves at least 3 cm thick where the source permits it.
  if (size[axis] >= 0.06 && bandHigh - bandLow < 0.06) {
    bandHigh = Math.min(high, bandLow + 0.06);
    bandLow = Math.max(low, bandHigh - 0.06);
  }
  const cuts: number[] = [low, bandLow, (bandLow + bandHigh) / 2, bandHigh, high];
  const ranges: Array<[number, number, boolean]> = [
    [cuts[0], cuts[1], true],
    [cuts[1], cuts[2], false],
    [cuts[2], cuts[3], false],
    [cuts[3], cuts[4], true],
  ];
  const result: LocalFragmentShape[] = [];
  const epsilon = Math.max(1e-7, size[axis] * 1e-7);
  let usedMass = 0;
  for (const [from, to, structural] of ranges) {
    const length = to - from;
    if (length <= epsilon) continue;
    const partCenter = [...center] as V3;
    const partSize = [...size] as V3;
    partCenter[axis] = (from + to) / 2;
    partSize[axis] = length;
    const partMass = mass * length / size[axis];
    usedMass += partMass;
    result.push({
      center: partCenter,
      size: partSize,
      mass: partMass,
      kick: [0, 0, 0],
      structural,
      parent: { center: [...parent.center] as V3, size: [...parent.size] as V3 },
    });
  }

  // Correct the final floating point residue so callers can conserve mass exactly.
  if (result.length) result[result.length - 1].mass += mass - usedMass;
  const rubble = result.filter(fragment => fragment.structural === false);
  const kickAxis = axis;
  const kickAmount = Math.min(1.25, Math.max(0.2, size[axis] * 0.16));
  if (rubble.length === 2) {
    rubble[0].kick[kickAxis] = -kickAmount;
    rubble[1].kick[kickAxis] = kickAmount;
  } else if (rubble.length === 1) {
    rubble[0].kick[kickAxis] = hit >= center[axis] ? kickAmount : -kickAmount;
  }
  return result.slice(0, 4);
}
