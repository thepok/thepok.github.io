import * as THREE from 'three';
import {MeshBasicNodeMaterial} from 'three/webgpu';
import {attribute, texture, uv} from 'three/tsl';

/** Fixed visual pool: no bodies, collisions, shadows, or queued emissions. */
export class ConcreteDust {
 readonly capacity=96;
 readonly mesh:THREE.InstancedMesh;
 readonly stats={emitted:0,active:0,dropped:0};
 private births=new Float64Array(this.capacity).fill(-100);
 private centers=new Float32Array(this.capacity*3);
 private sizes=new Float32Array(this.capacity);
 private opacity=new THREE.InstancedBufferAttribute(new Float32Array(this.capacity),1);
 private next=0;private window=-1;private emittedInWindow=0;
 private matrix=new THREE.Matrix4();private position=new THREE.Vector3();private scale=new THREE.Vector3();
 time=0;
 constructor(backend:string){
  const canvas=document.createElement('canvas');canvas.width=canvas.height=64;
  const ctx=canvas.getContext('2d')!;
  const gradient=ctx.createRadialGradient(32,32,2,32,32,31);
  gradient.addColorStop(0,'rgba(255,255,255,.8)');gradient.addColorStop(.45,'rgba(255,255,255,.38)');gradient.addColorStop(1,'rgba(255,255,255,0)');
  ctx.fillStyle=gradient;ctx.fillRect(0,0,64,64);
  const map=new THREE.CanvasTexture(canvas);
  const geometry=new THREE.PlaneGeometry(1,1);geometry.setAttribute('dustOpacity',this.opacity);
  let material:THREE.Material;
  if(backend==='webgpu'){
   const m=new MeshBasicNodeMaterial({color:'#b8b09b',transparent:true,depthWrite:false,side:THREE.DoubleSide});
   m.opacityNode=texture(map,uv()).a.mul(attribute('dustOpacity','float'));material=m;
  }else{
   const m=new THREE.MeshBasicMaterial({color:'#b8b09b',map,transparent:true,depthWrite:false,side:THREE.DoubleSide});
   m.onBeforeCompile=shader=>{shader.vertexShader='attribute float dustOpacity; varying float vDustOpacity;\n'+shader.vertexShader;shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nvDustOpacity=dustOpacity;');shader.fragmentShader='varying float vDustOpacity;\n'+shader.fragmentShader;shader.fragmentShader=shader.fragmentShader.replace('#include <alphamap_fragment>','#include <alphamap_fragment>\ndiffuseColor.a*=vDustOpacity;');};
   m.customProgramCacheKey=()=> 'concrete-dust-1';material=m;
  }
  this.mesh=new THREE.InstancedMesh(geometry,material,this.capacity);this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);this.opacity.setUsage(THREE.DynamicDrawUsage);
  this.mesh.frustumCulled=false;this.mesh.renderOrder=4;this.mesh.visible=false;
 }
 spawn(x:number,y:number,z:number,time:number,strength=1){
  const window=Math.floor(time*10);if(window!==this.window){this.window=window;this.emittedInWindow=0;}
  const count=Math.min(4,Math.max(1,Math.ceil(strength*2)),12-this.emittedInWindow);
  if(count<=0){this.stats.dropped++;return;}
  this.emittedInWindow+=count;
  for(let n=0;n<count;n++){
   const i=this.next++%this.capacity,angle=i*2.39996;
   this.births[i]=time;this.centers[i*3]=x+Math.cos(angle)*.35;this.centers[i*3+1]=y;this.centers[i*3+2]=z+Math.sin(angle)*.35;
   this.sizes[i]=Math.min(2.4,.7+strength*.35+(i%5)*.12);this.stats.emitted++;
  }
 }
 update(time:number,camera:THREE.Camera){
  this.time=time;let active=0;
  for(let i=0;i<this.capacity;i++){
   const age=time-this.births[i],life=2.4+(i%4)*.25;
   if(age<0||age>=life){if(this.opacity.getX(i)!==0)this.opacity.setX(i,0);continue;}
   active++;const t=age/life,fade=Math.min(1,age*10)*(1-t)*(1-t),spread=this.sizes[i]*(1+age*.6);
   this.position.set(this.centers[i*3]+Math.cos(i*2.39996)*age*.38,this.centers[i*3+1]+age*.34,this.centers[i*3+2]+Math.sin(i*2.39996)*age*.38);
   this.scale.setScalar(spread);this.matrix.compose(this.position,camera.quaternion,this.scale);this.mesh.setMatrixAt(i,this.matrix);
   // Near-camera clouds remain translucent rather than covering the screen.
   this.opacity.setX(i,fade*.34*Math.min(1,this.position.distanceTo(camera.position)/5));
  }
  if(active||this.stats.active){this.opacity.needsUpdate=true;this.mesh.instanceMatrix.needsUpdate=true;}
  this.stats.active=active;this.mesh.visible=active>0;
 }
 reset(){this.births.fill(-100);this.opacity.array.fill(0);this.opacity.needsUpdate=true;this.stats.active=0;this.mesh.visible=false;this.time=0;this.window=-1;this.emittedInWindow=0;}
}
