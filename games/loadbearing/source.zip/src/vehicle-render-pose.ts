type Vector={x:number;y:number;z:number;set:(x:number,y:number,z:number)=>any};
type Rotation={x:number;y:number;z:number;w:number;set:(x:number,y:number,z:number,w:number)=>any};
/** Smooth authoritative vehicle poses without predicting beyond the newest packet. */
export function smoothVehiclePose(position:Vector,rotation:Rotation,target:Vector,q:Rotation,dt:number,snap=false){
 const alpha=snap||Math.hypot(position.x-target.x,position.y-target.y,position.z-target.z)>8?1:1-Math.exp(-24*Math.max(0,Math.min(.1,dt)));
 position.set(position.x+(target.x-position.x)*alpha,position.y+(target.y-position.y)*alpha,position.z+(target.z-position.z)*alpha);
 const sign=rotation.x*q.x+rotation.y*q.y+rotation.z*q.z+rotation.w*q.w<0?-1:1;
 const x=rotation.x+(q.x*sign-rotation.x)*alpha,y=rotation.y+(q.y*sign-rotation.y)*alpha,z=rotation.z+(q.z*sign-rotation.z)*alpha,w=rotation.w+(q.w*sign-rotation.w)*alpha,len=Math.hypot(x,y,z,w)||1;
 rotation.set(x/len,y/len,z/len,w/len);
}
