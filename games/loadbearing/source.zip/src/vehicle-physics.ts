import {assertVehicleParts,VEHICLE_PARTS,type VehiclePart} from './vehicle-blueprint';
import {cannonLaunch,CANNON_BALLISTICS} from './cannon-ballistics';
import type {V3} from './catalog';
export class VehiclePhysics{
 controls={throttle:0,steer:0,brake:false,fire:false,yaw:0,pitch:.08};chassis:any;chassisItem:any;fireCooldown=0;
 private wheels:{body:any;motor:any;side:number}[]=[];private constraints:any[]=[];
 constructor(public sim:any,public parts:VehiclePart[],origin:V3=[0,0,20]){
  assertVehicleParts(parts);const J=sim.J,compound=new J.StaticCompoundShapeSettings();
  for(const part of parts.filter(p=>p.kind!=='wheel')){const def=VEHICLE_PARTS[part.kind],half=new J.Vec3(...def.size.map(n=>n/2)),shape=new J.BoxShapeSettings(half,.02),pos=new J.Vec3(...part.p),q=new J.Quat(0,0,0,1);compound.AddShape(pos,q,shape);J.destroy(half);J.destroy(pos);J.destroy(q);}
  const result=compound.Create(),shape=result.Get(),q=new J.Quat(0,0,0,1);this.chassis=sim.makeBody(shape,origin,q,parts.filter(p=>p.kind!=='wheel').reduce((n,p)=>n+VEHICLE_PARTS[p.kind].mass,0));J.destroy(q);J.destroy(result);J.destroy(compound);
  this.chassisItem={id:-50000,kind:'vehicle-chassis',body:this.chassis,initial:origin,stress:0,vehicleParts:parts};sim.items.push(this.chassisItem);
  for(const part of parts.filter(p=>p.kind==='wheel')){
   const pos=origin.map((v,i)=>v+part.p[i]) as V3,shape=new J.CylinderShape(.18,.55,.02);shape.AddRef();const axis=new J.Vec3(0,0,1),q=J.Quat.prototype.sRotation(axis,Math.PI/2),body=sim.makeBody(shape,pos,q,VEHICLE_PARTS.wheel.mass);shape.Release();J.destroy(axis);J.destroy(q);body.SetFriction(.85);
   sim.filter.DisableCollision(this.chassis.GetCollisionGroup().GetSubGroupID(),body.GetCollisionGroup().GetSubGroupID());
   const s=new J.HingeConstraintSettings();s.mPoint1.Set(...pos);s.mPoint2.Set(...pos);s.mHingeAxis1.Set(1,0,0);s.mHingeAxis2.Set(1,0,0);s.mNormalAxis1.Set(0,1,0);s.mNormalAxis2.Set(0,1,0);s.mMotorSettings.mMinTorqueLimit=-1600;s.mMotorSettings.mMaxTorqueLimit=1600;
   const motor=J.castObject(s.Create(this.chassis,body),J.HingeConstraint);sim.system.AddConstraint(motor);J.destroy(s);this.constraints.push(motor);this.wheels.push({body,motor,side:Math.sign(part.p[0])});sim.items.push({id:-50001-this.wheels.length,kind:'vehicle-wheel',body,initial:pos,stress:0,vehiclePart:part});
  }
 }
 step(dt:number){const J=this.sim.J,c=this.controls,throttle=Math.max(-1,Math.min(1,c.throttle)),steer=Math.max(-1,Math.min(1,c.steer));
  for(const wheel of this.wheels){if(throttle||steer||c.brake)this.sim.bodies.ActivateBody(wheel.body.GetID());wheel.motor.SetMotorState(throttle||steer||c.brake?J.EMotorState_Velocity:J.EMotorState_Off);wheel.motor.SetTargetAngularVelocity(c.brake?0:-(throttle*24+steer*wheel.side*12));}
  if(steer&&this.wheels.some(w=>this.sim.system.WereBodiesInContact(w.body.GetID(),this.sim.ground.GetID()))){this.sim.bodies.ActivateBody(this.chassis.GetID());const torque=new J.Vec3(0,steer*18000,0);this.chassis.AddTorque(torque);J.destroy(torque);}
  this.fireCooldown=Math.max(0,this.fireCooldown-dt);if(c.fire&&this.fireCooldown===0)this.fire();
 }
 // Gameplay recoil is capped independently of shell momentum to keep the vehicle controllable.
 private fire(){for(const cannon of this.parts.filter(p=>p.kind==='cannon')){
  const rotation=this.chassis.GetRotation(),q=[rotation.GetX(),rotation.GetY(),rotation.GetZ(),rotation.GetW()],p=this.chassis.GetPosition(),v=this.chassis.GetLinearVelocity();
  const {muzzle,velocity,direction}=cannonLaunch(cannon.p,[p.GetX(),p.GetY(),p.GetZ()],q,[v.GetX(),v.GetY(),v.GetZ()],this.controls.yaw,this.controls.pitch);
  const shot=this.sim.launchProjectile(muzzle,velocity,CANNON_BALLISTICS.mass,CANNON_BALLISTICS.radius);if(shot){shot.body.GetMotionProperties().SetLinearDamping(CANNON_BALLISTICS.linearDamping);const J=this.sim.J,impulse=new J.Vec3(...direction.map(n=>-n*2000));this.sim.bodies.ActivateBody(this.chassis.GetID());this.chassis.AddImpulse(impulse);J.destroy(impulse);}this.fireCooldown=1.1;}
 }

 dispose(){for(const c of this.constraints)this.sim.system.RemoveConstraint(c);this.constraints=[];}
}
