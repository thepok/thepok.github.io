// Finish static-host isolation before loading the renderer or physics workers.
async function boot() {
  const key = 'loadbearing.isolation-reload';
  if (!crossOriginIsolated && 'serviceWorker' in navigator && isSecureContext) {
    try {
      const registration = await navigator.serviceWorker.register(
        new URL('isolation-sw.js', document.baseURI), { scope: new URL('./', document.baseURI).pathname });
      await Promise.race([
        new Promise<void>(resolve => {
          if (navigator.serviceWorker.controller?.scriptURL === new URL('isolation-sw.js', registration.scope).href) return resolve();
          navigator.serviceWorker.addEventListener('controllerchange', () => resolve(), { once: true });
        }),
        new Promise<void>(resolve => setTimeout(resolve, 8000)),
      ]);
      if (navigator.serviceWorker.controller && !sessionStorage.getItem(key)) {
        sessionStorage.setItem(key, '1');
        location.reload();
        return;
      }
    } catch (error) { console.warn('Static-host isolation unavailable; using compatible physics.', error); }
  }
  if (crossOriginIsolated) sessionStorage.removeItem(key);
  await import('./main');
}
void boot();
