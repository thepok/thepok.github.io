// Finish static-host isolation before loading the renderer or physics workers.
declare const __BUILD_VERSION__: string;
async function boot() {
  const status=(text:string)=>{const el=document.getElementById('boot-status');if(el)el.textContent=text;};
  status('Mehrkern-Physik wird eingerichtet …');
  const key = 'loadbearing.isolation-reload';
  if ('serviceWorker' in navigator && isSecureContext) {
    try {
      const scriptURL = new URL(`isolation-sw.js?v=${__BUILD_VERSION__}`, document.baseURI);
      await navigator.serviceWorker.register(scriptURL,
        { scope: new URL('./', document.baseURI).pathname, updateViaCache: 'none' });
      if (!crossOriginIsolated) {
      await Promise.race([
        new Promise<void>(resolve => {
          if (navigator.serviceWorker.controller?.scriptURL === scriptURL.href) return resolve();
          navigator.serviceWorker.addEventListener('controllerchange', () => resolve(), { once: true });
        }),
        new Promise<void>(resolve => setTimeout(resolve, 8000)),
      ]);
      if (navigator.serviceWorker.controller && !sessionStorage.getItem(key)) {
        sessionStorage.setItem(key, '1');
        location.reload();
        return;
      }
      }
    } catch (error) { console.warn('Static-host isolation unavailable; using compatible physics.', error); }
  }
  if (crossOriginIsolated) sessionStorage.removeItem(key);
  status('Spielpaket wird geladen …');
  const main=await import('./main');
  status('Grafik und Spielwelt werden vorbereitet …');
  await main.startupReady;
  document.getElementById('boot-screen')?.remove();
}
void boot().catch(error=>{console.error('Game startup failed',error);document.getElementById('boot-status')!.textContent='Das Spiel konnte nicht gestartet werden.';document.getElementById('boot-note')!.textContent='Bitte prüfe die Verbindung und lade das Spiel erneut.';const retry=document.getElementById('boot-retry')!;retry.hidden=false;retry.onclick=()=>location.reload();});
