import initJolt from 'jolt-physics';
import { VehiclePhysics } from './vehicle-physics';
import type { VehiclePart } from './vehicle-blueprint';
import { PARTS, ports, SCENARIOS, type Piece, type Scenario, type V3 } from './catalog';
import { evaluateBuilding } from './building-objective';
import { fractureShapes, rotateByQuaternion } from './fracture';
import { PhysicalTrees, type TreeSpec } from './physical-trees';
import { OccupancyLoad } from './occupancy';

// Keep the WASM boundary in one module; Jolt objects must be explicitly released.
let modulePromise: ReturnType<typeof initJolt> | undefined;
export const loadPhysics = () => modulePromise ??= initJolt();
export const HOUSE_DISPLACEMENT_LIMIT = .5;
const HUB_PRIORITY:Record<string,number>={foundation:0,column:1,deck:2,slab:3,wall:4,truss:5,girder:6,brace:7,facade:8};
const REINFORCED_KINDS=new Set(['foundation','column','slab','wall','deck']);
// Break points are in the surviving body's local space, matching Joint.localA/localB.
export interface BreakRemnant { point:V3; sourceKind:string; sourceFinish?:Piece['finish']; seed:number }
export interface DynamicItem { body:any; id:number; kind:string; initial:V3; stress:number; radius?:number; impactMass?:number; fractured?:boolean; retired?:boolean; size?:V3; finish?:Piece['finish']; sourceKind?:string; bornAt?:number; remnants?:BreakRemnant[]; rebarTo?:number; rebarLinks?:{id:number;to:number;localA:V3;localB:V3}[] }
export interface SimulationRules {
 vehicleParts?:VehiclePart[];
 vehicleMass?: number;
 duration?: number;
 minHeight?: number;
 minFloorArea?: number;
 rockCount?: number;
 rockInterval?: number;
 aftershock?: boolean;
 occupancy?: boolean;
 sandbox?: boolean;
 fragmentLimit?: number;
}
interface Joint { constraint:any; a:DynamicItem; b?:DynamicItem; force:number; torque:V3; pinned:boolean; broken:boolean; stress:number; overloadTime:number; localA:V3[]; localB?:V3[]; groupA?:number; groupB?:number }
interface RebarLink { constraint:any; a:DynamicItem; b:DynamicItem; id:number; localA:V3; localB:V3; limit:number; strength:number; broken:boolean; overloadTime:number }
export class Simulation {
 J:any; world:any; system:any; bodies:any; filter:any; items:DynamicItem[]=[]; joints:Joint[]=[]; rebars:RebarLink[]=[]; private nextRebarId=0; bodyList:any[]=[];
 vehicle?:VehiclePhysics;
 driveConstraints:any[]=[];
 trees?:PhysicalTrees;
 attachTrees(specs:TreeSpec[]){if(!this.trees)this.trees=new PhysicalTrees(this,specs);}
 fragments=0; private nextFragmentId=0; fragmentLimit:number; removedBodies=new Set<any>();
 jointCounts=new Map<string,number>();attachmentCounts=new Map<number,number>();jointNeighbors=new Map<number,Joint[]>();
 pendingCollisions=new Map<string,{a:any;b:any}>();
 projectileHits=new Set<string>();
 sandboxHazards={wind:false,earthquake:false,flood:false,meteors:false};
 meteors=0; meteorPool:DynamicItem[]=[]; private nextMeteorAt=0;
 private quakeResetSteps=0;
 private hazardStart={wind:0,earthquake:0,flood:0,meteors:0};
 hazardAge(kind:'wind'|'earthquake'|'flood'|'meteors'){return this.rules.sandbox?this.elapsed-this.hazardStart[kind]:this.elapsed;}
 hazardActive(kind:'wind'|'earthquake'|'flood'|'meteors'){return this.rules.sandbox?this.sandboxHazards[kind]:this.scenario===kind;}
 setSandboxHazard(kind:'wind'|'earthquake'|'flood'|'meteors',enabled:boolean){
  if(!this.rules.sandbox)return;
  if(enabled&&!this.sandboxHazards[kind])this.hazardStart[kind]=this.elapsed;
  if(kind==='earthquake'&&enabled)this.bodies.SetMotionType(this.ground.GetID(),this.J.EMotionType_Kinematic,this.J.EActivation_Activate);
  this.sandboxHazards[kind]=enabled;
  if(kind==='meteors'&&enabled)this.nextMeteorAt=this.elapsed+.2;
  if(kind==='earthquake'&&!enabled)this.quakeResetSteps=2;
  for(const item of this.items)if(!item.fractured)this.bodies.ActivateBody(item.body.GetID());
 }

 ground:any; truck?:DynamicItem; house?:DynamicItem; occupancy?:OccupancyLoad; elapsed=0; broken=0; maxStress=0; peakStress=0; duration:number; result:'passed'|'failed'|null=null; reason=''; water=-8; rocks=0; physicsMs=0; projectiles=0; readonly rules:SimulationRules; forceVector:any;
 constructor(J:any, public pieces:Piece[], public scenario:Scenario, public intensity=1, rules:SimulationRules = {}, workerThreads=0) {
  this.J=J; this.rules=rules;this.fragmentLimit=Math.max(24,Math.min(3000,Math.round(rules.fragmentLimit??156)));this.duration=rules.duration ?? SCENARIOS[scenario].duration; this.forceVector=new J.Vec3(0,0,0);
  const settings=new J.JoltSettings();settings.mMaxWorkerThreads=Math.max(0,Math.min(8,workerThreads));
  const pair=new J.ObjectLayerPairFilterTable(2); pair.EnableCollision(0,1); pair.EnableCollision(1,1);
  const broad=new J.BroadPhaseLayerInterfaceTable(2,2); const b0=new J.BroadPhaseLayer(0),b1=new J.BroadPhaseLayer(1); broad.MapObjectToBroadPhaseLayer(0,b0); broad.MapObjectToBroadPhaseLayer(1,b1);
  settings.mObjectLayerPairFilter=pair; settings.mBroadPhaseLayerInterface=broad;
  settings.mObjectVsBroadPhaseLayerFilter=new J.ObjectVsBroadPhaseLayerFilterTable(broad,2,pair,2);
  this.world=new J.JoltInterface(settings); J.destroy(settings); J.destroy(b0); J.destroy(b1);
  this.system=this.world.GetPhysicsSystem(); this.bodies=this.system.GetBodyInterface();
  const ps=this.system.GetPhysicsSettings(),large=pieces.length>=800,medium=pieces.length>=400;ps.mNumVelocitySteps=large?12:medium?16:48;ps.mNumPositionSteps=large?3:medium?4:12;this.system.SetPhysicsSettings(ps);
  this.filter=new J.GroupFilterTable(8192); this.filter.AddRef();
  if(scenario==='bridge') {
   this.ground=this.box([-23,-4,0],[22,8,28],0); this.box([23,-4,0],[22,8,28],0); this.box([0,-10,0],[100,2,100],0);
  } else {
   this.ground=this.box([0,-1,0],[1000,2,1000],0,scenario==='earthquake');
   if(rules.sandbox)for(const side of [-1,1]){this.box([0,1,side*498],[1000,4,3],0);this.box([side*498,1,0],[3,4,1000],0);}
   if(scenario==='landslide') { this.box([0,5,-19],[30,.8,24],0,false,.51); this.house=this.dynamicBox([-900,'house'],[0,1.6,5],[3.2,3.2,3.2],18000); }
  }
  const portMap=new Map<string,DynamicItem[]>(),pieceById=new Map(pieces.map(piece=>[piece.id,piece])),portsById=new Map(pieces.map(piece=>[piece.id,ports(piece)])),shapeCache=new Map<string,any>();
  for(const p of pieces) {
   const def=PARTS[p.kind];let shape=shapeCache.get(p.kind);
   if(!shape){const cs=new J.StaticCompoundShapeSettings();for(const s of def.segments){const half=new J.Vec3(...s.size.map(n=>n/2)),partShape=new J.BoxShapeSettings(half,.02);J.destroy(half);const pos=new J.Vec3(...s.center),axis=new J.Vec3(0,0,1),partRotation=J.Quat.prototype.sRotation(axis,s.tilt??0);cs.AddShape(pos,partRotation,partShape);J.destroy(pos);J.destroy(partRotation);J.destroy(axis);}const result=cs.Create();shape=result.Get();shape.AddRef();shapeCache.set(p.kind,shape);J.destroy(result);J.destroy(cs);}
   const axis=new J.Vec3(0,1,0); const q=J.Quat.prototype.sRotation(axis,p.rotation*Math.PI/2); J.destroy(axis);
   const body=this.makeBody(shape,p.p,q,def.mass); J.destroy(q);
   const item:DynamicItem={body,id:p.id,kind:p.kind,initial:[...p.p],stress:0,finish:p.finish}; this.items.push(item);
   for(const port of portsById.get(p.id)!) { const key=port.map(n=>Math.round(n*100)).join(','); const list=portMap.get(key)??[]; list.push(item); portMap.set(key,list); }
  }
  for(const shape of shapeCache.values())shape.Release();
  const connections=new Map<string,{a:DynamicItem;b:DynamicItem;points:V3[]}>(),collisionPairs=new Set<string>();
  for(const [key,items] of portMap) {
   const p=key.split(',').map(n=>Number(n)/100) as V3;
   const ordered=[...new Map(items.map(item=>[item.id,item])).values()].sort((a,b)=>(HUB_PRIORITY[a.kind]??99)-(HUB_PRIORITY[b.kind]??99)||a.id-b.id),hub=ordered[0];
   for(let i=0;i<ordered.length;i++)for(let j=i+1;j<ordered.length;j++)collisionPairs.add([ordered[i].id,ordered[j].id].sort((a,b)=>a-b).join(':'));
   const connect=(a:DynamicItem,b:DynamicItem)=>{const k=[a.id,b.id].sort((x,y)=>x-y).join(':'),connection=connections.get(k)??{a,b,points:[]};connection.points.push(p);connections.set(k,connection);};
   if(pieces.length<400){for(let i=0;i<ordered.length;i++)for(let j=i+1;j<ordered.length;j++)connect(ordered[i],ordered[j]);}
   else for(const item of ordered.slice(1))connect(hub,item);
  }
  for(const {a,b,points} of connections.values()) {
   const center=points.reduce((sum,p)=>sum.map((v,i)=>v+p[i]/points.length) as V3,[0,0,0] as V3);
   // Road panels attach through bearings rather than moment welds. Multiple
   // pins preserve panel width while allowing each support to carry its load.
   if(a.kind==='deck'||b.kind==='deck')for(const p of points)this.join(a,b,p,[p],true);
   else this.join(a,b,center,points);
  }
  const structuralById=new Map(this.items.filter(item=>item.id>0).map(item=>[item.id,item]));for(const pair of collisionPairs){const [a,b]=pair.split(':').map(Number),left=structuralById.get(a),right=structuralById.get(b);if(left&&right)this.filter.DisableCollision(left.body.GetCollisionGroup().GetSubGroupID(),right.body.GetCollisionGroup().GetSubGroupID());}
  for(const item of this.items) {
   if(item.id<0)continue; const p=pieceById.get(item.id)!;
   const anchors=portsById.get(item.id)!.filter(v=>Math.abs(v[1])<.01 && (scenario==='bridge'?Math.abs(v[0])>=11.99&&Math.abs(v[0])<=34&&Math.abs(v[2])<=14:p.kind==='foundation'&&Math.abs(v[0])<=40&&Math.abs(v[2])<=40));
   if(anchors.length){const center=anchors.reduce((sum,p)=>sum.map((v,i)=>v+p[i]/anchors.length) as V3,[0,0,0] as V3);const support=scenario==='bridge'&&center[0]>0?this.bodyList[1]:this.ground;if(scenario==='bridge')for(const p of anchors)this.join(item,undefined,p,[p],true,support);else this.join(item,undefined,center,anchors);
    // Embedded bearings and foundations intentionally overlap their support.
    // Contact resolution must not fight the attachment holding them there.
    this.filter.DisableCollision(item.body.GetCollisionGroup().GetSubGroupID(),support.GetCollisionGroup().GetSubGroupID());
   }
  }
  if(rules.vehicleParts?.length&&rules.sandbox)this.vehicle=new VehiclePhysics(this,rules.vehicleParts);
  if(scenario==='bridge') this.createTruck((rules.vehicleMass ?? 12000)*intensity);
  if((scenario as string)==='occupancy' || rules.occupancy) this.occupancy=new OccupancyLoad(this);
 }
 makeBody(shape:any,p:V3,q:any,mass:number,kinematic=false,debris=false) {
  const J=this.J,pos=new J.RVec3(...p); const settings=new J.BodyCreationSettings(shape,pos,q,mass>0?J.EMotionType_Dynamic:kinematic?J.EMotionType_Kinematic:J.EMotionType_Static,mass>0||kinematic?1:0); J.destroy(pos);
  settings.mAllowDynamicOrKinematic=true;settings.mFriction=mass>0?.55:.7; settings.mRestitution=.03;
  if(mass>0) { settings.mOverrideMassProperties=J.EOverrideMassProperties_CalculateInertia; settings.mMassPropertiesOverride.mMass=mass; settings.mLinearDamping=.08; settings.mAngularDamping=.14; settings.mAllowSleeping=!!this.rules.sandbox||debris; settings.mMotionQuality=J.EMotionQuality_LinearCast;
  }
  settings.mCollisionGroup.SetGroupFilter(this.filter); settings.mCollisionGroup.SetGroupID(1); settings.mCollisionGroup.SetSubGroupID(this.bodyList.length);
  const body=this.bodies.CreateBody(settings); this.bodies.AddBody(body.GetID(),J.EActivation_Activate); J.destroy(settings); this.bodyList.push(body); return body;
 }
 box(p:V3,size:V3,mass:number,kinematic=false,tilt=0) { const J=this.J,half=new J.Vec3(...size.map(n=>n/2)),shape=new J.BoxShape(half,.03); J.destroy(half); shape.AddRef(); const ax=new J.Vec3(1,0,0),q=J.Quat.prototype.sRotation(ax,tilt); J.destroy(ax); const b=this.makeBody(shape,p,q,mass,kinematic); J.destroy(q); shape.Release(); return b; }
 dynamicBox([id,kind]:[number,string],p:V3,size:V3,mass:number) { const item:DynamicItem={body:this.box(p,size,mass),id,kind,initial:p,stress:0}; if(kind==='truck')item.body.SetFriction(.16); this.items.push(item); return item; }
 createTruck(mass:number) {
  const J=this.J,wheelMass=mass*.01;this.truck=this.dynamicBox([-800,'truck'],[-20,1,0],[3.6,.75,2.05],mass-wheelMass*4);
  for(const x of [-1.15,1.1])for(const z of [-1.1,1.1]){
   const p:V3=[-20+x,.65,z],shape=new J.CylinderShape(.13,.44,.02);shape.AddRef();const axis=new J.Vec3(1,0,0),q=J.Quat.prototype.sRotation(axis,Math.PI/2);J.destroy(axis);
   const wheel=this.makeBody(shape,p,q,wheelMass);J.destroy(q);shape.Release();wheel.SetFriction(1.1);
   this.filter.DisableCollision(this.truck.body.GetCollisionGroup().GetSubGroupID(),wheel.GetCollisionGroup().GetSubGroupID());
   const settings=new J.HingeConstraintSettings();settings.mPoint1.Set(...p);settings.mPoint2.Set(...p);settings.mHingeAxis1.Set(0,0,1);settings.mHingeAxis2.Set(0,0,1);settings.mNormalAxis1.Set(1,0,0);settings.mNormalAxis2.Set(1,0,0);
   settings.mMotorSettings.mMinTorqueLimit=-mass*.22;settings.mMotorSettings.mMaxTorqueLimit=mass*.22;
   const hinge=J.castObject(settings.Create(this.truck.body,wheel),J.HingeConstraint);this.system.AddConstraint(hinge);J.destroy(settings);hinge.SetMotorState(J.EMotorState_Velocity);hinge.SetTargetAngularVelocity(0);this.driveConstraints.push(hinge);
  }
 }
  join(a:DynamicItem,b:DynamicItem|undefined,p:V3,points:V3[]=[p],pinned=false,support=this.ground) {
  const J=this.J, settings=pinned?new J.PointConstraintSettings():new J.SixDOFConstraintSettings();
  if(pinned){settings.mPoint1.Set(...p);settings.mPoint2.Set(...p);}else{for(let axis=0;axis<6;axis++) settings.MakeFixedAxis(axis);settings.mPosition1.Set(...p);settings.mPosition2.Set(...p);}
  const constraint=J.castObject(settings.Create(a.body,b?.body??support),pinned?J.PointConstraint:J.SixDOFConstraint); this.system.AddConstraint(constraint); J.destroy(settings);
  const da=PARTS[a.kind as keyof typeof PARTS], db=b?PARTS[b.kind as keyof typeof PARTS]:da;
  const groupA=a.body.GetCollisionGroup().GetSubGroupID();
  const groupB=(b?.body??support).GetCollisionGroup().GetSubGroupID();
  // Distributed sockets resist moments through their actual lever arms.
  // Collinear contacts strengthen only the rotation axes they can resist.
  const socketForce=Math.min(da.force,db.force),socketTorque=Math.min(da.torque,db.torque);
  const torque=([0,1,2] as const).map(axis=>points.reduce((n,point)=>n+socketTorque+socketForce*Math.hypot(...point.map((v,i)=>i===axis?0:v-p[i])),0)) as V3;
  const joint:Joint={constraint,a,b,force:socketForce*points.length,torque,pinned,broken:false,stress:0,overloadTime:0,localA:points.map(point=>this.bodyLocalPoint(a,point)),localB:b?points.map(point=>this.bodyLocalPoint(b,point)):undefined,groupA,groupB};this.joints.push(joint);
  const key=`${groupA}:${groupB}`;this.jointCounts.set(key,(this.jointCounts.get(key)??0)+1);
  for(const item of b?[a,b]:[a]){this.attachmentCounts.set(item.id,(this.attachmentCounts.get(item.id)??0)+1);const neighbors=this.jointNeighbors.get(item.id)??[];neighbors.push(joint);this.jointNeighbors.set(item.id,neighbors);}

 }
 bodyLocalPoint(item:DynamicItem,point:V3):V3 {
  const p=item.body.GetPosition(),q=item.body.GetRotation();
  return rotateByQuaternion([point[0]-p.GetX(),point[1]-p.GetY(),point[2]-p.GetZ()],[-q.GetX(),-q.GetY(),-q.GetZ(),q.GetW()]);
 }
 addBreakRemnants(item:DynamicItem,points:V3[],source:DynamicItem){
  if(item.id<=0||item.fractured)return;
  const remnants=item.remnants??=[];
  for(const point of points){
   if(remnants.length>=4)break;
   if(remnants.some(remnant=>Math.hypot(remnant.point[0]-point[0],remnant.point[1]-point[1],remnant.point[2]-point[2])<.22))continue;
   remnants.push({point:[...point],sourceKind:source.kind,sourceFinish:source.finish,seed:Math.imul(item.id,73856093)^Math.imul(source.id,19349663)^remnants.length*83492791});
  }
 }
 force(item:DynamicItem,x:number,y:number,z:number) { if((x||y||z)&&!item.body.IsActive())this.bodies.ActivateBody(item.body.GetID());this.forceVector.Set(x,y,z); item.body.AddForce(this.forceVector); }
 spawnRock() {
  const J=this.J,n=this.rocks++,r=.65+(Math.sin(n*13.7)+1)*.36,x=Math.sin(n*4.17)*3.2;
  const shape=new J.SphereShape(r); shape.AddRef(); const q=new J.Quat(0,0,0,1); const body=this.makeBody(shape,[x,9+n%3,-20],q,2600*r*r*r*this.intensity); J.destroy(q); shape.Release();
  const vel=new J.Vec3(Math.sin(n)*.5,0,7*this.intensity); body.SetLinearVelocity(vel); J.destroy(vel); body.SetRestitution(.18);
  this.items.push({id:-1000-n,kind:'rock',body,initial:[x,9,-20],stress:0,radius:r});
 }
 spawnMeteor(){
  const J=this.J,n=this.meteors++,slot=n%24;
  const footprint=this.pieces.flatMap(p=>ports(p));
  const xs=footprint.map(p=>p[0]),zs=footprint.map(p=>p[2]);
  const minX=Math.min(0,...xs)-3,maxX=Math.max(0,...xs)+3,minZ=Math.min(0,...zs)-3,maxZ=Math.max(0,...zs)+3;
  const top=Math.max(8,...footprint.map(p=>p[1]));
  const random=(salt:number)=>{const v=Math.sin((n+1)*127.1+salt*311.7)*43758.5453;return v-Math.floor(v);};
  const x=minX+random(1)*(maxX-minX),z=minZ+random(2)*(maxZ-minZ),vx=5+random(3)*5,vz=3+random(4)*5;
  const position:V3=[x-vx*.9,top+30,z-vz*.9];
  let item=this.meteorPool[slot];
  if(!item){const radius=.55+(Math.sin(slot*4.17)+1)*.27,shape=new J.SphereShape(radius);shape.AddRef();const q=new J.Quat(0,0,0,1);const body=this.makeBody(shape,position,q,1800*radius**3);J.destroy(q);shape.Release();body.SetRestitution(.08);item={id:-4000-slot,kind:'meteor',body,initial:position,radius,stress:0};this.items.push(item);this.meteorPool.push(item);}
  else {const p=new J.RVec3(...position),q=new J.Quat(0,0,0,1);this.bodies.SetPositionAndRotation(item.body.GetID(),p,q,J.EActivation_Activate);J.destroy(p);J.destroy(q);}
  item.bornAt=this.elapsed;const velocity=new J.Vec3(vx,-29-4*this.intensity,vz);item.body.SetLinearVelocity(velocity);velocity.Set(0,0,0);item.body.SetAngularVelocity(velocity);J.destroy(velocity);
 }
 launchProjectile(position:V3, velocity:V3, mass:number, radius:number):DynamicItem|undefined {
  if(this.projectiles>=60)return undefined;
  const J=this.J, n=this.projectiles++, r=Math.max(.08,Math.min(3,radius)), m=Math.max(.1,mass);
  const shape=new J.SphereShape(r); shape.AddRef(); const q=new J.Quat(0,0,0,1);
  const body=this.makeBody(shape,position,q,m); J.destroy(q); shape.Release();
  const v=new J.Vec3(...velocity); body.SetLinearVelocity(v); J.destroy(v);
  body.SetRestitution(.12);
  const item:DynamicItem={id:-3000-n,kind:'projectile',body,initial:[...position],stress:0,radius:r,impactMass:m}; this.items.push(item); return item;
 }
 step(dt=1/120) {
  if(this.result)return; const start=performance.now(); this.elapsed+=dt; const t=this.elapsed, J=this.J, ramp=Math.min(1,Math.max(0,(t-1)/3));
  if(this.hazardActive('earthquake')||this.quakeResetSteps>0) {
   if(this.quakeResetSteps>0)this.quakeResetSteps--;
   const aftershock=this.rules.aftershock && t>this.duration*.58;
   const shockEnvelope=aftershock ? 1.8*Math.max(0,1-(t-this.duration*.58)/2) : 0;
   const quakeRamp=Math.min(1,Math.max(0,(this.hazardAge('earthquake')-1)/3));const amp=this.hazardActive('earthquake')?.025*this.intensity*quakeRamp*(1+shockEnvelope):0; const p=new J.RVec3(amp*Math.sin(t*19)+amp*.4*Math.sin(t*31),-1,amp*.65*Math.sin(t*23)); const q=new J.Quat(0,0,0,1); this.bodies.MoveKinematic(this.ground.GetID(),p,q,dt); J.destroy(p); J.destroy(q);
  }
  // Wheel motors generate traction through contacts. The chassis receives no
  // artificial translation or mid-air driving force.
  if(this.truck)for(const hinge of this.driveConstraints)hinge.SetTargetAngularVelocity(t>1?-3.2/.44:0);
  if(this.scenario==='landslide' && t>1 && this.rocks<(this.rules.rockCount ?? 20) && t>1+this.rocks*(this.rules.rockInterval ?? .5)) this.spawnRock();
  if(this.hazardActive('meteors')&&t>=this.nextMeteorAt){this.spawnMeteor();this.nextMeteorAt=t+.85/Math.max(.5,this.intensity);}
  this.occupancy?.update(t);
  const floodRamp=Math.min(1,Math.max(0,(this.hazardAge('flood')-1)/3));
  const waterTarget=this.hazardActive('flood')?-1+floodRamp*6*this.intensity:-8;
  this.water=this.rules.sandbox?this.water+Math.max(-dt*2,Math.min(dt*2,waterTarget-this.water)):waterTarget;
  const wind=this.hazardActive('wind'), flood=this.hazardActive('flood')||(this.rules.sandbox&&this.water>0);
  const gust=wind ? 1+.3*Math.sin(t*3)+.2*Math.sin(t*7) : 0;
  const windForce=wind ? 58*this.intensity*Math.min(1,Math.max(0,(this.hazardAge('wind')-1)/3)) : 0;
  for(const item of this.items) {
   item.stress=0; if(item.fractured || item.id<0 || (!wind && !flood))continue;
   const def=PARTS[item.kind as keyof typeof PARTS];
   if(wind) { const area=((item.kind==='wall'||item.kind==='facade')?16:item.kind==='slab'?2:3); this.force(item,area*.65*windForce*windForce*gust,0,area*.15*windForce*windForce); }
   if(flood) { const p=item.body.GetCenterOfMassPosition(),v=item.body.GetLinearVelocity(); const submerged=Math.max(0,Math.min(1,(this.water-p.GetY()+1)/2)); const volume=def.segments.reduce((n,s)=>n+s.size[0]*s.size[1]*s.size[2],0); this.force(item,submerged*(14500*this.intensity-v.GetX()*1900),submerged*(volume*1000*9.81-v.GetY()*1500),submerged*1000); }
  }
  const projectileSweeps=this.rules.sandbox?this.captureProjectileSweeps():[];
  this.trees?.beforeStep(dt);
  this.vehicle?.step(dt);this.world.Step(dt,1);this.trees?.afterStep(dt);
  this.updateRebars(dt);
  this.fractureProjectileImpacts(projectileSweeps);
  if(this.rules.sandbox&&!this.sandboxHazards.earthquake&&this.quakeResetSteps===0&&this.ground.GetMotionType()===J.EMotionType_Kinematic)this.bodies.SetMotionType(this.ground.GetID(),J.EMotionType_Static,J.EActivation_DontActivate);
  for(const [key,pair] of this.pendingCollisions){if(this.removedBodies.has(pair.a)||this.removedBodies.has(pair.b)){this.pendingCollisions.delete(key);continue;}if(!this.bodiesOverlap(pair.a,pair.b)){this.filter.EnableCollision(pair.a.GetCollisionGroup().GetSubGroupID(),pair.b.GetCollisionGroup().GetSubGroupID());this.pendingCollisions.delete(key);}}
  this.maxStress=0;const fractureCandidates=new Set<DynamicItem>();
  const awake=new Set<number>();for(const item of this.items)if(item.id>0&&!item.fractured&&item.body.IsActive())awake.add(item.id);
  for(const j of this.joints) {
   if(j.broken)continue;
   if(!awake.has(j.a.id)&&(!j.b||!awake.has(j.b.id))){j.stress=0;j.overloadTime=Math.max(0,j.overloadTime-dt*.5);continue;}
   const f=j.constraint.GetTotalLambdaPosition().Length()/dt, torque=j.pinned?null:j.constraint.GetTotalLambdaRotation();
   const stress=torque?Math.max(f/j.force,Math.abs(torque.GetX())/(dt*j.torque[0]),Math.abs(torque.GetY())/(dt*j.torque[1]),Math.abs(torque.GetZ())/(dt*j.torque[2])):f/j.force; j.stress=stress;
   j.a.stress=Math.max(j.a.stress,stress); if(j.b)j.b.stress=Math.max(j.b.stress,stress); this.maxStress=Math.max(this.maxStress,stress);
   // Large impacts fail promptly; small transient solver peaks can settle.
   // Overload accumulation is a uniform game material model, not a mode bonus.
   if(t<.5)j.overloadTime=0;else if(stress>1) j.overloadTime+=dt*(stress-1)*(stress-1); else j.overloadTime=Math.max(0,j.overloadTime-dt*.5);
   if(j.overloadTime>.08&&this.breakJoint(j)){fractureCandidates.add(j.a);if(j.b)fractureCandidates.add(j.b);}
  }
  for(const item of fractureCandidates)if(!item.fractured&&(this.attachmentCounts.get(item.id)??0)===0)this.fracture(item);
  this.peakStress=Math.max(this.peakStress,this.maxStress);
  if(this.truck) { const p=this.truck.body.GetPosition(); if(p.GetY()<-2) this.finish(false,'The truck fell below the road. Reinforce the span and try again.'); else if(p.GetX()>14) this.finish(true,'The test truck made it across. Your bridge carried the load.'); }
  if(this.house) { const p=this.house.body.GetPosition(); if(Math.hypot(p.GetX(),p.GetY()-1.6,p.GetZ()-5)>HOUSE_DISPLACEMENT_LIMIT) this.finish(false,'The house shifted more than 0.5 m. Widen the wall or add stronger buttresses.'); }
  if(!this.rules.sandbox && t>=this.duration && !this.result) {
   const structural=this.items.filter(i=>i.id>0); const moved=structural.filter(i=>{if(i.fractured)return true;const p=i.body.GetPosition();return Math.hypot(p.GetX()-i.initial[0],p.GetY()-i.initial[1],p.GetZ()-i.initial[2])>1.5}).length;
   const building=['earthquake','wind','flood','occupancy'].includes(this.scenario)||!!this.rules.occupancy?this.buildingStatus():null;
   const tall=building?.passed??false;
   const occupancyScenario=!!this.occupancy;
   const slabsAboveGround=this.pieces.some(p=>p.kind==='slab'&&p.p[1]>=4);
   const payload=this.items.filter(i=>i.kind==='payload');
   const retained=payload.length>0&&payload.filter(i=>i.body.GetPosition().GetY()>=i.initial[1]-1.5).length/payload.length>=.75;
   const pass=occupancyScenario ? tall&&slabsAboveGround&&retained&&moved/Math.max(1,structural.length)<.25 : this.scenario!=='bridge' && (this.scenario==='landslide'||tall) && structural.length>0 && moved/structural.length<.25;
   let reason:string;
   if(pass) reason=occupancyScenario?'The occupied floors held their live load and the tower remained stable.':this.scenario==='landslide'?'The barrier held. The house is safe.':'Your structure survived with less than 25% major displacement.';
   else if(building&&!building.passed) reason=building.reason;
   else if(occupancyScenario&&!slabsAboveGround) reason=`The structure must include an occupied floor above ground and reach at least ${this.rules.minHeight ?? 8} m.`;
   else if(occupancyScenario&&!payload.length) reason='No occupancy load was placed on a raised floor.';
   else if(occupancyScenario&&!retained) reason='Too much occupancy load fell from the floors. Add columns and lateral bracing.';
   else reason=this.scenario==='bridge'?'The truck did not reach the far bank.':!tall&&this.scenario!=='landslide'?`The structure must reach at least ${this.rules.minHeight ?? 8} m.`:'Too much of the structure moved or collapsed. Add foundations and lateral bracing.';
   this.finish(pass,reason);
  }
  this.physicsMs=performance.now()-start;
 }
 breakJoint(j:Joint){
  if(j.broken)return false;
  j.constraint.SetEnabled(false);j.broken=true;
  if(j.b){this.addBreakRemnants(j.a,j.localA,j.b);this.addBreakRemnants(j.b,j.localB??[],j.a);}
  const key=`${j.groupA}:${j.groupB}`,remaining=Math.max(0,(this.jointCounts.get(key)??1)-1);this.jointCounts.set(key,remaining);
  for(const item of j.b?[j.a,j.b]:[j.a])this.attachmentCounts.set(item.id,Math.max(0,(this.attachmentCounts.get(item.id)??1)-1));
  if(remaining===0&&j.groupA!==undefined&&j.groupB!==undefined)this.restoreCollisionWhenSeparate(j.a.body,j.b?.body??this.bodyList[j.groupB]);
  if(j.b&&remaining===0&&REINFORCED_KINDS.has(j.a.kind)&&REINFORCED_KINDS.has(j.b.kind)&&!j.a.fractured&&!j.b.fractured){
   const center=(points:V3[])=>points.reduce((out,p)=>out.map((v,i)=>v+p[i]/points.length) as V3,[0,0,0] as V3);
   this.createRebar(j.a,j.b,this.bodyWorldPoint(j.a,center(j.localA)),this.bodyWorldPoint(j.b,center(j.localB!)),.18,220000);
  }
  this.broken++;return true;
 }
 captureProjectileSweeps(){
  const sweeps:{item:DynamicItem;from:V3;speed:number;energy:number}[]=[];
  for(const item of this.items){
   if(item.kind!=='projectile'||item.fractured)continue;
   const p=item.body.GetPosition(),v=item.body.GetLinearVelocity(),speed=Math.hypot(v.GetX(),v.GetY(),v.GetZ());
   sweeps.push({item,from:[p.GetX(),p.GetY(),p.GetZ()],speed,energy:.5*(item.impactMass??0)*speed*speed});
  }
  return sweeps;
 }
 fractureProjectileImpacts(sweeps:{item:DynamicItem;from:V3;speed:number;energy:number}[]){
  // A fast heavy projectile can punch through a reinforced floor even while
  // other bearings still hold it. Ordinary gravity, occupancy and low-energy
  // bumps continue to use the joint fatigue model above.
  for(const sweep of sweeps){
   if(sweep.speed<12||sweep.energy<750000)continue;
   const p=sweep.item.body.GetPosition(),to:[number,number,number]=[p.GetX(),p.GetY(),p.GetZ()];
   let hit:DynamicItem|undefined,first=Infinity;
   for(const target of this.items){
    if(target.id<=0||(target.kind!=='slab'&&target.kind!=='deck')||target.fractured)continue;
    const key=`${sweep.item.id}:${target.id}`;if(this.projectileHits.has(key))continue;
    const bounds=target.body.GetWorldSpaceBounds(),lo=bounds.mMin,hi=bounds.mMax;
    const min:V3=[lo.GetX(),lo.GetY(),lo.GetZ()],max:V3=[hi.GetX(),hi.GetY(),hi.GetZ()];
    // Jolt resolves the contact and can move both bodies apart before we read
    // their post-step poses, so keep a small solver travel allowance here.
    const contact=this.segmentAabbHit(sweep.from,to,min,max,(sweep.item.radius??0)+.35);
    if(contact<first){first=contact;hit=target;}
   }
   if(!hit)continue;
   this.projectileHits.add(`${sweep.item.id}:${hit.id}`);
   for(const joint of this.jointNeighbors.get(hit.id)??[])this.breakJoint(joint);
   this.fracture(hit);
  }
 }
 segmentAabbHit(from:V3,to:V3,min:V3,max:V3,margin:number){
  let near=0,far=1;
  for(let axis=0;axis<3;axis++){
   const delta=to[axis]-from[axis],low=min[axis]-margin,high=max[axis]+margin;
   if(Math.abs(delta)<1e-9){if(from[axis]<low||from[axis]>high)return Infinity;continue;}
   let a=(low-from[axis])/delta,b=(high-from[axis])/delta;if(a>b)[a,b]=[b,a];
   near=Math.max(near,a);far=Math.min(far,b);if(near>far)return Infinity;
  }
  return near;
 }
 bodiesOverlap(a:any,b:any){
  // Jolt's returned value wrappers can share temporary storage: snapshot before the next call.
  const bounds=a.GetWorldSpaceBounds(),lo=bounds.mMin;
  const ax=lo.GetX(),ay=lo.GetY(),az=lo.GetZ(),hi=bounds.mMax;
  const bx=hi.GetX(),by=hi.GetY(),bz=hi.GetZ();
  const other=b.GetWorldSpaceBounds(),min=other.mMin;
  const cx=min.GetX(),cy=min.GetY(),cz=min.GetZ(),max=other.mMax;
  return ax<=max.GetX()&&bx>=cx&&ay<=max.GetY()&&by>=cy&&az<=max.GetZ()&&bz>=cz;
 }
 restoreCollisionWhenSeparate(a:any,b:any){
  const ga=a.GetCollisionGroup().GetSubGroupID(),gb=b.GetCollisionGroup().GetSubGroupID();
  const key=ga<gb?`${ga}:${gb}`:`${gb}:${ga}`;
  if(this.bodiesOverlap(a,b)){this.filter.DisableCollision(ga,gb);this.pendingCollisions.set(key,{a,b});}
  else this.filter.EnableCollision(ga,gb);
 }
 makeFragmentRoom(amount:number){
  let needed=Math.max(0,this.fragments+amount-this.fragmentLimit);if(!needed)return true;
  const debris=this.items.filter(item=>item.kind==='fragment'&&!item.fractured).sort((a,b)=>Number(a.body.IsActive())-Number(b.body.IsActive())||((a.bornAt??0)-(b.bornAt??0)));
  for(const item of debris){
   if(needed<=0)break;
   this.removeRebars(item);this.bodies.RemoveBody(item.body.GetID());this.removedBodies.add(item.body);item.fractured=true;item.retired=true;this.fragments--;needed--;
  }
  return needed===0;
 }
 setFragmentLimit(value:number){this.fragmentLimit=Math.max(24,Math.min(3000,Math.round(value)));this.makeFragmentRoom(0);}
 fracture(item:DynamicItem){
  if(item.fractured)return;
  const piece=this.pieces.find(p=>p.id===item.id);if(!piece)return;
  const chunks=fractureShapes(piece);if(!chunks.length)return;
  if(!this.makeFragmentRoom(chunks.length))return;
  for(const joint of this.jointNeighbors.get(item.id)??[])this.breakJoint(joint);
  const J=this.J,p=item.body.GetPosition(),q=item.body.GetRotation(),v=item.body.GetLinearVelocity(),w=item.body.GetAngularVelocity();
  const origin:V3=[p.GetX(),p.GetY(),p.GetZ()],rotation=[q.GetX(),q.GetY(),q.GetZ(),q.GetW()];
  const velocity:V3=[v.GetX(),v.GetY(),v.GetZ()],angular:V3=[w.GetX(),w.GetY(),w.GetZ()];
  const com=item.body.GetCenterOfMassPosition(),center:V3=[com.GetX(),com.GetY(),com.GetZ()];
  const peers=new Set<any>();
  for(const joint of this.jointNeighbors.get(item.id)??[]){if(joint.a===item)peers.add(joint.b?.body??this.bodyList[joint.groupB!]);else if(joint.b===item)peers.add(joint.a.body);}
  for(const pair of this.pendingCollisions.values()){if(pair.a===item.body)peers.add(pair.b);else if(pair.b===item.body)peers.add(pair.a);}
  const energy=chunks.reduce((sum,c)=>sum+.5*c.mass*c.kick.reduce((n,v)=>n+v*v,0),0);
  const kinetic=.5*PARTS[piece.kind].mass*velocity.reduce((n,v)=>n+v*v,0);
  // Stylized scatter spends at most 2% of the source kinetic energy, capped at 750 J.
  const kickScale=Math.sqrt(Math.min(750,kinetic*.02)/Math.max(energy,.001));
  const transfers=this.rebars.filter(link=>!link.broken&&(link.a===item||link.b===item)).map(link=>({link,pa:this.bodyWorldPoint(link.a,link.localA),pb:this.bodyWorldPoint(link.b,link.localB)}));
  this.removeRebars(item);
  // Keep the removed body's last pose alive for objective/history readers until reset.
  this.bodies.RemoveBody(item.body.GetID());this.removedBodies.add(item.body);item.fractured=true;
  const created:DynamicItem[]=[];
  for(const chunk of chunks){
   const offset=rotateByQuaternion(chunk.center,rotation),position=origin.map((v,a)=>v+offset[a]) as V3;
   const half=new J.Vec3(...chunk.size.map(v=>v/2)),shape=new J.BoxShape(half,.015);J.destroy(half);shape.AddRef();
   const quat=new J.Quat(...rotation),body=this.makeBody(shape,position,quat,chunk.mass,false,true);J.destroy(quat);shape.Release();
   const r=position.map((v,a)=>v-center[a]),cross=[angular[1]*r[2]-angular[2]*r[1],angular[2]*r[0]-angular[0]*r[2],angular[0]*r[1]-angular[1]*r[0]];
   const linear=new J.Vec3(...velocity.map((v,a)=>v+cross[a]+chunk.kick[a]*kickScale));body.SetLinearVelocity(linear);J.destroy(linear);
   const spin=new J.Vec3(...angular);body.SetAngularVelocity(spin);J.destroy(spin);
   for(const peer of peers)if(peer&&!this.removedBodies.has(peer))this.restoreCollisionWhenSeparate(body,peer);
   const fragment:DynamicItem={id:-10000-this.nextFragmentId++,kind:'fragment',body,initial:position,stress:0,size:chunk.size,finish:piece.finish,sourceKind:piece.kind,bornAt:this.elapsed};this.items.push(fragment);created.push(fragment);this.fragments++;
  }
  if(REINFORCED_KINDS.has(piece.kind))this.createRebarChain(created);
  for(const {link,pa,pb} of transfers){const point=link.a===item?pa:pb;const nearest=created.reduce((best,c)=>Math.hypot(...c.initial.map((v,i)=>v-point[i]))<Math.hypot(...best.initial.map((v,i)=>v-point[i]))?c:best);const a=link.a===item?nearest:link.a,b=link.b===item?nearest:link.b;if(!a.fractured&&!b.fractured)this.createRebar(a,b,pa,pb,link.limit,link.strength);}

 }
 bodyWorldPoint(item:DynamicItem,local:V3):V3{const q=item.body.GetRotation(),offset=rotateByQuaternion(local,[q.GetX(),q.GetY(),q.GetZ(),q.GetW()]),p=item.body.GetPosition();return [p.GetX()+offset[0],p.GetY()+offset[1],p.GetZ()+offset[2]];}
 createRebar(a:DynamicItem,b:DynamicItem,pa:V3,pb:V3,limit:number,strength=140000){
  const J=this.J,settings=new J.DistanceConstraintSettings();settings.mPoint1.Set(...pa);settings.mPoint2.Set(...pb);settings.mMinDistance=0;settings.mMaxDistance=limit;
  const constraint=J.castObject(settings.Create(a.body,b.body),J.DistanceConstraint);this.system.AddConstraint(constraint);J.destroy(settings);
  const id=this.nextRebarId++,localA=this.bodyLocalPoint(a,pa),localB=this.bodyLocalPoint(b,pb);this.rebars.push({id,constraint,a,b,localA,localB,limit,strength,broken:false,overloadTime:0});(a.rebarLinks??=[]).push({id,to:b.id,localA,localB});
 }
 createRebarChain(fragments:DynamicItem[]){
  for(let i=1;i<fragments.length;i++){const a=fragments[i-1],b=fragments[i],pa=this.bodyWorldPoint(a,[0,0,0]),pb=this.bodyWorldPoint(b,[0,0,0]),distance=Math.hypot(...pa.map((v,i)=>v-pb[i]));this.createRebar(a,b,pa,pb,distance*1.15+.08);}
 }
 updateRebars(dt:number){
  for(const link of this.rebars){if(link.broken)continue;const tension=Math.abs(link.constraint.GetTotalLambdaPosition())/dt,ratio=tension/link.strength;if(ratio>1)link.overloadTime+=dt*(ratio-1)*(ratio-1);else link.overloadTime=Math.max(0,link.overloadTime-dt*.7);if(link.overloadTime>.065)this.breakRebar(link);}
 }
 breakRebar(link:RebarLink){if(link.broken)return;this.system.RemoveConstraint(link.constraint);link.broken=true;link.a.rebarLinks=link.a.rebarLinks?.filter(row=>row.id!==link.id);}
 removeRebars(item:DynamicItem){for(const link of this.rebars)if(!link.broken&&(link.a===item||link.b===item))this.breakRebar(link);}
 buildingStatus(){
  const positions=new Map<number,V3>(),upright=new Map<number,boolean>(),blueprint=new Map(this.pieces.map(p=>[p.id,p]));
  for(const item of this.items){if(item.id<0)continue;const p=item.body.GetPosition(),q=item.body.GetRotation();positions.set(item.id,[p.GetX(),p.GetY(),p.GetZ()]);const initialYaw=(blueprint.get(item.id)?.rotation??0)*Math.PI/4;const aligned=Math.abs(q.GetY()*Math.sin(initialYaw)+q.GetW()*Math.cos(initialYaw))>=Math.cos(Math.PI/24);upright.set(item.id,!item.fractured&&aligned&&1-2*(q.GetX()*q.GetX()+q.GetZ()*q.GetZ())>=Math.cos(Math.PI/18));}
  const intact=this.joints.filter(j=>!j.broken);
  return evaluateBuilding(this.pieces,{minHeight:this.rules.minHeight??8,minFloorArea:this.rules.minFloorArea??32},{positions,upright,links:intact.filter(j=>j.b).map(j=>[j.a.id,j.b!.id] as [number,number]),anchors:intact.filter(j=>!j.b).map(j=>j.a.id)});
 }
 finish(pass:boolean,reason:string) { this.result=pass?'passed':'failed'; this.reason=reason; }
  dispose() { this.vehicle?.dispose();this.trees?.dispose();for(const j of this.joints)this.system.RemoveConstraint(j.constraint);for(const link of this.rebars)if(!link.broken)this.system.RemoveConstraint(link.constraint);this.rebars=[];for(const c of this.driveConstraints)this.system.RemoveConstraint(c);this.driveConstraints=[]; this.joints=[]; for(const b of this.bodyList){const id=b.GetID();if(!this.removedBodies.has(b))this.bodies.RemoveBody(id);this.bodies.DestroyBody(id)} this.bodyList=[]; this.filter.Release(); this.J.destroy(this.forceVector); this.J.destroy(this.world); }
}
