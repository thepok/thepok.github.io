import {build} from 'esbuild';import assert from 'node:assert/strict';
await build({entryPoints:['src/vehicle-render-pose.ts'],bundle:true,platform:'node',format:'esm',outfile:'artifacts/vehicle-render-pose.mjs'});
const {smoothVehiclePose}=await import('../artifacts/vehicle-render-pose.mjs');
class V{constructor(x=0,y=0,z=0,w=1){Object.assign(this,{x,y,z,w})}set(x,y,z,w=this.w){Object.assign(this,{x,y,z,w});return this}}
const p=new V(),q=new V(),target=new V(),rotation=new V();let last=0,packet=0,arrived=0,raw=0,old=0,oldReversals=0;const intervals=[.033,.08,.02,.065,.04,.09];
for(let i=0;i<500;i++){const t=i/120;if(t>=arrived){raw+=.033*10;target.x=raw;packet=t;arrived=t+intervals[i%intervals.length];}const predicted=raw+Math.min(.05,t-packet)*10;if(predicted<old-1e-5)oldReversals++;old=predicted;smoothVehiclePose(p,q,target,rotation,1/120,i===0);assert.ok(p.x>=last-1e-9,'late snapshots must not pull a forward-moving vehicle backwards');assert.ok(p.x<=target.x+1e-9,'visual pose must not overshoot authoritative vehicle position');last=p.x;}
assert.ok(oldReversals>0,'jitter replay must reproduce prediction corrections');assert.ok(target.x-p.x<1,'smoothing must keep vehicle display latency bounded');
rotation.set(0,0,0,-1);smoothVehiclePose(p,q,target,rotation,.016);assert.ok(Math.abs(q.w-1)<1e-8,'equivalent quaternion signs must not spin the car');target.set(0,0,0);smoothVehiclePose(p,q,target,new V(),0,true);assert.equal(p.x,0,'reset snaps directly to spawn');console.log('PASS jittered snapshot motion, bounded smoothing lag, quaternion continuity and reset', {oldReversals});

