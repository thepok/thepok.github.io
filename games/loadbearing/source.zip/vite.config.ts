import { defineConfig } from 'vite';
export default defineConfig({
  base: './',
  worker: { format: 'es' },
  server: { headers: { 'Cross-Origin-Opener-Policy': 'same-origin', 'Cross-Origin-Embedder-Policy': 'require-corp' } },
  preview: { headers: { 'Cross-Origin-Opener-Policy': 'same-origin', 'Cross-Origin-Embedder-Policy': 'require-corp' } },
  build: {
    rollupOptions: {
      output: { manualChunks(id) { if(id.includes('/node_modules/jolt-physics/')) return 'jolt-physics'; if(id.includes('/node_modules/three/')) return 'three'; } }
    }
  }
});
